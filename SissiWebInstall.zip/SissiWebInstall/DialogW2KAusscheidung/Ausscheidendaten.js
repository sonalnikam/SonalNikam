function Ausscheidendaten()
{ 
  // Momentan nicht benutzt!!!
  alert('Ausscheidendaten')
  if(typeof(Asource)=='undefined')
  {
    alert('nichts ausgew�hlt')
    return
  }
  var OK=true
  var keinesAusgewaehlt=true
  var root=Asource.firstChild;
  var i=0
  while(i<AListe.elements.length-1 && OK)
  {
    if(AListe.elements(i+1).checked)
    {
      keinesAusgewaehlt=false
    }
    i++  
  }
  if(keinesAusgewaehlt) alert('nichts ausgew�hlt')
  else
  {
   alert('ausgew�hlt') 
  }
} 

function AusschDrucken()
{

var i=0

// alert(AListe.elements.length-1)

 
  
if (CheckboxTrue())
	{
	while(i<AListe.elements.length-1 )
		{
		AListe.elements(i+1).disabled=true
		i++  
		}
	DruckeAusscheiden()
	} 
else  alert('nichts ausgew�hlt!')


}

function AusschAlle()
{
// alert('AusschAlle')
if(typeof(Asource)=='undefined')
  {
    alert('nichts ausgew�hlt')
    return
  }
  var OK=true
  var keinesAusgewaehlt=true
  var root=Asource.firstChild;
  var i=0
  while(i<AListe.elements.length-1 && OK)
  {
    AListe.elements(i+1).checked=true
    i++  
  } 
}

function AusschUeber()
{
var root=Asource.firstChild;
var i=0

// alert(AusscheidungSTO);

if (CheckboxTrue())
{
// alert('Ausw�hlen �bertragen ist in Arbeit  '+root.childNodes.length)

  for(i=0; i<root.childNodes.length-1; i++)
  {
	if (AListe.elements(i+1).checked)
	{
		c=root.childNodes(i);
		// alert(c.getElementsByTagName("PARKID")(0).text)
		var pid=c.getElementsByTagName("PARKID")(0).text
		
		var SPLSSource = new ActiveXObject("Microsoft.XMLDOM")
			SPLSSource.async = false;
			
			SPLSSource.load('../DialogW2KAusscheidung/AusscheidungUeber.asp'+
				                  '?PARKID='   +pid)
            
            // alert(SPLSSource.parseError)
            
			if(SPLSSource.parseError != 0)
			 {
			 alert('Parse Error -> '+SPLSSource.parseError)
			 }
			 
			 var aadd=SPLSSource.firstChild;
			  cc=aadd.childNodes(0);
			  var sql   = cc.getElementsByTagName("MSG")(0).text
			 
			 if (sql!='OK') 
			 {
			 alert('Datenbank Fehler');
			 }
	}
  }
  var n="Auscheiden"
  clockTimeoutID=setTimeout("top.LoadAusscheiden('"+n+"')",100,"JavaScript");
} 
else  alert('nichts ausgew�hlt!')
}

function CheckboxTrue()
{
var i=0
  while(i<AListe.elements.length-1)
  {
    if (AListe.elements(i+1).checked) return true;
    i++  
  }
  return false; 
}

function AusschUeber1()
{
alert('AusschUeber1');
}