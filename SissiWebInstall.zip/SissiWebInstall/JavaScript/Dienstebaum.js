function DB(currentNumber,currentIsExpanded) 
{
  DiensteDiv.style.display='block'
  DBDiv.style.display='block' 
  var nCols=4;
  var x1=x2=x3=aa=0
  var str1=ausg=persnr=pid=did=ipnr=hn=f2=''
  var root=Dsource.firstChild;
  var img
 
  imgx = new Image()
  imgx.src = '../Images/replytoauthor.gif'
  imgy = new Image()
  imgy.src = '../Images/DATEICON.gif'
  imgz = new Image()
  imgz.src = '../Images/unknownicon.gif'
  
  str1+='<table border=0 cellspacing=1 cellpadding=0><tr>'+
  '<col WIDTH="20"><col WIDTH="20"><col WIDTH="20"><col WIDTH="20"><col WIDTH="730"><tr>';
  
  var currentNumArray = currentNumber.split(".");  
  var currentLevel = currentNumArray.length-1;
  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)  
 
  for (i=0; i< root.childNodes.length-1; i++)   
  {
    c=root.childNodes(i)
    switch (c.firstChild.tagName)
    {
      case 'PLATZ':
      {
        thisLevel=0
        x1++
        x2=0
        x3=0
        thisNumber=x1+''
        ausg=''+
             c.getElementsByTagName("BEZ")(0).text+' '+
             c.getElementsByTagName("NAME")(0).text+' '+
             c.getElementsByTagName("VNAME")(0).text
        //was='PLATZ'
        persnr=c.getElementsByTagName("PERSNR")(0).text
        pid=c.getElementsByTagName("PARKID")(0).text    
        break;
      }  
      case 'IP':
      {
        thisLevel=1
        x2++
        thisNumber=x1+'.'+x2
        ausg=c.getElementsByTagName("DBEZ")(0).text+' '+
             c.getElementsByTagName("IPNR")(0).text+' '+
             c.getElementsByTagName("DNSDOMAIN")(0).text
        ipnr=c.getElementsByTagName("IPNR")(0).text
        did= c.getElementsByTagName("DIENSTID")(0).text        
        pid= c.getElementsByTagName("PARKID")(0).text    
        break;   
      }
      default:
      { 
        var dbez1= c.getElementsByTagName("DBEZ")(0).text  
          
        if(dbez1=='Hostname' || dbez1=='BS2000-Name' || dbez1=='Sharename (Drucker)' ) thisLevel=2
        else thisLevel=3
        x3++
        thisNumber=x1+'.'+x2+'.'+x3
        ausg=c.getElementsByTagName("DBEZ")(0).text+' '+
             c.getElementsByTagName("HNName")(0).text+' '+
             c.getElementsByTagName("FELD2")(0).text
        pid= c.getElementsByTagName("PARKID")(0).text
        ipnr=c.getElementsByTagName("IPNR")(0).text
        did= c.getElementsByTagName("DIENSTID")(0).text
        hn=c.getElementsByTagName("HNName")(0).text
        f2=c.getElementsByTagName("FELD2")(0).text
        break;
      }               
    }
    ausg=ausg.replace('"','')  	
    if(i<root.childNodes.length-2)
    {
      switch(root.childNodes(i+1).firstChild.tagName)
      {
        case 'PLATZ': aa=0; break;
        case 'ITEM' : aa=1; break;
        default:      aa=2; break;      
      }
    }

	var thisNumArray=thisNumber.split(".");

	var toDisplay=true;
	if(thisLevel>0) 
	{
	  for(j=0;j<thisLevel;j++) 
	  {
		toDisplay = (j>currentLevel)?false:toDisplay && (thisNumArray[j] == currentNumArray[j]);
	  }
    }
    thisIsExpanded = toDisplay && (thisNumArray[thisLevel] == currentNumArray[thisLevel])
    if(currentIsExpanded) 
    {
	  toDisplay = toDisplay && (thisLevel<=currentLevel);
      if(thisNumber==currentNumber) thisIsExpanded=false;      
    }
    //if(toDisplay)		
    if(true) 
    {
      var ausgTD=(thisNumber==currentNumber)?'Exp':'notExp'
      var isLeaf=(i==root.childNodes.length-1) || (thisLevel >= aa)
 	  switch(c.firstChild.tagName)
	  {
	    case 'PLATZ':  img="replytoauthor";break;
	    case 'IP':     img="DATEICON";break;
	    default:       img="unknownicon";break;
	  }      
      
 //var img="leaf"     
	  //var img=(isLeaf)?"leaf":(thisIsExpanded)?"minus":"plus";
	  str1+='<tr>';
	  for(k=1; k<=thisLevel; k++) 
	  {
	    str1+='<td>&nbsp;</td>';
	  }		
	  str1+='<td valign=top>'+
	        '<img src="../Images/'+img+'.gif" onload="" onclick="top.DB('+"'"+thisNumber+"',"+thisIsExpanded+');"></td>' +
	        '<td ID="'+ausgTD+'" colspan='+(nCols-thisLevel)
	  switch(c.firstChild.tagName)
	  {
	    case 'PLATZ': str1+=' onclick="top.Platz('+"'"+persnr+"','"+pid+"'"+')"';break;
	    case 'IP':    str1+=' onclick="top.IP('+"'"+ipnr+"','"+pid+"','"+did+"'"+')"';break;    
	    default:
	    {	      
	      switch(c.getElementsByTagName("DBEZ")(0).text)
	      {
	        case 'Hostname':
	        {
	          domain=c.getElementsByTagName("FELD2")(0).text
	          hn1=c.getElementsByTagName("HNName")(0).text
	          str1+=' onclick="top.Host('+"'"+pid+"','"+ipnr+"','"+did+"','"+hn1+"','"+domain+"'"+')"';
	          break
	        }
	        case 'Alias':
	        {
	          domain=c.getElementsByTagName("FELD2")(0).text
	          hn1=c.getElementsByTagName("HNName")(0).text
	          str1+=' onclick="top.Alias('+"'"+pid+"','"+ipnr+"','"+did+"','"+hn1+"','"+domain+"'"+')"';
	          break
	        }
	        case 'BS2000-Name':
	        {
	          str1+=' onclick="top.BS2000('+"'"+pid+"','"+ipnr+"','"+did+"','"+hn+"'"+')"';
	          break
	        
	        }	         
	        case 'Sharename (Drucker)':
	        { 
	          str1+=' onclick="top.Sharename('+"'"+pid+"','"+ipnr+"','"+did+"','"+hn+"','"+f2+"'"+')"';
	          break	         
	        }
	      }	          
	      break;
	    }        
	  }
	  str1+='>'+ausg+'</td></tr>';
    }
  }
  str1+='</table>';
  //alert(str1)
  DBDiv.innerHTML=str1	
}

function Platz(persnr,pid)
{
  if(top.lastIPSuche!='IPFehler')
  { 
    r=window.showModalDialog("../Dialogs/PLATZDialog.htm","","dialogHeight:80px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  }                           
  switch(r)
  {
    case 'A':
      var DiaDetail="dialogHeight:715px;dialogWidth:420px;"+
         "dialogLeft:340;dialogTop:5;help:No;resizable:No;status:No;scroll:no" 
      r=window.showModalDialog("../Details/DetailParkData.asp?pid="+pid,"",DiaDetail)    
      break;
    case 'N':
    if(chkPW('IP'))
    {
      DiaStrIP="dialogHeight:620px;dialogWidth:480px;"+
               "dialogLeft:290;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
                                             
      r=window.showModalDialog("../MaskeIPNummer/IP.asp?persnr="+persnr+
                                                    "&pid="+pid+
                                                    "&PersKey="+PersKey+
                                                    "&AenPersKey="+AenPersKey,"",DiaStrIP)
      LoadDBaum(persnr,pid,false)
    }                                
  }  
}

function IP(ipnr,pid,did)
{ 
  if(top.lastIPSuche=='IPFehler')
  {
    r=window.showModalDialog("../Dialogs/IPDialogFehler.htm",ipnr,"dialogHeight:180px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  }
  else
  {
//	LevanicE 16.03.2006 - Mail Hr. Cech, Sandmair - Ping Fenster Groesse
//    	r=window.showModalDialog("../Dialogs/IPDialog.htm",ipnr,"dialogHeight:220px;dialogWidth:200px;"+
    	r=window.showModalDialog("../Dialogs/IPDialog.htm",ipnr,"dialogHeight:230px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  
  }                         
  switch (r)
  {
    case 'A':
      var DiaDetail1="dialogHeight:500px;dialogWidth:360px;"+
                     "dialogLeft:320;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
                    
      r=window.showModalDialog("../Details/DetailIP.asp?ipnr="+ipnr+
                                                      "&was=IP"+
                                                      "&pid="+pid,"",DiaDetail1)    
      break;
    case 'AE':if(chkPW('IP'))
    { 

      var DiaStrAe="dialogHeight:600px;dialogWidth:480px;"+
                   "dialogLeft:290;dialogTop:100;help:No;resizable:No;status:No;scroll:no"  
      r=window.showModalDialog("../MaskeIPNummer/IP.asp?ipnr="+ipnr+
                                                      "&pid="+pid+
                                                      "&did="+did+
                                                      "&PersKey="+PersKey+
                                                      "&AenPersKey="+AenPersKey,"",DiaStrAe)
      if (typeof(r)!='undefined')
      {
        var a=r.indexOf('@')
        top.LoadDBaum(r.substring(a+1,100),pid,false)
      }  
    }
    break;                                                     
    case 'L':if(confirm('IP-Nummer '+ipnr+' wirklich l�schen?'))
    {
      if(chkPW('IP'))
      { 
        IPsource = new ActiveXObject("Microsoft.XMLDOM")
        IPsource.async = false;          
        IPsource.load('../ASP/DeleteIP.asp?ipnr='+ipnr+
                                         '&pid='+pid+
                                         '&did='+did+
                                         '&PersKey='+PersKey+
                                         '&AenPersKey='+AenPersKey)
        top.LoadDBaum(ipnr,pid,false)
        IPsource = null                                         
      }
    }
    break;
    case 'Ping':
    { 
//	LevanicE 16.03.2006 - Mail Hr. Cech, Sandmair - Ping Fenster Groesse
//	var DiaStrPing="dialogHeight:200px;dialogWidth:600px;"+
      	var DiaStrPing="dialogHeight:300px;dialogWidth:650px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../PingLookup/PingAusgabe.asp?Suche="+ipnr+"&was=IPNummer",'',DiaStrPing)
      break;
    }
    case 'NSLookup':
    { 
      var DiaStrPing="dialogHeight:200px;dialogWidth:600px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../PingLookup/NSLookupAusgabe.asp?Suche="+ipnr+"&was=IPNummer",'',DiaStrPing)
      break;
    }           
    case 'NH':if(chkPW('IP'))
    {
      r=window.showModalDialog("../MaskeHostAlias/HostAlias.asp?ipnr="+ipnr+
                                                        "&pid="+pid+
                                                        "&did="+did+
                                                        "&was=HOST"+
                                                        "&art=NEU"+
                                                        "&PersKey="+PersKey+
                                                        "&AenPersKey="+AenPersKey,"",DiaStrHo)
      top.LoadDBaum(ipnr,pid,false)
      break;
    }
    case 'NeuerBS2000Zugang':if(chkPW('IP'))
    {
      var DiaStrBS="dialogHeight:240px;dialogWidth:300px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"  
      r=window.showModalDialog("../MaskeBS2000/BS2000.asp?ipnr="+ipnr+
                                                        "&pid="+pid+
                                                        "&did="+did+
                                                        "&art=NEU"+
                                                        "&PersKey="+PersKey+
                                                        "&AenPersKey="+AenPersKey,"",DiaStrBS)
      top.LoadDBaum(ipnr,pid,false)
      break;
    } 
    
    case 'NeuerSharename':if(chkPW('IP'))
    {
      var DiaStrSh="dialogHeight:250px;dialogWidth:300px;"+
         "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../MaskeSharenamen/Sharename.asp?ipnr="+ipnr+
                                                        "&pid="+pid+
                                                        "&did="+did+
                                                        "&art=NEU"+
                                                        "&PersKey="+PersKey+
                                                        "&AenPersKey="+AenPersKey,"",DiaStrSh)
      top.LoadDBaum(ipnr,pid,false)
      break;
    }
    case 'IPDienstverschieben':if(chkPW('IP'))
    {
      var DiaStrPIDAendern="dialogHeight:300px;dialogWidth:360px;"+
          "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no" 
      r=window.showModalDialog("../MaskeParkIDAendern/ParkIDAendern.asp?ipnr="+ipnr+
                                                                      "&pid="+pid+
                                                                      "&did="+did+                                              
                                                                      "&PersKey="+PersKey,"",DiaStrPIDAendern)
      top.LoadDBaum(ipnr,pid,false)     
    }     
  }  
}

function Host(pid,ipnr,did,hostname,domain)
{
  if(top.lastIPSuche!='IPFehler')
  {
    r=window.showModalDialog("../Dialogs/HostDialog.htm",hostname,"dialogHeight:180px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  }                             
  switch (r)
  {
     case 'A':
      var DiaDetail1="dialogHeight:440px;dialogWidth:340px;"+
                    "dialogLeft:320;dialogTop:100;help:No;resizable:No;status:No;scroll:no"

      r=window.showModalDialog("../Details/DetailHost.asp?did="+did+
                                                        "&hostname="+hostname
                                                        ,"",DiaDetail1)    
      break; 
  
    case 'HL':if(chkPW('IP'))
    {
      if(confirm('Dienst wirklich l�schen?'))
      {
        if(chkPW('IP'))
        {
          IPsource = new ActiveXObject("Microsoft.XMLDOM")
          IPsource.async = false;          
          IPsource.load('../ASP/DeleteHostAlias.asp?DIENSTID='+did+'&PersKey='+PersKey+
                                                         '&AenPersKey='+AenPersKey)
          top.LoadDBaum(ipnr,pid,false)
          IPsource = null
        }
      }
      break;
    }
    case 'HN':if(chkPW('IP'))
    { 
      r=window.showModalDialog("../MaskeHostAlias/HostAlias.asp?ipnr="+ipnr+
                                                        "&pid="+pid+
                                                        "&did="+did+
                                                        "&was=ALIAS"+
                                                        "&hostname="+hostname+
                                                        "&art=NEU"+
                                                        "&PersKey="+PersKey+
                                                        "&AenPersKey="+AenPersKey,"",DiaStrHo)
      top.LoadDBaum(ipnr,pid,false)
      break;
    }         
    break;    
    case 'HAE':if(chkPW('IP'))
    {
      r=window.showModalDialog("../MaskeHostAlias/HostAlias.asp?ipnr="+ipnr+
                                                        "&pid="+pid+
                                                        "&did="+did+
                                                        "&was=HOST"+
                                                        "&hostname="+hostname+
                                                        "&art=AENDERN"+
                                                        "&PersKey="+PersKey+
                                                        "&AenPersKey="+AenPersKey,"",DiaStrHo)
      top.LoadDBaum(ipnr,pid,false)
      break;
    }         
    break;
    case 'Ping':
    {
//	LevanicE 16.03.2006 - Mail Hr. Cech, Sandmair - Ping Fenster Groesse
//	var DiaStrPing="dialogHeight:200px;dialogWidth:600px;"+    	 
      	var DiaStrPing="dialogHeight:300px;dialogWidth:650px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../PingLookup/PingAusgabe.asp?Suche="+hostname+"."+domain+"&was=Hostname",'',DiaStrPing)
      break;
    }
    case 'NSLookup':
    { 
      var DiaStrPing="dialogHeight:200px;dialogWidth:600px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../PingLookup/NSLookupAusgabe.asp?Suche="+hostname+"."+domain+"&was=Hostname",'',DiaStrPing)
      break;
    }                     
  }   
}

function Alias(pid,ipnr,did,aliasname,domain)
{
  if(top.lastIPSuche!='IPFehler')
  {
    r=window.showModalDialog("../Dialogs/AliasDialog.htm",aliasname,"dialogHeight:170px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  }                           
  switch (r)
  {
     case 'A':
      var DiaDetail1="dialogHeight:440px;dialogWidth:340px;"+
                    "dialogLeft:320;dialogTop:100;help:No;resizable:No;status:No;scroll:no"

      r=window.showModalDialog("../Details/DetailAlias.asp?did="+did+
                                                        "&aliasname="+aliasname
                                                        ,"",DiaDetail1)    
      break;
  
    case 'AL':if(chkPW('IP'))
    {
      if(confirm('Alias '+aliasname+' wirklich l�schen?'))
      {
        if(chkPW('IP'))
        {
          IPsource = new ActiveXObject("Microsoft.XMLDOM")
          IPsource.async = false;          
          IPsource.load('../ASP/DeleteHostAlias.asp?DIENSTID='+did+'&PersKey='+PersKey+
                                                         '&AenPersKey='+AenPersKey)
          top.LoadDBaum(ipnr,pid,false)
          IPsource = null
        }
      }
      break;
    }   
    case 'AAE':if(chkPW('IP'))
    {
      r=window.showModalDialog("../MaskeHostAlias/HostAlias.asp?ipnr="+ipnr+
                                                        "&pid="+pid+
                                                        "&did="+did+
                                                        "&was=Alias"+
                                                        "&hostname="+aliasname+
                                                        "&art=AENDERN"+
                                                        "&PersKey="+PersKey+
                                                        "&AenPersKey="+AenPersKey,"",DiaStrHo)
      top.LoadDBaum(ipnr,pid,false)
      break;
    }         
    break;
     
    case 'Ping':
    { 
//	LevanicE 16.03.2006 - Mail Hr. Cech, Sandmair - Ping Fenster Groesse
//	var DiaStrPing="dialogHeight:200px;dialogWidth:600px;"+
      	var DiaStrPing="dialogHeight:300px;dialogWidth:650px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../PingLookup/PingAusgabe.asp?Suche="+aliasname+"."+domain+"&was=Aliasname",'',DiaStrPing)
      break;
    }
    case 'NSLookup':
    { 
      var DiaStrPing="dialogHeight:200px;dialogWidth:600px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog("../PingLookup/NSLookupAusgabe.asp?Suche="+aliasname+"."+domain+"&was=Aliasname",'',DiaStrPing)
      break;
    } 
  }          
} 

function BS2000(pid,ipnr,did,BS2000Name)
{
  if(top.lastIPSuche!='IPFehler')
  {
    r=window.showModalDialog("../Dialogs/BS2000Dialog.htm",BS2000Name,"dialogHeight:150px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  }                           
  switch (r)
  {
     case 'DetailAnzeigen':
      var DiaDetail1="dialogHeight:440px;dialogWidth:340px;"+
                    "dialogLeft:320;dialogTop:100;help:No;resizable:No;status:No;scroll:no"

      r=window.showModalDialog("../Details/DetailBS2000.asp?did="+did+
                                                        "&hostname="+BS2000Name
                                                        ,"",DiaDetail1)    
      break;
  
    case 'BS2000Loeschen':if(chkPW('IP'))
    {
      if(confirm('BS2000-Zugang '+BS2000Name+' wirklich l�schen?'))
      {
        if(chkPW('IP'))
        {
          IPsource = new ActiveXObject("Microsoft.XMLDOM")
          IPsource.async = false;          
          IPsource.load('../ASP/DeleteBS2000.asp?DIENSTID='+did+'&PersKey='+PersKey+
                                                         '&AenPersKey='+AenPersKey)
          top.LoadDBaum(ipnr,pid,false)
          IPsource = null
        }
      }
      break;
    }   
    case 'BS2000Aendern':if(chkPW('IP'))
    {
      if(top.lastIPSuche!='IPFehler')
      {
        var DiaStrBS="dialogHeight:210px;dialogWidth:300px;"+
                     "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"  

        r=window.showModalDialog("../MaskeBS2000/BS2000.asp?ipnr="+ipnr+
                                                          "&pid="+pid+
                                                          "&did="+did+
                                                          "&BS2000Name="+BS2000Name+
                                                          "&art=AENDERN"+
                                                          "&PersKey="+PersKey+
                                                          "&AenPersKey="+AenPersKey,"",DiaStrBS)
        top.LoadDBaum(ipnr,pid,false)
        break;
      }  
    }         
    break;
  }       
}

function Sharename(pid,ipnr,did,Servername,Druckername)
{
  if(top.lastIPSuche!='IPFehler')
  {
    r=window.showModalDialog("../Dialogs/SharenameDialog.htm",Druckername,"dialogHeight:150px;dialogWidth:200px;"+
                             "center:yes;help:No;resizable:No;status:No;scroll:no");
  }                           
  switch (r)
  {
     case 'DetailAnzeigen':
     var DiaDetail1="dialogHeight:440px;dialogWidth:340px;"+
                    "dialogLeft:320;dialogTop:100;help:No;resizable:No;status:No;scroll:no"

      r=window.showModalDialog("../Details/DetailSharename.asp?did="+did+
                                                        "&hostname="+Servername
                                                        ,"",DiaDetail1)    
      break;
  
    case 'SharenameLoeschen':
    { 
      if(chkPW('IP'))
      {  
        if(confirm('Sharename '+Druckername+' wirklich l�schen?'))
        {       
          if(chkPW('IP'))
          {
            IPsource = new ActiveXObject("Microsoft.XMLDOM")
            IPsource.async = false;          
            IPsource.load('../ASP/DeleteSharename.asp?DIENSTID='+did+'&PersKey='+PersKey+
                                                         '&AenPersKey='+AenPersKey)
            top.LoadDBaum(ipnr,pid,false)
            IPsource = null
          }         
        }         
      }       
      break;      
    }
   
    case 'SharenameAendern':if(chkPW('IP'))
    {
      var DiaStrSh="dialogHeight:230px;dialogWidth:300px;"+
                   "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
      r=window.showModalDialog(
      "../MaskeSharenamen/Sharename.asp"+
      "?ipnr="+ipnr+
      "&pid="+pid+
      "&did="+did+
      "&Servername="+Servername+
      "&Druckername="+Druckername+
      "&art=AENDERN"+
      "&PersKey="+PersKey+
      "&AenPersKey="+AenPersKey,"",DiaStrSh)
      top.LoadDBaum(ipnr,pid,false)
      break;
    }         
    break;
  }       
}      