function IniAuswW2KEinzelSuche()
{

 //KUK:20050623: Update Input: max 12Chr, Inventarnr.

  AuswW2KGeraet.innerHTML= ''+
  '<form NAME="form5">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="80"><col WIDTH="100"><col WIDTH="80"><col WIDTH="100"><col WIDTH="60">'+
  '<col WIDTH="100"><col WIDTH="110"><col WIDTH="235">'+
  '<tr>'+
  '<th CLASS="U" colspan="7">&nbsp;</th></tr><tr>'+
  '<th>Equipmentnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Equipment" maxlength="10" size="11"></td>'+
  '<th>Inventarnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Inventar"  maxlength="12"  size="12"> </td>'+
  '<th>GNS</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS"       maxlength="20" size="21"></td>'+
  '<th>&nbsp;</th>'+
  '<td><button onClick="Such(\'W2KGeraet\')">Anlage suchen</button></td>'+
  '</tr><tr>'+
  '<th>IP-Nummer</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="IPNummer"  maxlength="15" size="16"></td>'+
  '<th>Host/Alias</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="HostAlias"  maxlength="20" size="21"></td>'+
  '<th>&nbsp;</th>'+
  '<td>&nbsp;</td>'+
  '<th>&nbsp;</th>'+
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+
  '<tr><th colspan="7">&nbsp;</th></tr>'+
  '</table></form>'
}

function IniAuswW2KMassenSuche()
{
  AuswW2KPers.innerHTML= ''+
  '<form NAME="form6">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="50"><col WIDTH="100"><col WIDTH="60"><col WIDTH="80"><col WIDTH="60">'+
  '<col WIDTH="90"><col WIDTH="90"><col WIDTH="70"><col WIDTH="70"><col WIDTH="90">'+
  '<col WIDTH="10"><col WIDTH="100"><col WIDTH="20">'+
  '<tr>'+
  '<th CLASS="U" colspan="11">&nbsp;</th>'+
  '</tr>'+
  '<tr>'+
  '<th>Standort</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="STO"     maxlength="20" size="20"></td>'+
  '<th>Raumnr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Raum"    maxlength="10" size="10"></td>'+
  '<th>Verr-KST</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTVerr" maxlength="30" size="10"></td>'+
  '<th>Betriebsbereich</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Betriebsbereich" maxlength="4" size="4"></td>'+
  '<th>Besitz-KST</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTBesitz" maxlength="30" size="10"></td>'+
  '<td>&nbsp;</td>'+
  '<td><button onClick="Such(\'W2KMassenSuche\')" name="x">Anlage suchen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+
  '<tr>'+
  '<th>Name</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Name" maxlength="20" size="20"></td>'+
  '<th>Vorname</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Vorname" maxlength="20" size="20"></td>'+
  '<th>Abteilung</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Abteilung" maxlength="20" size="20"></td>'+
  '<th>MA-KST</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTBenutzer" maxlength="30" size="10"></td>'+
  '<td>&nbsp;</td>'+
  '<td>'+
  '<SELECT name="Zustand">'+
  '<OPTION VALUE="1">ALLE</OPTION>'+
  '<OPTION VALUE="2">beauftragt</OPTION>'+
  '<OPTION VALUE="3">erledigt</OPTION>'+
  '<OPTION VALUE="4">kein Rollout</OPTION>'+
  '<OPTION VALUE="5">offene</OPTION>'+
  '</SELECT></td>'+
  '<td>&nbsp;</td>'+
  '<input type="hidden" name="order" value=" KUNDE.NAME1,PARK.RAUM,KDANSPRECH.NAME1,KDANSPRECH.NAME2 ">'+
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+
  '<tr><th colspan="11">&nbsp;</th></tr>'+
  '</table></form>'
}