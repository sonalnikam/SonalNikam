function AL()
{

  var root=Asource.firstChild;

  //KK:
  //max: obergrenze an datens�tzen, die insgesamt ausgegeben werden
  max = 600

  //KK: anzeigelimit erh�hen f�r 600 datens�tze
  //ersteAusgabe: Anzahl der Datens�tze, die ausgegeben werden, bevor der Rest eineglesen wird (optimiert die Waretzeit auf die Anzeige)
  ersteAusgabe=69
  //ersteAusgabe=10

  // alert('SPLS    '+form10.STANDORT2.value)

  str1=''

  kopf='<form name="AListe"><table id="ML" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="20"><col WIDTH="10"><col WIDTH="90"><col WIDTH="110"><col WIDTH="70"><col WIDTH="70">'+
  '<col WIDTH="50"><col WIDTH="110"><col WIDTH="80">'+
  '<col WIDTH="110"><col WIDTH="80"><col WIDTH="40"><col WIDTH="100"><col WIDTH="40">'+
  '<tr>'+
  '<th><input type="button" value="X" Name="AChB" onclick="aa4()"></th>'+
  '<th id="InvTH">&nbsp;</th>'+
  '<th id="InvTH">Bezeichnung</th>'+
  '<th id="InvTH" '
  kopf+='>Bez. Erg.<br></th>'+
  '<th id="InvTH">Equip. Nr.<br></th>'+
  '<th id="InvTH">Inventarnr.<br></th>'+
  '<th id="InvTH" '
  kopf+='>StruNr.<br></th>'+
  '<th id="InvTH" '
  kopf+='>Letzter Benutzer<br></th>'+
  '<th id="InvTH" '
  kopf+='>Telefon<br></th>'+
  '<th id="InvTH" '
  kopf+='>Ausscheider<br></th>'+
  '<th id="InvTH">Telefon<br></th>'+
  '<th id="InvTH">KST<br></th>'+
  '<th id="InvTH">STO/Bau/Gesch.<br></th>'+
  '<th id="InvTH">Raum<br></th>'+
  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='')
  {
	// Email 28.6.2004 von Autengruber
    //alert(root.getElementsByTagName("Fehler")(0).text)
  }

  if(root.childNodes.length-1<ersteAusgabe) ersteAusgabe=root.childNodes.length-1

  if(root.childNodes.length-1>max)
  {
    anz=max
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+
        ' S�tzen anzeigen'
    //alert(msg)
  }
  else
  {
    anz=root.childNodes.length-1
    msg=''
  }
  for (i=0; i<ersteAusgabe; i++)
  {
    str1+=root.childNodes(i).firstChild.text+'</tr>';
  }

  //var STOText=form10.STANDORT2.value+'@'+form10.STANDORT2.children[form10.STANDORT2.selectedIndex].text;
  var STOText=form10.STANDORT2.children[form10.STANDORT2.selectedIndex].text;
  ADiv.innerHTML=kopf+str1+'</table><input type="hidden" name="STO" value="'+STOText+'"></input>'
  //ADiv.innerHTML=kopf+str1+'</table><input type="hidden" name="STO" value="'+form10.STANDORT2.value+'"></input>'+
  //'<input type="hidden" name="STOValue" value="'+form10.STANDORT2.children[form10.STANDORT2.selectedIndex].text+'"></input>'

  AusschDiv.style.display='block'
  //W2KDiv.style.cursor='hand'
  //WDiv.runtimeStyle.cursor='hand'
  ADiv.style.display='block'
  ADivUnten.innerHTML='<button STYLE="FONT-SIZE: 8pt;WIDTH: 150px;HEIGHT: 20px" onClick="AusschDrucken()">Auswahl drucken</button>'+
					  '<button STYLE="FONT-SIZE: 8pt;WIDTH: 150px;HEIGHT: 20px" onClick="AusschUeber()">Auswahl �bertragen</button>'

  if(root.childNodes.length-1 > ersteAusgabe)
  {
    window.setTimeout("Aweiter()",1)
  }
  else
  {
    Fortschritt.innerText=''

    //alert(form10.NETZSEG)
    // +form10.NETZSEG.value+

    ADiv.innerHTML=kopf+str1+'</table><input type="hidden" name="STO" value="'+STOText+'"></input>'
    ADiv.runtimeStyle.cursor='hand'

    //Gsource=null
  }
}

function Aweiter()
{

  try
  {
    var root=Asource.firstChild;
    var str2=''

    for(var i=ersteAusgabe; i < (anz); i++)
    {
      str2+=root.childNodes(i).firstChild.text+'</tr>';
    }

    Fortschritt.innerText=msg

    //ADiv.innerHTML=kopf+str1+str2+'</table><input type="hidden" name="STO" value="'+form10.STANDORT2.value+'"></input>'
    var STOText=form10.STANDORT2.children[form10.STANDORT2.selectedIndex].text;
    ADiv.innerHTML=kopf+str1+str2+'</table><input type="hidden" name="STO" value="'+STOText+'"></input>'
    ADiv.runtimeStyle.cursor='hand'
  }
  catch(e)
  {
    alert('zu viele Datens�tze')
    //alert(e)
  }
  //Asource=null
}

function aa4()
{
  for (i=1; i<AListe.elements.length; i++)
  {
    AListe.elements(i).checked=true;
  }
}

function aa6(mpid,hpid)
{
// alert(mpid);
// alert(hpid);
var gns = new Array(2)
gns[0]=mpid;
gns[1]=hpid;

  if(window.event.srcElement.tagName=='TD')
  {
    window.showModalDialog("../DialogW2KAusscheidung/DialogAUSEinzel.asp",gns,"dialogHeight:320px;dialogWidth:740px;"+
                           "center:yes;help:No;resizable:Yes;status:No;scroll:no");
  }
}




