function LoadVerfahren()
{
  Vsource = new ActiveXObject("Microsoft.XMLDOM")
  Vsource.async = false;
                                      
  Vsource.load('../ASP/LoadVerfahren.asp?Verfahren='+form9.Verfahren.value+
                                       '&Name='     +form9.Name.value+
                                       '&Rolle='    +form9.Rolle.value); 
  if(Vsource.parseError != 0)
  {
    VDiv.innerHTML=''
    alert('keinen Treffer gefunden')    
    //alert(Vsource.parseError.reason)
  }
  else
  {
    VL()
    VDiv.style.display='block'
  }
}
