function UL() 
{  
  var root=Msource.firstChild;
  max = 100
  ersteAusgabe=23  
  str1=''
  
  kopf='<form name="MListe"><table id="ML" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="20"><col WIDTH="10"><col WIDTH="100"><col WIDTH="150"><col WIDTH="150"><col WIDTH="150">'+
  '<col WIDTH="50"><col WIDTH="50"><col WIDTH="100">'+
  '<col WIDTH="100"><col WIDTH="50"><col WIDTH="70">'+
  '<tr>'+
  '<th><input type="button" value="X" onclick="a4()"></th>'+
  '<th id="InvTH">&nbsp;</th>'+
  '<th id="InvTH">Firma</th>'+
  '<th id="InvTH" '
  kopf+='>Standort<br></th>'+
  '<th id="InvTH">Bezeichnung<br></th>'+
  '<th id="InvTH" ' 
  kopf+='>Benutzer<br></th>'+ 
  '<th id="InvTH" '
  kopf+='>Persnr<br></th>'+  
  '<th id="InvTH" '
  kopf+='>GNS<br></th>'+
  '<th id="InvTH" '
  kopf+='>IPNR<br></th>'+
  '<th id="InvTH">Abteilung<br></th>'+  
  '<th id="InvTH">MA-KST<br></th>'+ 
  '<th id="InvTH">Betriebsber.<br></th>'+
  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='')
  {
    alert(root.getElementsByTagName("Fehler")(0).text)
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) ersteAusgabe=root.childNodes.length-1
 
  if(root.childNodes.length-1>max)
  {
    anz=max
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+
        ' S�tzen anzeigen' 
  }
  else
  {
    anz=root.childNodes.length-1
    msg=''
  }    
  for (i=0; i<ersteAusgabe; i++)   
  {
    str1+=root.childNodes(i).firstChild.text+'</tr>';
  }
  MDiv.innerHTML=kopf+str1+'</table>'
  
  MassenDiv.style.display='block'
  //W2KDiv.style.cursor='hand'
  //WDiv.runtimeStyle.cursor='hand'
  MDiv.style.display='block'
  MDivUnten.innerHTML='<button STYLE="FONT-SIZE: 8pt;WIDTH: 150px;HEIGHT: 20px" onClick="Massendaten()">Auswahl �bernehmen</button>'
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout("Mweiter()",1)
  }
  else
  {
    Fortschritt.innerText=''
    MDiv.innerHTML=kopf+str1+'</table>'    
    MDiv.runtimeStyle.cursor='hand'
    //Gsource=null 
  }
}

function Mweiter()
{
  try
  {  
    var root=Msource.firstChild;
    var str2=''
    for(var i=ersteAusgabe; i < anz; i++)
    {
      str2+=root.childNodes(i).firstChild.text+'</tr>';
    }  
    Fortschritt.innerText=msg
    MDiv.innerHTML=kopf+str1+str2+'</table>'
    MDiv.runtimeStyle.cursor='hand'
  }
  catch(e)
  {
    alert('zu viele Datens�tze')
  }  
  //Msource=null 
}

function a4()
{ 
  for (i=1; i<MListe.elements.length; i++)   
  {
    MListe.elements(i).checked=true; 
  }
}

function a6(pid,gns)
{
  if(window.event.srcElement.tagName=='TD')
  {
    window.showModalDialog("../DialogW2KEinzel/DialogW2KEinzel.asp",gns,"dialogHeight:320px;dialogWidth:740px;"+
                           "center:yes;help:No;resizable:Yes;status:No;scroll:no");
  }
}




