function IniAuswUebersiedeln()
{ 
  AuswMassen.innerHTML= ''+
  '<form NAME="form8">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="50"><col WIDTH="100"><col WIDTH="55"><col WIDTH="80"><col WIDTH="60">'+
  '<col WIDTH="90"><col WIDTH="90"><col WIDTH="60"><col WIDTH="40"><col WIDTH="135">'+
  '<col WIDTH="5"><col WIDTH="100"><col WIDTH="20">'+    
  '<tr>'+
  '<th CLASS="U" colspan="11">&nbsp;</th>'+
  '</tr>'+      
  '<tr>'+
  '<th>Standort</th>'+       
  '<td><input oncontextmenu="fnLoad(this)" NAME="STO"     maxlength="20" size="20"></td>'+
  '<th>Raumnr</th>'+    
  '<td><input oncontextmenu="fnLoad(this)" NAME="Raum"    maxlength="10" size="10"></td>'+
  '<th>KST Verr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTVerr" maxlength="30" size="10"></td>'+
  '<th>Betriebsbereich</th>'+  
  '<td><input oncontextmenu="fnLoad(this)" NAME="Betriebsbereich" maxlength="4" size="4"></td>'+
  '<th>GNS</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS" maxlength="20" size="21"></td>'+
  '<td>&nbsp;</td>'+ 
  '<td><button onclick="Such(\'Uebersiedeln\')">Anlage suchen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+    
  '<tr>'+
  '<th>Name</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Name" maxlength="20" size="20"></td>'+
  '<th>Vorname</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Vorname" maxlength="20" size="20"></td>'+
  '<th>Abteilung</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Abteilung" maxlength="20" size="20"></td>'+
  '<th>MA-KST</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTBenutzer" maxlength="30" size="10"></td>'+

  '<th>Firma</th>'+
  '<td colspan="2"><span id="Firma" style="display:none"></span>'+
  /*  ** diese Listbox wird aus der Datenbank bef�llt  (siehe die Funktion Allgemein.js -> LadeSELFirma())
  '<SELECT visible=false name="Firma">'+
  '<OPTION VALUE="ALLE">Alle</OPTION>'+
  '<OPTION VALUE="SIEMENS">SIEMENS</OPTION>'+
  '<OPTION VALUE="BALIP">BALIP</OPTION>'+
  '<OPTION VALUE="BFE">BFE</OPTION>'+
  '<OPTION VALUE="BITS">BITS</OPTION>'+
  '<OPTION VALUE="BSH>BSH</OPTION>'+
  '<OPTION VALUE="DATRA">DATRA</OPTION>'+
  '<OPTION VALUE="DOERFLER">DOERFLER</OPTION>'+
  '<OPTION VALUE="ERN E">ERN E</OPTION>'+
  '<OPTION VALUE="FSC">FSC</OPTION>'+
  '<OPTION VALUE="I CENTER">I CENTER</OPTION>'+
  '<OPTION VALUE="INNOVEST">INNOVEST</OPTION>'+
  '<OPTION VALUE="ITWORX">ITWORX</OPTION>'+
  '<OPTION VALUE="LANDIS GYR HT">LANDIS GYR HT</OPTION>'+
  '<OPTION VALUE="LANDIS GYR LFT">LANDIS GYR LFT</OPTION>'+
  '<OPTION VALUE="LANDIS GYR STAEFA">LANDIS GYR STAEFA</OPTION>'+
  '<OPTION VALUE="MWW">MWW</OPTION>'+
  '<OPTION VALUE="OEKW">OEKW</OPTION>'+
  '<OPTION VALUE="PIRELLI">PIRELLI</OPTION>'+
  '<OPTION VALUE="RINGO">RINGO</OPTION>'+
  '<OPTION VALUE="S IND SERV">S IND SERV</OPTION>'+
  '<OPTION VALUE="SAA">SAA</OPTION>'+
  '<OPTION VALUE="SBS">SBS</OPTION>'+ 
  '<OPTION VALUE="SBT">SBT</OPTION>'+  
  '<OPTION VALUE="SEAS">SEAS</OPTION>'+     
  '<OPTION VALUE="SEKD">SEKD</OPTION>'+
  '<OPTION VALUE="SGP">SGP</OPTION>'+       
  '<OPTION VALUE="SGS">SGS</OPTION>'+ 
  '<OPTION VALUE="SIRAM">SIRAM</OPTION>'+
  '<OPTION VALUE="SITEC">SITEC</OPTION>'+
  '<OPTION VALUE="SLG">SLG</OPTION>'+      
  '<OPTION VALUE="SN">SN</OPTION>'+  
  '<OPTION VALUE="SPDSC">SPDSC</OPTION>'+
  '<OPTION VALUE="SPL">SPL</OPTION>'+
  '<OPTION VALUE="VSH">VSH</OPTION>'+
  '</SELECT>*/'</td>'+

  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+ 
  '<tr><th colspan="11">&nbsp;</th></tr>'+        
  '</table></form>'
}
