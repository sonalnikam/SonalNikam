function VL() 
{ 
top.aktVLZeile=''
  var root=Vsource.firstChild;
  max = 1000
  ersteAusgabe=23  
  str1=''
  
  kopf='<form name="VListe"><table id="VL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="150"><col WIDTH="150">'+
  '<tr>'+
  '<th id="VFTH">Verfahren</th><th id="VFTH">Verantwortlicher</th>'+

  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='')
  {
    alert(root.getElementsByTagName("Fehler")(0).text)
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1
    alert(ersteAusgabe)
  }
 
  if(root.childNodes.length-1>max)
  {
    anz=max
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+
        ' S�tzen anzeigen' 
  }
  else
  {
    anz=root.childNodes.length-1
    msg=''
  }    
  for (i=0; i<ersteAusgabe; i++)   
  {
    str1+=root.childNodes(i).firstChild.text+'</tr>';
    //alert(str1)
  }
  VDiv.innerHTML=kopf+str1+'</table>'
  alert(VDiv.innerHTML)
  VerfahrenDiv.style.display='block'
  VDiv.style.display='block'
  
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout("Vweiter()",1)
  }
  else
  {
    Fortschritt.innerText=''
    VDiv.innerHTML=kopf+str1+'</table>'    
    VDiv.runtimeStyle.cursor='hand'
    //Gsource=null 
  }
}

function Vweiter()
{
  try
  {  
    var root=Vsource.firstChild;
    var str2=''
    for(var i=ersteAusgabe; i < anz; i++)
    {
      str2+=root.childNodes(i).firstChild.text+'</tr>';
    }  
    Fortschritt.innerText=msg
    VDiv.innerHTML=kopf+str1+str2+'</table>'
    VDiv.runtimeStyle.cursor='hand'
    
  }
  catch(e)
  {
    alert('zu viele Datens�tze')
  }  
  //Vsource=null 
}

function a9(ParkID,t)
{ 
//alert(t.id)
  if(top.aktVLZeile!='') eval(top.aktVLZeile+'.runtimeStyle.backgroundColor="white"')  
  eval(t.id+'.runtimeStyle.backgroundColor="#99CCCC"')
  top.aktVLZeile=t.id
  top.aktSLZeile=''  
  VerfahrenDiv.style.width=360 //180
  
  SchnittstDiv.style.display='block'
  SSDiv.style.display='block'
  LoadSchnittst(ParkID)
  
}








