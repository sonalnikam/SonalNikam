function IniAuswWSGeraet()
{

  AuswWSGeraet.innerHTML= ''+
  '<form NAME="form11">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="80"><col WIDTH="100"><col WIDTH="80"><col WIDTH="100"><col WIDTH="60">'+
  '<col WIDTH="100"><col WIDTH="110"><col WIDTH="235">'+
  '<tr>'+
  '<th CLASS="U" colspan="7">&nbsp;</th></tr><tr>'+
  '<th>Equipmentnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Equipment" maxlength="10" size="11"></td>'+
  '<th>Inventarnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Inventar"  maxlength="8"  size="9"> </td>'+
  '<th>GNS</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS"       maxlength="20" size="21"></td>'+
  '<th>&nbsp;</th>'+
  '<td><button onClick="Such(\'WSGeraet\')">Anlage suchen</button></td>'+
  '</tr><tr>'+
  '<th>IP-Nummer</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="IPNummer"  maxlength="15" size="16"></td>'+
  '<th>Host/Alias</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="HostAlias"  maxlength="20" size="21"></td>'+
  '<th>&nbsp;</th>'+
  '<td>&nbsp;</td>'+
  '<th>&nbsp;</th>'+
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+
  '<tr><th colspan="7">&nbsp;</th></tr>'+
  '</table></form>'
}

function IniAuswWSPers()
{

  AuswWSPers.innerHTML= ''+
  '<form NAME="form12">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="50"><col WIDTH="100"><col WIDTH="60"><col WIDTH="80"><col WIDTH="60">'+
  '<col WIDTH="90"><col WIDTH="90"><col WIDTH="40"><col WIDTH="70"><col WIDTH="90">'+
  '<col WIDTH="20"><col WIDTH="100"><col WIDTH="20">'+
  '<tr>'+
  '<th CLASS="U" colspan="11">&nbsp;</th>'+
  '</tr>'+
  '<tr>'+
  '<th>Standort</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="STO"     maxlength="20" size="20"></td>'+
  '<th>Raumnr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Raum"    maxlength="10" size="10"></td>'+
  '<th>Verr-KST.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTVerr" maxlength="6" size="6"></td>'+
  '<th>Betriebsbereich</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Betriebsbereich" maxlength="4" size="4"></td>'+
  '<th>Besitz-KST</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTBesitz" maxlength="6" size="6"></td>'+
  '<td>&nbsp;</td>'+
  '<td><button onClick="Such(\'WSPers\')" name="x">Anlage suchen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+
  '<tr>'+
  '<th>Name</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Name" maxlength="20" size="20"></td>'+
  '<th>Vorname</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Vorname" maxlength="20" size="20"></td>'+
  '<th>Abteilung</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Abteilung" maxlength="20" size="20"></td>'+
  '<th>MA-KST</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTBenutzer" maxlength="6" size="6"></td>'+
  '<td>&nbsp;</td>'+
  '<td>'+
  //'<SELECT name="Zustand">'+
  //'<OPTION VALUE="1">ALLE</OPTION>'+
  //'<OPTION VALUE="2">beauftragt</OPTION>'+
  //'<OPTION VALUE="3">erledigt</OPTION>'+
  //'<OPTION VALUE="4">kein Rollout</OPTION>'+
  //'<OPTION VALUE="5">offene</OPTION>'+
  //'</SELECT></td>'+
  '&nbsp;</td>' +
  '<td>&nbsp;</td>'+
  '<input type="hidden" name="order" value=" KUNDE.NAME1,PARK.RAUM,KDANSPRECH.NAME1,KDANSPRECH.NAME2 ">'+
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+
  '<tr><th colspan="11">&nbsp;</th></tr>'+
  '</table></form>'
}

/*
// --- thom, 09.08.2004: first version von Laszlo; nach Autengruber-eMail korr.
function IniAuswWSGeraet()
{

  AuswWSGeraet.innerHTML= ''+
  '<form NAME="form11">'+
  '<table border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="80"><col WIDTH="100"><col WIDTH="80"><col WIDTH="100"><col WIDTH="60">'+
  '<col WIDTH="100"><col WIDTH="70"><col WIDTH="120"><col WIDTH="120">'+
  //'<col WIDTH="157">'+
  '<tr>'+
  '<th colspan="9">&nbsp;</th></tr><tr>'+
  '<th>Equipmentnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Equipment" maxlength="10" size="11"></td>'+
  '<th>Inventarnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Inventar" maxlength="8" size="9"></td>'+
  '<th>GNS</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS"      maxlength="20" size="21"></td>'+
  '<th>Strukturnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Stru"     maxlength="10" size="10"  ></td>'+
  '<td><button  onClick="Such(\'WSGeraet\')">Anlage suchen</button></td>'+
  '</tr><tr>'+
  '<th>IP-Nummer</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="IPNummer" maxlength="15" size="16"></td>'+
  '<th>Host/Alias</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="HostAlias" maxlength="20" size="21"></td>'+
  '<th>MAC-Adr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="MAC" VALUE maxlength="20" size="21"></td>'+
  '<th>gel.Dienste</th>'+
  '<td><input type="checkbox" name="mitgeloeschtDienst"></td>'+
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+
  '<tr><th colspan="9">&nbsp;</th></tr>'+
  '</table></form></div>'
}

function IniAuswWSPers()
{

  AuswWSPers.innerHTML= ''+
  '<form NAME="form12">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="100"><col WIDTH="100"><col WIDTH="100"><col WIDTH="100"><col WIDTH="50">'+
  '<col WIDTH="70"><col WIDTH="70"><col WIDTH="50"><col WIDTH="40"><col WIDTH="100">'+
  '<col WIDTH="87">'+
  '<tr>'+
  '<th CLASS="U" colspan="11">&nbsp;</th></tr><tr>'+
  '<th>Name</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Name"    maxlength="20" size="20"></td>'+
  '<th>Vorname</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Vorname" maxlength="20" size="20"></td>'+
  '<th>Persnr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Persnr"  maxlength="7" size="7"></td>'+
  '<th>Kostenstelle</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KST"     maxlength="6" size="6"></td>'+
  '<th>&nbsp;</th>'+
  '<td><button onClick="Such(\'WSPers\')">Anlage suchen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr><tr>'+
  '<th>BS2000-Zugang</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="BS2000"       maxlength="20" size="20"></td>'+
  '<th>Drucker-Share</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Druckershare" maxlength="20" size="20"></td>'+
  '<th colspan="2">&nbsp;</th>'+
  '<th>gel.Dienste</th>'+
  '<td><input type="checkbox" name="mitgeloeschtDienst"></td>'+
  '<th>&nbsp;</th><td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+
  '<tr><th colspan="11">&nbsp;</th></tr>'+
  '</table></form></div>'
}
*/
