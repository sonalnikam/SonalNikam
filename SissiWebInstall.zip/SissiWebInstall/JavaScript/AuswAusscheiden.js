function IniAuswAusscheiden()
{
  // AUSelSTO()
  AuswAussch.innerHTML= ''+
  '<form NAME="form10">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="60"><col WIDTH="100"><col WIDTH="100">'+
  '<col WIDTH="250"><col WIDTH="200">'+
  '<col WIDTH="87">'+
  '<td>&nbsp;</td>'+
  '<td>&nbsp;</td>'+
  '<td>&nbsp;</td>'+
  '<td style="font-size: 8pt;font-weight:bold;font-family:arial;"></td>'+
  '</tr>'+
  '<td>&nbsp;</td>'+
  '<td>&nbsp;</td>'+
  '<th>Die Pools</th><td><span id="SELStandorte3" style="display:block"></span></td>'+
  '<td colspan="1"><button style="width:110" onClick="Such(\'Ausscheiden\')">Pool Anzeigen</button></td>'+
  '</tr>'+
  '<tr><th colspan="4">&nbsp;</th>'+
  '<td><input type=button id=btnLoe style="width:100;background-color:buttonface;visibility:hidden" value="L�schen" onClick="LoeschePool(this)"></td>'+
  '</tr>'+'</table></form></div>'
}

/*KK: alte funkion vor weiterentwicklung
function LoeschePool(t)
{
//alert('L�schen den Invetarnummer=0');

 var xmlLoeInv = new ActiveXObject("Microsoft.XMLDOM")
 xmlLoeInv.async = false;

 //xmlLoeInv.load('../ASP/LoeschZentralPool.asp')
 window.open('../ASP/LoeschZentralPool.asp','hallo');

 if(xmlLoeInv.parseError != 0)
      {
        //alert('Fehler')
        alert(xmlLoeInv.parseError.reason)
      }

}

KK*/

function LoeschePool(t)
{
  //KK:  loeschZentralPool() ist in der /.Allgemein.js definiert
  loeschZentralPool();
}


function CheckboxTrue()
{
var i=0
  while(i<AListe.elements.length-1)
  {
    if (AListe.elements(i+1).checked) return true;
    i++
  }
  return false;
}

