function IniAuswILPers()
{  
  AuswILPers.innerHTML= ''+
  '<form NAME="form3">'+
  '<table border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="80"><col WIDTH="100"><col WIDTH="80"><col WIDTH="100"><col WIDTH="80">'+
  '<col WIDTH="100"><col WIDTH="60">'+
  '<col WIDTH="267">'+
  '<tr>'+
  '<th colspan="6">&nbsp;</th></tr><tr>'+
  '<th>Name</th>'+       
  '<td><input oncontextmenu="fnLoad(this)" NAME="Name"      maxlength="20" size="20"></td>'+
  '<th>Vorname</th>'+    
  '<td><input oncontextmenu="fnLoad(this)" NAME="Vorname"   maxlength="20" size="20"></td>'+      
  '<th>Abteilung</th>'+ 
  '<td><input oncontextmenu="fnLoad(this)" NAME="Abteilung" maxlength="20" size="20"></td>'+
  '<th>&nbsp;</th>'+     
  '<td><button onClick="Such(\'ILPers\')" name="f3x">Anlage suchen</button></td>'+
  '</tr><tr>'+
  '<th>Persnr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Persnr"    maxlength="7" size="7"></td>'+
  '<th>Kostenstelle</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KST"       maxlength="30" size="10"></td>'+
  '<th>&nbsp;</th>'+
  '<th>&nbsp;</th>'+
  '<th>&nbsp;</th>'+ 
  '<td><button onClick="LoescheForm(this)" name="f3x">Eingaben l�schen</button></td>'+
  '</tr>'+      
  '<tr>'+
  '<th>&nbsp;</th>'+  
  '<th colspan="2" style="text-align: left;"><select name="Menge">'+
  '<option value="1">nur Hardware</option>'+
  '<option value="2">nur Software</option>'+
  '<option value="3">Hardware und Software</option>'+      
  '</select></th>'+      
  '<th colspan="3" style="text-align: left;"><select name="Elemente">'+
  '<option value="1">aktive und gelieferte Elemente</option>'+
  '<option value="2">aktive und bestellte Elemente</option>'+
  '<option value="3">bestellte, aktive und demontierte Elemente</option>'+  
  '</select></th>'+
  '<th>&nbsp;</th>'+       
  '<td>&nbsp;</td>'+
  '</tr>'+   
  '<tr><th colspan="6">&nbsp;</th></tr>'+
  '</table></form></div>'
} 

function IniAuswILGeraet()
{
  var s1=''+
  '<form NAME="form4">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="10"><col WIDTH="60"> <col WIDTH="100"><col WIDTH="5"><col WIDTH="60"> <col WIDTH="80"><col WIDTH="100">'+
  '<col WIDTH="80"><col WIDTH="250"><col WIDTH="10"> <col WIDTH="100"><col WIDTH="10">'+     
  '<tr>'+
  '<th CLASS="U" colspan="2">&nbsp;</th>'+
  '</tr>'+      
  '<tr>'+
  '<th>&nbsp;</th>'+
  '<th>Standort</th>'+       
  '<td><input oncontextmenu="fnLoad(this)" NAME="STO"  maxlength="20" size="20"></td>'+
  '<th>&nbsp;</th>'+
  '<th>Raumnr</th>'+    
  '<td><input oncontextmenu="fnLoad(this)" NAME="Raum" maxlength="10" size="10"></td>'+
  '<th>Betriebsbereich</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Betriebsbereich" maxlength="4" size="4"></td>'+
  '<th>Bezeichnung<input NAME="GeraeteArt" maxlength="30" size="30"></th>'+
  '<td>&nbsp;</td>'+ 
  '<td><button onClick="Such(\'ILGeraet\')">Anlage suchen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+    
  '<tr>'+
  '<th>&nbsp;</th>'+
  '<th>KST Verr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTVerr"   maxlength="30" size="10"></td>'+
  '<th>&nbsp;</th>'+
  '<th>KST Besitz</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTBesitz" maxlength="30" size="10"></td>'+
  '<th>Firma&nbsp;&nbsp;</th>'+
  '<td colspan="2"><SELECT name="FKZ">'+
  '<OPTION VALUE="ALLE">Alle</OPTION>'+
  '<OPTION VALUE="SIEMENS">SIEMENS</OPTION>'+
  '<OPTION VALUE="AOSA">AOSA</OPTION>'+ 
  '<OPTION VALUE="BALIP">BALIP</OPTION>'+
  '<OPTION VALUE="BFE">BFE</OPTION>'+
  '<OPTION VALUE="BITS">BITS</OPTION>'+
  '<OPTION VALUE="BSH>BSH</OPTION>'+
  '<OPTION VALUE="DATRA">DATRA</OPTION>'+
  '<OPTION VALUE="DOERFLER">DOERFLER</OPTION>'+
  '<OPTION VALUE="ERN E">ERN E</OPTION>'+
  '<OPTION VALUE="FSC">FSC</OPTION>'+
  '<OPTION VALUE="I CENTER">I CENTER</OPTION>'+
  '<OPTION VALUE="ISEC">ISEC</OPTION>'+
  '<OPTION VALUE="INNOVEST">INNOVEST</OPTION>'+
  '<OPTION VALUE="LANDIS GYR HT">LANDIS GYR HT</OPTION>'+
  '<OPTION VALUE="LANDIS GYR LFT">LANDIS GYR LFT</OPTION>'+
  '<OPTION VALUE="LANDIS GYR STAEFA">LANDIS GYR STAEFA</OPTION>'+
  '<OPTION VALUE="MWW">MWW</OPTION>'+
  '<OPTION VALUE="NSN">NSN</OPTION>'+
  '<OPTION VALUE="OEKW">OEKW</OPTION>'+
  '<OPTION VALUE="PIRELLI">PIRELLI</OPTION>'+
  '<OPTION VALUE="RINGO">RINGO</OPTION>'+
  '<OPTION VALUE="SAA">SAA</OPTION>'+
  '<OPTION VALUE="SBS">SBS</OPTION>'+ 
  '<OPTION VALUE="SBT">SBT</OPTION>'+ 
  '<OPTION VALUE="SEAS">SEAS</OPTION>'+      
  '<OPTION VALUE="SEKD">SEKD</OPTION>'+
  '<OPTION VALUE="SEN">SEN</OPTION>'+
  '<OPTION VALUE="S ELIN BI">S ELIN BI</OPTION>'+
  '<OPTION VALUE="S ELIN HT CO">S ELIN HT CO</OPTION>'+
  '<OPTION VALUE="SGP">SGP</OPTION>'+       
  '<OPTION VALUE="SGS">SGS</OPTION>'+ 
  '<OPTION VALUE="SIRAM">SIRAM</OPTION>'+
  '<OPTION VALUE="SITEC">SITEC</OPTION>'+
  '<OPTION VALUE="SLG">SLG</OPTION>'+      
  '<OPTION VALUE="SN">SN</OPTION>'+  
  '<OPTION VALUE="SPDSC">SPDSC</OPTION>'+
  '<OPTION VALUE="SPL">SPL</OPTION>'+
  '<OPTION VALUE="STS">STS</OPTION>'+
  '<OPTION VALUE="VAT PM">VAT PM</OPTION>'+
  '<OPTION VALUE="VSH">VSH</OPTION>'+
  '<OPTION VALUE="UNIT IT">UNIT IT</OPTION>'+
  '</SELECT></td>'+
  '<td>&nbsp;</td>'+       
  '<td><button onClick="LoescheForm(this)" name="f3x">Eingaben l�schen</button></td>'+
  '<th>&nbsp;</th>'+
  '</tr>'+ 
  '<tr>'+
  '<th>&nbsp;</th>'+  
  '<th colspan="2" style="text-align: left;"><select name="Menge">'+
  '<option value="1">nur Hardware</option>'+
  '<option value="2">nur Software</option>'+
  '<option value="3">Hardware und Software</option>'+
  '<option value="4">nur Kopfzeile</option>'+     
  '</select></th>'+ 
  '<th>&nbsp;</th>'+      
  '<th colspan="3" style="text-align: left;"><select name="Elemente">'+
  '<option value="1">aktive und gelieferte Elemente</option>'+
  '<option value="2">aktive und bestellte Elemente</option>'+
  '<option value="3">bestellte, aktive und demontierte Elemente</option>'+  
  '</select></th>'+
  '<td colspan="2"><span id="SELArbeitsplaetze1" style="display:none"></span></td>'+   
  '<td>&nbsp;</td>'+
  '<td>&nbsp;</td>'+               
  '<th>&nbsp;</th></tr>'+
  '<tr><th colspan="9">&nbsp;</th></tr>'+      
  '</table></form></div>'
  AuswILGeraet.innerHTML=s1
}