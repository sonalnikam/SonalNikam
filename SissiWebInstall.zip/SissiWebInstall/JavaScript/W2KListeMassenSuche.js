function WLM(was)
{
  var root=Gsource.firstChild;
  max = 5000
  ersteAusgabe=23
  str1=''

  kopf='<form name="W2KListeMassenSuche"><table id="InvL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="20"><col WIDTH="10">'+
  /*<col WIDTH="85"><col WIDTH="120">*/
  '<col WIDTH="50"><col WIDTH="140"><col WIDTH="100"><col WIDTH="80"><col WIDTH="150">'+
  '<col WIDTH="50"><col WIDTH="80"><col WIDTH="80"><col WIDTH="50"><col WIDTH="100">'+
  '<col WIDTH="100"><col WIDTH="50"><col WIDTH="50"><col WIDTH="70">'+
  '<tr>'+
  '<th><input type="button" value="X" onclick="a3()"></th>'+
  '<th id="InvTH">&nbsp;</th>'+
  /*'<th id="InvTH">Clienttyp</th>'+
  '<th id="InvTH">MS-Lizenzvereinbarung</th>'+*/
  '<th id="InvTH">Status</th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' KUNDE.NAME1,KDANSPRECH.NAME1,KDANSPRECH.NAME2 '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>Standort<br></th>'+
  '<th id="InvTH">Bezeichnung<br></th>'+
  '<th id="InvTH">Inbetriebs-nahme<br></th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' KDANSPRECH.NAME1,KDANSPRECH.NAME2 '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>Benutzer<br></th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' KDANSPRECH..PERSNR '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>Persnr<br></th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' PARK_1.INVNR '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>Inventarnr<br></th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' PARK_1.BEREICHNR1 '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>Equipmentnr<br></th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' PARK.BEZ '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>GNS<br></th>'+
  '<th id="InvTH" '
  if(was==1) kopf+='onclick="form6.order.value='+"'"+' DIENSTE.FELD1 '+"'"+';Such('+"'"+'W2KMassenSuche'+"'"+')"'
  kopf+='>IPNR<br></th>'+
  '<th id="InvTH">Abteilung<br></th>'+
  '<th id="InvTH">MA-KST<br></th>'+
  '<th id="InvTH">Besitz-KST<br></th>'+
  '<th id="InvTH">Betriebsber.<br></th>'+
  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='')
  {
    Aendern.innerHTML=''
    Sichern.innerHTML=''
    alert(root.getElementsByTagName("Fehler")(0).text)
  }

  if(root.childNodes.length-1<ersteAusgabe) ersteAusgabe=root.childNodes.length-1

  if(root.childNodes.length-1>max)
  {
    anz=max
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+
        ' S�tzen anzeigen'
  }
  else
  {
    anz=root.childNodes.length-1
    msg=''
  }
  for (i=0; i<ersteAusgabe; i++)
  {
    str1+=root.childNodes(i).firstChild.text+'</tr>';
  }
  WDiv.innerHTML=kopf+str1+'</table>'

  W2KDiv.style.display='block'
  //W2KDiv.style.cursor='hand'
  //WDiv.runtimeStyle.cursor='hand'
  WDiv.style.display='block'

  var u1=''
  if(was==1)
  {
    u1+=''+
    '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
    '<button onClick="ExcelW2K()" STYLE="HEIGHT: 20px; WIDTH: 120px">Excel</button>'
  }
  WDivUnten.innerHTML=u1

  if(root.childNodes.length-1 > ersteAusgabe)
  {
    window.setTimeout("W2Kweiter()",1)
  }
  else
  {
    Fortschritt.innerText=''
    WDiv.innerHTML=kopf+str1+'</table>'
    WDiv.runtimeStyle.cursor='hand'
    //Gsource=null
  }
}

function W2Kweiter()
{
  try
  {
    var root=Gsource.firstChild;
    var str2=''
    for(var i=ersteAusgabe; i < anz; i++)
    {
      str2+=root.childNodes(i).firstChild.text+'</tr>';
    }
    Fortschritt.innerText=msg
    WDiv.innerHTML=kopf+str1+str2+'</table>'
    WDiv.runtimeStyle.cursor='hand'
  }
  catch(e)
  {
    alert('zu viele Datens�tze')
  }
  //Gsource=null
}

function a3()
{
  for (i=1; i<W2KListeMassenSuche.elements.length; i++)
  {
    W2KListeMassenSuche.elements(i).checked=true;
  }
}

function a5(pid,pid1,gns)
{
  var r,r1,r2

  if(window.event.srcElement.tagName=='TD')
  {
    r=window.showModalDialog("../Dialogs/W2KMassenSucheDialog.htm","","dialogHeight:150px;dialogWidth:250px;"+
                             "center:yes;help:No;resizable:Yes;status:No;scroll:no");
    if(typeof(r)!='undefined')
    {
      switch(r)
      {
        case 'Detail': {r=window.showModalDialog("../DialogW2KEinzel/DialogW2KEinzel.asp",gns,"dialogHeight:320px;dialogWidth:740px;"+
                                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
                         break}
        case 'Auftrag': {r1=window.showModalDialog("../DialogW2KAuftrag/DialogW2KAuftrag.asp?pid="+pid+"&pid1="+pid1+"&gns="+gns+"&PersKey="+PersKey,window,"dialogHeight:660px;dialogWidth:800px;"+
                                                 "center:yes;help:No;resizable:Yes;status:No;scroll:yes");


			if(typeof(r1)=='undefined') break;


						 var r1arr = new Array(11)
						 var r1Anz =1
						 var trch="@"



						 if (r1.substr(0,2)=='OK')
						 {
						 r1Anz=zerlegen(trch,r1,r1arr);

						 //KK: 04.05.2005, Auskommentiert, weil die beiden Felder
						 //aus Auftrag-Formular gestrichen wurden.
						 //W2KLizenzAen(r1arr[3],pid,PersKey);
						 //W2KClientAen(r1arr[1],pid,PersKey);

						 }

                         break}
        case 'Ausscheid': { var AsArr = new Array();
							AsArr[0]=gns;
							AsArr[1]=ASPIDKey;
							AsArr[2]=ASPIDKey;



                                          // beginn aut.m 040709
                                                        r=window.showModalDialog("../a/sperre.htm",AsArr,"dialogHeight:50px;dialogWidth:300px;"+
                                                        "center:yes;help:No;resizable:Yes;status:No;scroll:no");
                                                        //alert(r)
                                                        if (r=="wert12")
                                                         {
                                                           r=1;
					                   while(r==1)
							   {
					                     r=window.showModalDialog("../DialogW2KAusscheidung/DialogW2KAusscheidung.asp",AsArr,"dialogHeight:500px;dialogWidth:740px;"+
                                                             "center:yes;help:No;resizable:Yes;status:No;scroll:no");
                                                           }
                                                         }
                                          // ende aut.m 040709


                         break}
      }
    }
  }
}

function zerlegen(ptrch,pStr,pArr)
{
  var iLength=pStr.length;
  var j=0;
  var k;
  var arr = new Array(30);

  var l=0;
  arr[l++]=-1;
  while(j==j)
	{
	k=pStr.indexOf(ptrch,j)
	if(k==-1) break;
	arr[l++]=k;
	j=k+1;
	}

	arr[l]=iLength;

	pN=0;

	for (jj=0; jj<l; jj++)
	{
	iKezd=arr[jj]+1
	iHossz=arr[jj+1]-arr[jj]-1
	pArr[jj]=pStr.substr(iKezd,iHossz);
	pN++;
	}

	return pN;
  }

  function W2KLizenzAen(liz,pid,PersKey)
  {
  //alert(liz+'  '+pid+' '+PersKey)

  var W2KAendernSource = new ActiveXObject("Microsoft.XMLDOM")
  W2KAendernSource.async = false;

  W2KAendernSource.load('../ASP/W2KAendern1.asp'+
                            '?PARKID='   +pid+
                            '&Lizenz='   +liz+
                            '&PersKey='  +PersKey)

      if(W2KAendernSource.parseError != 0)
      {
          alert(W2KAendernSource.parseError.reason)
      }
	  else
	  {
		if (W2KListeMassenSuche.elements.length < 51)
		{
		 var root=Gsource.firstChild;

  		 for (i=1; i<W2KListeMassenSuche.elements.length; i++)
		 {
		 if (pid == root.childNodes(i-1).getElementsByTagName("PARKID")(0).text)
		 InvL.childNodes(1).children(i).children(3).innerHTML=liz;
		 }
        }
      }
  }

  function W2KClientAen(client,pid,PersKey)
  {
  // alert(client+'  '+pid+' '+PersKey+' '+ client.substr(0,3))

  if (client.substr(0,3) != 'CAT' && client.substr(0,3) != 'unb')
   {

   var W2KAendernSource = new ActiveXObject("Microsoft.XMLDOM")
   W2KAendernSource.async = false;

   W2KAendernSource.load('../ASP/W2KAendern2.asp'+
                            '?PARKID='   +pid+
                            '&Clienttyp='   +client+
                            '&PersKey='  +PersKey)

      if(W2KAendernSource.parseError != 0)
      {
          alert(W2KAendernSource.parseError.reason)
      }
       else
	  {
		if (W2KListeMassenSuche.elements.length < 51)
		{
		 var root=Gsource.firstChild;

	      for (i=1; i<W2KListeMassenSuche.elements.length; i++)
		  {
		  if (pid == root.childNodes(i-1).getElementsByTagName("PARKID")(0).text)
		  InvL.childNodes(1).children(i).children(2).innerHTML=client;
		  }
	    }
	  }
   }

  }



