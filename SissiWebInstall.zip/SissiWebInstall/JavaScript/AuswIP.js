function IniAuswIPGeraet()
{   
  AuswIPGeraet.innerHTML= ''+
  '<form NAME="form1">'+
  '<table border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="80"><col WIDTH="100"><col WIDTH="80"><col WIDTH="100"><col WIDTH="60">'+
  '<col WIDTH="100"><col WIDTH="70"><col WIDTH="120"><col WIDTH="120">'+
  //'<col WIDTH="157">'+
  '<tr>'+
  '<th colspan="9">&nbsp;</th></tr><tr>'+
  '<th>Equipmentnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Equipment" maxlength="10" size="11"></td>'+
  '<th>Inventarnr.</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Inventar" maxlength="12" size="12"></td>'+
  '<th>GNS</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS"      maxlength="20" size="21"></td>'+
  '<th>Strukturnr.</th>'+  
  '<td><input oncontextmenu="fnLoad(this)" NAME="Stru"     maxlength="30" size="10"  ></td>'+
  '<td><button  onClick="Such(\'IPGeraet\')">Anlage suchen</button></td>'+        
  '</tr><tr>'+  
  '<th>IP-Nummer</th>'+  
  '<td><input oncontextmenu="fnLoad(this)" NAME="IPNummer" maxlength="15" size="16"></td>'+
  '<th>Host/Alias</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="HostAlias" maxlength="20" size="21"></td>'+
  '<th>MAC-Adr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="MAC" VALUE maxlength="20" size="21"></td>'+
  '<th>gel.Dienste</th>'+ 
  '<td><input type="checkbox" name="mitgeloeschtDienst"></td>'+   
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+
  '<tr><th colspan="9">&nbsp;</th></tr>'+
  '</table></form></div>'
}

function IniAuswIPPers()
{
  AuswIPPers.innerHTML= ''+
  '<form NAME="form2">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="100"><col WIDTH="100"><col WIDTH="100"><col WIDTH="100"><col WIDTH="50">'+
  '<col WIDTH="70"><col WIDTH="90"><col WIDTH="70"><col WIDTH="20"><col WIDTH="100">'+
  '<col WIDTH="87">'+
  '<tr>'+
  '<th CLASS="U" colspan="11">&nbsp;</th></tr><tr>'+
  '<th>Name</th>'+       
  '<td><input oncontextmenu="fnLoad(this)" NAME="Name"    maxlength="20" size="20"></td>'+
  '<th>Vorname</th>'+    
  '<td><input oncontextmenu="fnLoad(this)" NAME="Vorname" maxlength="20" size="20"></td>'+
  '<th>Persnr</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Persnr"  maxlength="7" size="7"></td>'+
  '<th>Kostenstelle</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KST"     maxlength="30" size="10"></td>'+
  '<th>&nbsp;</th>'+
  '<td><button onClick="Such(\'IPPers\')">Anlage suchen</button></td>'+
  '<th>&nbsp;</th>'+        
  '</tr><tr>'+
  '<th>BS2000-Zugang</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="BS2000"       maxlength="20" size="20"></td>'+
  '<th>Drucker-Share</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Druckershare" maxlength="20" size="20"></td>'+
  '<th colspan="2">&nbsp;</th>'+
  '<th>gel.Dienste</th>'+ 
  '<td><input type="checkbox" name="mitgeloeschtDienst"></td>'+ 
  '<th>&nbsp;</th><td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+
  '<tr><th colspan="11">&nbsp;</th></tr>'+
  '</table></form></div>'
}

function IniAuswIPFehler()
{
  AuswIPFehler.innerHTML= ''+
  '<form NAME="FehlerForm">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+
  '<col WIDTH="10"><col WIDTH="100"><col WIDTH="200">'+
  '<col WIDTH="100"><col WIDTH="300">'+
  '<col WIDTH="87">'+
  '<tr>'+
  '<th CLASS="U" colspan="6">&nbsp;</th></tr><tr>'+
  '<td>&nbsp;</td>'+
  '<th>Standorte</th><td><span id="SELStandorte2" style="display:block"></span></td>'+
  '<th>&nbsp;</th>'+
  '<td><button style="width:300" onClick="Such(\'IPFehler1\')">deaktivierte Anlagen mit Diensten suchen</button></td>'+
  '<th>&nbsp;</th>'+        
  '</tr>'+
  '<tr><th colspan="4">&nbsp;</th>'+
  '<td><button style="width:300" onClick="Such(\'IPFehler2\')">Arbeitspl�tze mit IP-Adresse ohne Unterkomponenten</button></td>'+
  '<th>&nbsp;</th>'+  
  '</tr>'+
  //'<tr><th colspan="6">&nbsp;</th></tr>'+
 
  '<tr><th colspan="4">&nbsp;</th>'+
  '<td><button style="width:300" onClick="Such(\'IPFehler3\')">Arbeitspl�tze mit abgelaufener IP-Adresse</button></td>'+
  '<th>&nbsp;</th>'+  
  '</tr>'+

  
  '</table></form></div>'
}