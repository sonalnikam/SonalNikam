vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|17 Oct 2001 16:35:33 +0200
vti_modifiedby:SR|ATVIEE101A\\hertlk
vti_backlinkinfo:VX|htm/main.htm Htm/Main\\ 20040613.htm Htm/Main\\ 20040614.htm
vti_nexttolasttimemodified:TW|15 Jan 2002 15:57:07 +0100
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|15 Jan 2002 15:57:08 +0100
