vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|22 Oct 2001 15:40:01 +0200
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|htm/main.htm Htm/Main\\ 20040613.htm Htm/Main\\ 20040614.htm
vti_nexttolasttimemodified:TW|12 Mar 2002 08:38:07 +0100
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|12 Mar 2002 08:49:10 +0100
