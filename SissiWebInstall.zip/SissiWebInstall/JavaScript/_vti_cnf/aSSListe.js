vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|23 Oct 2001 13:37:54 +0200
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|12 Mar 2002 08:38:07 +0100
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|24 Apr 2002 14:40:37 +0200
