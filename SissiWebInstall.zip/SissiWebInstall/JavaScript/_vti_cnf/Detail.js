vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|09 Oct 2001 11:37:39 +0200
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|details/detailip.asp details/detailparkobjekt.asp details/detailpark_rollen.asp details/detailhost.asp park/maskepark.htm details/detailkdansprech.asp details/detailsharename.asp details/detailparkdata.asp details/detailanlklasse.asp verfahren/maskeschnittst.htm details/alleparkid.asp details/detailbs2000.asp details/detaildomain.asp details/detailsegment.asp details/detailalias.asp
vti_nexttolasttimemodified:TW|24 Apr 2002 10:06:32 +0200
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|24 Apr 2002 10:06:34 +0200
