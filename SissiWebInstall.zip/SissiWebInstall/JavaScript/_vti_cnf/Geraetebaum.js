vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|09 Oct 2001 11:37:40 +0200
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|htm/main.htm Htm/Main\\ 20040613.htm Htm/Main\\ 20040614.htm
vti_nexttolasttimemodified:TW|22 Aug 2002 11:52:19 +0200
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|22 Aug 2002 11:52:41 +0200
