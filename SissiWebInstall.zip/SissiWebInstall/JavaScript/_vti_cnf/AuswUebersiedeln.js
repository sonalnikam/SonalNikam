vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|17 Oct 2001 15:20:13 +0200
vti_filesize:IX|2328
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|htm/main.htm Htm/Main\\ 20040613.htm Htm/Main\\ 20040614.htm
vti_nexttolasttimemodified:TW|16 May 2002 11:32:32 +0200
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|16 May 2002 11:33:25 +0200
