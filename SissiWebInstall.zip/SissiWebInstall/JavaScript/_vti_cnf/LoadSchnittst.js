vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|23 Oct 2001 13:34:58 +0200
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|werner/werner.asp htm/main.htm Htm/Main\\ 20040613.htm Htm/Main\\ 20040614.htm
vti_nexttolasttimemodified:TW|08 Apr 2002 14:13:51 +0200
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|08 Apr 2002 14:13:52 +0200
