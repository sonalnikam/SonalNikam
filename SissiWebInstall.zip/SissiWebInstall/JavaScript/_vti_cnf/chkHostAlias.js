vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|09 Oct 2001 11:37:38 +0200
vti_modifiedby:SR|IUSR_A_32_028
vti_backlinkinfo:VX|maskehostalias/hostalias.asp maskesharenamen/sharename.asp maskeipnummer/altip.asp maskebs2000/bs2000.asp maskeipnummer/ip.asp
vti_nexttolasttimemodified:TW|22 Aug 2002 13:12:00 +0200
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|22 Aug 2002 13:14:42 +0200
