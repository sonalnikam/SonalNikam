vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Aug 2004 10:40:15 -0000
vti_extenderversion:SR|6.0.2.6551
vti_backlinkinfo:VX|Htm/Main.htm
