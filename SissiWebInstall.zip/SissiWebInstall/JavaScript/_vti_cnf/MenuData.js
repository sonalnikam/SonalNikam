vti_encoding:SR|utf8-nl
vti_author:SR|ATVIEE101A\\hertlk
vti_timecreated:TR|09 Oct 2001 11:37:45 +0200
vti_modifiedby:SR|ATVIEE101A\\hertlk
vti_backlinkinfo:VX|htm/main.htm Htm/Main\\ 20040613.htm Htm/Main\\ 20040614.htm
vti_extenderversion:SR|3.0.2.1105
vti_timelastmodified:TR|09 Oct 2001 11:37:45 +0200
