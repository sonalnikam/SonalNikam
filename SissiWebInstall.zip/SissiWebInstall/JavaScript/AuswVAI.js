function IniAuswVAIKOA()
{
  AuswVAIKOA.innerHTML= ''+
  '<form NAME="form13">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="70"><col WIDTH="100"><col WIDTH="80"><col WIDTH="320"><col WIDTH="50"><col WIDTH="140"><col WIDTH="160">'+
  '<tr height="14">'+
  '<th colspan="7">&nbsp;</th>'+
  '</tr>'+      
  '<tr colspan="7">'+

  //statt einer Combobox, nur VAI
  //'<th>Firma&nbsp;&nbsp;</th>'+
  //'<td colspan="1"><SELECT name="Firma">'+
  //'<OPTION VALUE="ALLE">Alle</OPTION>'+   
  //'<OPTION VALUE="VAI">VAI</OPTION>'+
  //'</SELECT></td>'+  
  '<th>Firma&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Firma" maxlength="50" size="14" VALUE="SIEMENS VAI MT"></td>'+
  
  '<th>Leistungsart&nbsp;&nbsp;</th>'+
  '<td colspan="1"><span id="SELLeistungsarten1" style="display:none"></span></td>'+ 
  '<td></td>'+
  '<td><button style="width:120" onClick="Such(\'VAIKOA\')">Auswahl</button></td>'+
  '<td><b>Inkl. EG und EK&nbsp;&nbsp;</b><INPUT TYPE=CHECKBOX NAME="dispAll" value="Alle"></td>'+
  '</tr>'+ 
  '</table></form>'
} 

function IniAuswVAIABR()
{
  AuswVAIABR.innerHTML= ''+
  '<form NAME="form14">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+ 
  //   '<col WIDTH="70"><col WIDTH="70"><col WIDTH="90"><col WIDTH="70"><col WIDTH="80"><col WIDTH="70"><col WIDTH="70"><col WIDTH="180"><col WIDTH="10"><col WIDTH="80"><col WIDTH="10"><col WIDTH="80">'+

  '<col WIDTH="70"><col WIDTH="70"><col WIDTH="90"><col WIDTH="70"><col WIDTH="80"><col WIDTH="190"><col WIDTH="70"><col WIDTH="60"><col WIDTH="10"><col WIDTH="80"><col WIDTH="10"><col WIDTH="80">'+
  '<tr>'+
  '<th colspan="8">&nbsp;</th>'+
  '</tr>'+      
  '<tr colspan="12">'+
  
  //statt einer Combobox, nur VAI
  //'<th>Firma&nbsp;&nbsp;</th>'+
  //'<td colspan="1"><SELECT name="Firma">'+
  //'<OPTION VALUE="ALLE">Alle</OPTION>'+   
  //'<OPTION VALUE="VAI">VAI</OPTION>'+
  //'</SELECT></td>'+  
  '<th>Firma&nbsp;&nbsp;</th>'+
  '<td colspan="2" rowspan="1"><input oncontextmenu="fnLoad(this)" NAME="Firma" maxlength="50" size="14" VALUE="SIEMENS VAI MT"></td>'+
  '<td><input type="hidden" name="ExcelStatus" value="Nix" maxlength="5" size="5"></td>'+
  
  '<th>Leistungsart&nbsp;&nbsp;</th>'+
  '<td colspan="3"><span id="SELLeistungsarten2" style="display:none"></span></td>'+ 
  '<td></td>'+
  '<td><button style="width:75" disabled name="Akt" onClick="Such(\'VAIABR1\')">Akt. Daten</button></td>'+
  '<td></td>'+
  '<td><button style="width:75" name="Histo" onClick="Such(\'VAIABR2\')">Hist. Daten</button></td>'+
  '</tr>'+
  
  '<tr colspan="6">'+        
  '<th>GNS&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS" maxlength="20" size="21"></td>'+  
  '<th>Equipmentnr.&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="EQUINR" maxlength="10" size="11"></td>'+
  '<th>KST&nbsp;&nbsp;</th>'+
  '<td colspan="3" rowspan="1"><input oncontextmenu="fnLoad(this)" NAME="KST" maxlength="30" size="30"></td>'+

  '<td></td>'+
  '<td><button style="width:75" name="AnzAkt" onClick="Such(\'VAIABR5\')">Schnellsuche</button></td>'+
  '</tr>'+
  
  '<tr colspan="8">'+ 
  '<th>Von Monat&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="VONMONAT" maxlength="2" size="2"></td>'+       
  '<th>Von Jahr&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="VONJAHR" maxlength="4" size="4"></td>'+
  '<th>Bis Monat&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="BISMONAT" maxlength="2" size="2"></td>'+
  '<th>Bis Jahr&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="BISJAHR" maxlength="4" size="4"></td>'+
  
  '<td></td>'+
  '<td><button style="width:75" name="btnFreigabe" onClick="Such(\'VAIABR3\')">Freigabe</button></td>'+
  '<td></td>'+
  '<td><button style="width:75" onClick="Such(\'VAIABR4\')">Excelexport</button></td>'+
  '</tr>'+ 
  '</table></form>'
  
}

function IniAuswVAIKST()
{
  AuswVAIKST.innerHTML= ''+
  '<form NAME="form15">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="70"><col WIDTH="180"><col WIDTH="80"><col WIDTH="280"><col WIDTH="50"><col WIDTH="120">'+
  '<tr>'+
  '<th colspan="6">&nbsp;</th></tr><tr>'+
  
  //statt einer Combobox, nur VAI
  //'<th>Firma&nbsp;&nbsp;</th>'+
  //'<td colspan="1"><SELECT name="Firma">'+
  //'<OPTION VALUE="ALLE">Alle</OPTION>'+   
  //'<OPTION VALUE="VAI">VAI</OPTION>'+
  //'</SELECT></td>'+  
  '<th>Firma&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Firma" maxlength="50" size="14" VALUE="SIEMENS VAI MT"></td>'+
  
  '<th>UserAbt.&nbsp;&nbsp;</th>'+
  '<td colspan="1"><SELECT name="BereichKZ">'+
  '<OPTION VALUE="ALLE">Alle</OPTION>'+   
  '<OPTION VALUE="VAI Abteilung xy">VAI Abteilung xy</OPTION>'+
  '</SELECT></td>'+
 
  '<th></th>'+
  '<td><button style="width:120" name="btnVAIKST" onClick="EnableVAIKST2();">Auswahl</button></td>'+
  '</tr>'+
  
  '<tr>'+
  '<th>KST-alt&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KSTalt" maxlength="30" size="27"></td>'+  

  '<th>KST-neu&nbsp;&nbsp;</th>'+
  '<td colspan="1"><SELECT name="KSTneu">'+
  '<OPTION VALUE="ALLE">Alle</OPTION>'+
  '<OPTION VALUE="C.09E0.SL.UEW.FR.01">C.09E0.SL.UEW.FR.01</OPTION>'+
  '<OPTION VALUE="C.4892.SL.0.CS030">C.4892.SL.0.CS030</OPTION>'+
  '<OPTION VALUE="C.5630.CB.0.CS030">C.5630.CB.0.CS030</OPTION>'+
  '<OPTION VALUE="C.IL20.131.305">C.IL20.131.305</OPTION>'+
  '<OPTION VALUE="C.TSS0.CB.SITE-97">C.TSS0.CB.SITE-97</OPTION>'+
  '<OPTION VALUE="C.TSS0.SL.GEN-24">C.TSS0.SL.GEN-24</OPTION>'+ 
  '<OPTION VALUE="C.ZSM2.CB.CPS01">C.ZSM2.CB.CPS01</OPTION>'+  
  '<OPTION VALUE="VAI - 1000">VAI - 1000</OPTION>'+  
  '<OPTION VALUE="VAI - 1004">VAI - 1004</OPTION>'+  
  '<OPTION VALUE="VAI - 1105">VAI - 1105</OPTION>'+  
  '<OPTION VALUE="VAI - 1202">VAI - 1202</OPTION>'+  
  '<OPTION VALUE="VAI - 1203">VAI - 1203</OPTION>'+  
  '<OPTION VALUE="VAI - 1215">VAI - 1215</OPTION>'+  
  '<OPTION VALUE="VAI - 1216">VAI - 1216</OPTION>'+  
  '<OPTION VALUE="VAI - 1217">VAI - 1217</OPTION>'+  
  '<OPTION VALUE="VAI - 1218">VAI - 1218</OPTION>'+  
  '<OPTION VALUE="VAI - 1219">VAI - 1219</OPTION>'+  
  '<OPTION VALUE="VAI - 1223">VAI - 1223</OPTION>'+  
  '<OPTION VALUE="VAI - 1230">VAI - 1230</OPTION>'+  
  '<OPTION VALUE="VAI - 1231">VAI - 1231</OPTION>'+  
  '<OPTION VALUE="VAI - 1255">VAI - 1255</OPTION>'+  
  '<OPTION VALUE="VAI - 1269">VAI - 1269</OPTION>'+  
  '<OPTION VALUE="VAI - 1270">VAI - 1270</OPTION>'+  
  '<OPTION VALUE="VAI - 1271">VAI - 1271</OPTION>'+  
  '<OPTION VALUE="VAI - 1272">VAI - 1272</OPTION>'+  
  '<OPTION VALUE="VAI - 1275">VAI - 1275</OPTION>'+  
  '<OPTION VALUE="VAI - 1276">VAI - 1276</OPTION>'+  
  '<OPTION VALUE="VAI - 1278">VAI - 1278</OPTION>'+  
  '<OPTION VALUE="VAI - 1279">VAI - 1279</OPTION>'+  
  '<OPTION VALUE="VAI - 1280">VAI - 1280</OPTION>'+  
  '<OPTION VALUE="VAI - 1281">VAI - 1281</OPTION>'+  
  '<OPTION VALUE="VAI - 1282">VAI - 1282</OPTION>'+  
  '<OPTION VALUE="VAI - 1284">VAI - 1284</OPTION>'+  
  '<OPTION VALUE="VAI - 1285">VAI - 1285</OPTION>'+  
  '<OPTION VALUE="VAI - 1286">VAI - 1286</OPTION>'+  
  '<OPTION VALUE="VAI - 1287">VAI - 1287</OPTION>'+  
  '<OPTION VALUE="VAI - 1290">VAI - 1290</OPTION>'+  
  '<OPTION VALUE="VAI - 1291">VAI - 1291</OPTION>'+  
  '<OPTION VALUE="VAI - 1303">VAI - 1303</OPTION>'+  
  '<OPTION VALUE="VAI - 1305">VAI - 1305</OPTION>'+  
  '<OPTION VALUE="VAI - 1314">VAI - 1314</OPTION>'+  
  '<OPTION VALUE="VAI - 1315">VAI - 1315</OPTION>'+  
  '<OPTION VALUE="VAI - 1319">VAI - 1319</OPTION>'+  
  '<OPTION VALUE="VAI - 1320">VAI - 1320</OPTION>'+  
  '<OPTION VALUE="VAI - 1321">VAI - 1321</OPTION>'+  
  '<OPTION VALUE="VAI - 1324">VAI - 1324</OPTION>'+  
  '<OPTION VALUE="VAI - 1325">VAI - 1325</OPTION>'+ 
  '<OPTION VALUE="VAI - 1326">VAI - 1326</OPTION>'+  
  '<OPTION VALUE="VAI - 1327">VAI - 1327</OPTION>'+  
  '<OPTION VALUE="VAI - 1329">VAI - 1329</OPTION>'+  
  '<OPTION VALUE="VAI - 1333">VAI - 1333</OPTION>'+  
  '<OPTION VALUE="VAI - 1334">VAI - 1334</OPTION>'+ 
  '<OPTION VALUE="VAI - 1335">VAI - 1335</OPTION>'+ 
  '<OPTION VALUE="VAI - 1483">VAI - 1483</OPTION>'+ 
  '<OPTION VALUE="VAI - 1484">VAI - 1484</OPTION>'+ 
  '<OPTION VALUE="VAI - 1490">VAI - 1490</OPTION>'+ 
  '<OPTION VALUE="VAI - 1495">VAI - 1495</OPTION>'+ 
  '<OPTION VALUE="VAI - 1580">VAI - 1580</OPTION>'+ 
  '<OPTION VALUE="VAI - 1581">VAI - 1581</OPTION>'+ 
  '<OPTION VALUE="VAI - 1582">VAI - 1582</OPTION>'+ 
  '<OPTION VALUE="VAI - 1583">VAI - 1583</OPTION>'+ 
  '<OPTION VALUE="VAI - 1699">VAI - 1699</OPTION>'+ 
  '<OPTION VALUE="VAI - 5421">VAI - 5421</OPTION>'+ 
  '<OPTION VALUE="VAI - 5422">VAI - 5422</OPTION>'+ 
  '<OPTION VALUE="VAI - 5423">VAI - 5423</OPTION>'+ 
  '<OPTION VALUE="VAI - 5424">VAI - 5424</OPTION>'+ 
  '<OPTION VALUE="VAI - 5425">VAI - 5425</OPTION>'+ 
  '<OPTION VALUE="VAI - 5426">VAI - 5426</OPTION>'+ 
  '<OPTION VALUE="VAI - 5428">VAI - 5428</OPTION>'+ 
  '<OPTION VALUE="VAI - 5429">VAI - 5429</OPTION>'+ 
  '<OPTION VALUE="VAI - 5430">VAI - 5430</OPTION>'+ 
  '<OPTION VALUE="VAI - 5435">VAI - 5435</OPTION>'+ 
  '<OPTION VALUE="VAI - 7110">VAI - 7110</OPTION>'+ 
  '<OPTION VALUE="VAI - 7111">VAI - 7111</OPTION>'+ 
  '<OPTION VALUE="VAI - 7112">VAI - 7112</OPTION>'+ 
  '<OPTION VALUE="VAI - 7113">VAI - 7113</OPTION>'+ 
  '<OPTION VALUE="VAI - 7114">VAI - 7114</OPTION>'+ 
  '<OPTION VALUE="VAI - 7115">VAI - 7115</OPTION>'+ 
  '<OPTION VALUE="VAI - 7120">VAI - 7120</OPTION>'+ 
  '<OPTION VALUE="VAI - 7121">VAI - 7121</OPTION>'+ 
  '<OPTION VALUE="VAI - 7122">VAI - 7122</OPTION>'+ 
  '<OPTION VALUE="VAI - 7123">VAI - 7123</OPTION>'+ 
  '<OPTION VALUE="VAI - 7124">VAI - 7124</OPTION>'+ 
  '<OPTION VALUE="VAI - 7130">VAI - 7130</OPTION>'+ 
  '<OPTION VALUE="VAI - 7150">VAI - 7150</OPTION>'+ 
  '<OPTION VALUE="VAI - 7210">VAI - 7210</OPTION>'+ 
  '<OPTION VALUE="VAI - 7211">VAI - 7211</OPTION>'+ 
  '<OPTION VALUE="VAI - 7212">VAI - 7212</OPTION>'+ 
  '<OPTION VALUE="VAI - 7213">VAI - 7213</OPTION>'+ 
  '<OPTION VALUE="VAI - 7214">VAI - 7214</OPTION>'+ 
  '<OPTION VALUE="VAI - 7300">VAI - 7300</OPTION>'+ 
  '<OPTION VALUE="VAI - 7312">VAI - 7312</OPTION>'+ 
  '<OPTION VALUE="VAI - 7320">VAI - 7320</OPTION>'+ 
  '<OPTION VALUE="VAI - 7400">VAI - 7400</OPTION>'+ 
  '<OPTION VALUE="VAI - 7430">VAI - 7430</OPTION>'+ 
  '<OPTION VALUE="VAI - 7431">VAI - 7431</OPTION>'+ 
  '<OPTION VALUE="VAI - 7432">VAI - 7432</OPTION>'+ 
  '<OPTION VALUE="VAI - 7433">VAI - 7433</OPTION>'+ 
  '<OPTION VALUE="VAI - 7434">VAI - 7434</OPTION>'+ 
  '<OPTION VALUE="VAI - 7435">VAI - 7435</OPTION>'+ 
  '<OPTION VALUE="VAI - 7436">VAI - 7436</OPTION>'+ 
  '<OPTION VALUE="VAI - 7450">VAI - 7450</OPTION>'+ 
  '<OPTION VALUE="VAI - 7451">VAI - 7451</OPTION>'+ 
  '<OPTION VALUE="VAI - 7452">VAI - 7452</OPTION>'+ 
  '<OPTION VALUE="VAI - 7453">VAI - 7453</OPTION>'+ 
  '<OPTION VALUE="VAI - 7454">VAI - 7454</OPTION>'+ 
  '<OPTION VALUE="VAI - 7460">VAI - 7460</OPTION>'+ 
  '<OPTION VALUE="VAI - 7660">VAI - 7660</OPTION>'+ 
  '<OPTION VALUE="VAI - 7700">VAI - 7700</OPTION>'+ 
  '<OPTION VALUE="VAI - 7710">VAI - 7710</OPTION>'+ 
  '<OPTION VALUE="VAI - 7715">VAI - 7715</OPTION>'+ 
  '<OPTION VALUE="VAI - 7717">VAI - 7717</OPTION>'+ 
  '<OPTION VALUE="VAI - 7718">VAI - 7718</OPTION>'+ 
  '<OPTION VALUE="VAI - 7719">VAI - 7719</OPTION>'+ 
  '<OPTION VALUE="VAI - 7720">VAI - 7720</OPTION>'+ 
  '<OPTION VALUE="VAI - 7723">VAI - 7723</OPTION>'+ 
  '<OPTION VALUE="VAI - 7734">VAI - 7734</OPTION>'+ 
  '<OPTION VALUE="VAI - 7735">VAI - 7735</OPTION>'+ 
  '<OPTION VALUE="VAI - 7740">VAI - 7740</OPTION>'+ 
  '<OPTION VALUE="VAI - 7741">VAI - 7741</OPTION>'+ 
  '<OPTION VALUE="VAI - 7742">VAI - 7742</OPTION>'+ 
  '<OPTION VALUE="VAI - 7743">VAI - 7743</OPTION>'+ 
  '<OPTION VALUE="VAI - 7744">VAI - 7744</OPTION>'+ 
  '<OPTION VALUE="VAI - 7745">VAI - 7745</OPTION>'+ 
  '<OPTION VALUE="VAI - 7746">VAI - 7746</OPTION>'+ 
  '<OPTION VALUE="VAI - 7750">VAI - 7750</OPTION>'+ 
  '<OPTION VALUE="VAI - 7751">VAI - 7751</OPTION>'+ 
  '<OPTION VALUE="VAI - 7764">VAI - 7764</OPTION>'+ 
  '<OPTION VALUE="VAI - 7766">VAI - 7766</OPTION>'+ 
  '<OPTION VALUE="VAI - 7770">VAI - 7770</OPTION>'+ 
  '<OPTION VALUE="VAI - 7771">VAI - 7771</OPTION>'+ 
  '<OPTION VALUE="VAI - 7772">VAI - 7772</OPTION>'+ 
  '<OPTION VALUE="VAI - 7778">VAI - 7778</OPTION>'+ 
  '<OPTION VALUE="VAI - 7779">VAI - 7779</OPTION>'+ 
  '<OPTION VALUE="VAI - 7780">VAI - 7780</OPTION>'+ 
  '<OPTION VALUE="VAI - 7782">VAI - 7782</OPTION>'+ 
  '<OPTION VALUE="VAI - 7784">VAI - 7784</OPTION>'+ 
  '<OPTION VALUE="VAI - 7785">VAI - 7785</OPTION>'+ 
  '<OPTION VALUE="VAI - 7788">VAI - 7788</OPTION>'+ 
  '<OPTION VALUE="VAI - 7839">VAI - 7839</OPTION>'+ 
  '<OPTION VALUE="VAI - 7845">VAI - 7845</OPTION>'+ 
  '<OPTION VALUE="VAI - 7846">VAI - 7846</OPTION>'+ 
  '<OPTION VALUE="VAI - 7847">VAI - 7847</OPTION>'+ 
  '<OPTION VALUE="VAI - 7848">VAI - 7848</OPTION>'+ 
  '<OPTION VALUE="VAI - 7849">VAI - 7849</OPTION>'+ 
  '<OPTION VALUE="VAI - 7850">VAI - 7850</OPTION>'+ 
  '<OPTION VALUE="VAI - 7870">VAI - 7870</OPTION>'+ 
  '<OPTION VALUE="VAI - 7871">VAI - 7871</OPTION>'+ 
  '<OPTION VALUE="VAI - 7875">VAI - 7875</OPTION>'+ 
  '<OPTION VALUE="VAI - 7876">VAI - 7876</OPTION>'+ 
  '<OPTION VALUE="VAI - 7877">VAI - 7877</OPTION>'+ 
  '<OPTION VALUE="VAI - 7878">VAI - 7878</OPTION>'+ 
  '<OPTION VALUE="VAI - 900637.110.SO">VAI - 900637.110.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - 9801368801/10003100">VAI - 9801368801/10003100</OPTION>'+ 
  '<OPTION VALUE="VAI - B.809953">VAI - B.809953</OPTION>'+ 
  '<OPTION VALUE="VAI - C.0250.KC0.CS030">VAI - C.0250.KC0.CS030</OPTION>'+ 
  '<OPTION VALUE="VAI - C.0760.KC33.051.41">VAI - C.0760.KC33.051.41</OPTION>'+ 
  '<OPTION VALUE="VAI - C.0C91.IH.054">VAI - C.0C91.IH.054</OPTION>'+ 
  '<OPTION VALUE="VAI - C.0EE1.CB.054">VAI - C.0EE1.CB.054</OPTION>'+ 
  '<OPTION VALUE="VAI - C.1010328560.33000100">VAI - C.1010328560.33000100</OPTION>'+ 
  '<OPTION VALUE="VAI - C.1016448914.12000100">VAI - C.1016448914.12000100</OPTION>'+ 
  '<OPTION VALUE="VAI - C.1029168911.11200100">VAI - C.1029168911.11200100</OPTION>'+ 
  '<OPTION VALUE="VAI - C.1031688560.63100100">VAI - C.1031688560.63100100</OPTION>'+ 
  '<OPTION VALUE="VAI - C.16C0.RD.0.CH010">VAI - C.16C0.RD.0.CH010</OPTION>'+ 
  '<OPTION VALUE="VAI - C.16C0.RD.0.CS030">VAI - C.16C0.RD.0.CS030</OPTION>'+ 
  '<OPTION VALUE="VAI - C.1C40.SE.0.BRAND">VAI - C.1C40.SE.0.BRAND</OPTION>'+ 
  '<OPTION VALUE="VAI - C.36F0.CB.304">VAI - C.36F0.CB.304</OPTION>'+ 
  '<OPTION VALUE="VAI - C.4892.SL.0.CH030">VAI - C.4892.SL.0.CH030</OPTION>'+ 
  '<OPTION VALUE="VAI - C.70D0.SLXA015/UR1">VAI - C.70D0.SLXA015/UR1</OPTION>'+ 
  '<OPTION VALUE="VAI - C.70D0.SLXA024/EB2">VAI - C.70D0.SLXA024/EB2</OPTION>'+ 
  '<OPTION VALUE="VAI - C.70D0.SLXA54">VAI - C.70D0.SLXA54</OPTION>'+ 
  '<OPTION VALUE="VAI - C.77C0.KCS2.01.81">VAI - C.77C0.KCS2.01.81</OPTION>'+ 
  '<OPTION VALUE="VAI - C.90A0.WC.BPK">VAI - C.90A0.WC.BPK</OPTION>'+   
  '<OPTION VALUE="VAI - C.BCX0.121.SL21.FE">VAI - C.BCX0.121.SL21.FE</OPTION>'+ 
  '<OPTION VALUE="VAI - C.CSZ0.312.9115">VAI - C.CSZ0.312.9115</OPTION>'+   
  '<OPTION VALUE="VAI - C.IL20.131.500">VAI - C.IL20.131.500</OPTION>'+ 
  '<OPTION VALUE="VAI - C.IPH0.WC.0.CS030">VAI - C.IPH0.WC.0.CS030</OPTION>'+  
  '<OPTION VALUE="VAI - C.MCL0.KC54.05/IL9">VAI - C.MCL0.KC54.05/IL9</OPTION>'+ 
  '<OPTION VALUE="VAI - C.SEV0.312.11000100">VAI - C.SEV0.312.11000100</OPTION>'+  
  '<OPTION VALUE="VAI - C.TAC0.121">VAI - C.TAC0.121</OPTION>'+ 
  '<OPTION VALUE="VAI - C.WUH0.131.600">VAI - C.WUH0.131.600</OPTION>'+ 
  '<OPTION VALUE="VAI - D.351153.198.ALL">VAI - D.351153.198.ALL</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.132">VAI - D.352009.132</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.133">VAI - D.352009.133</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.134">VAI - D.352009.134</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.135">VAI - D.352009.135</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.137">VAI - D.352009.137</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.138">VAI - D.352009.138</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.139">VAI - D.352009.139</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.140">VAI - D.352009.140</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.141">VAI - D.352009.141</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.145">VAI - D.352009.145</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.146">VAI - D.352009.146</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.147">VAI - D.352009.147</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.148">VAI - D.352009.148</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.149">VAI - D.352009.149</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.153">VAI - D.352009.153</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.154">VAI - D.352009.154</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.155">VAI - D.352009.155</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.159">VAI - D.352009.159</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.160">VAI - D.352009.160</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.161">VAI - D.352009.161</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.162">VAI - D.352009.162</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.163">VAI - D.352009.163</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.164">VAI - D.352009.164</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.165">VAI - D.352009.165</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.166">VAI - D.352009.166</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.168">VAI - D.352009.168</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.169">VAI - D.352009.169</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.170">VAI - D.352009.170</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.172">VAI - D.352009.172</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.177">VAI - D.352009.177</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.179">VAI - D.352009.179</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.191">VAI - D.352009.191</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.192">VAI - D.352009.192</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.199">VAI - D.352009.199</OPTION>'+ 
  '<OPTION VALUE="VAI - D.352009.200">VAI - D.352009.200</OPTION>'+ 
  '<OPTION VALUE="VAI - I.0715037200.10001100">VAI - I.0715037200.10001100</OPTION>'+ 
  '<OPTION VALUE="VAI - I.9002284300.11000100">VAI - I.9002284300.11000100</OPTION>'+ 
  '<OPTION VALUE="VAI - I.900637.298.SO">VAI - I.900637.298.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - I.900679.410.1">VAI - I.900679.410.1</OPTION>'+ 
  '<OPTION VALUE="VAI - I.900691.110.SO">VAI - I.900691.110.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - I.900691.240.SO">VAI - I.900691.240.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - I.900691.300">VAI - I.900691.300</OPTION>'+ 
  '<OPTION VALUE="VAI - I.900691.410.9">VAI - I.900691.410.9</OPTION>'+ 
  '<OPTION VALUE="VAI - I.9800158886.18886100">VAI - I.9800158886.18886100</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980210.02">VAI - I.980210.02</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980234.RK">VAI - I.980234.RK</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980234.SO">VAI - I.980234.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980253.01">VAI - I.980253.01</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980254.01">VAI - I.980254.01</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980254G">VAI - I.980254G</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980273.CON">VAI - I.980273.CON</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980278.14.AII">VAI - I.980278.14.AII</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980278.14.SO">VAI - I.980278.14.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980278.14.STHS">VAI - I.980278.14.STHS</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980278.20.AII">VAI - I.980278.20.AII</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980278.20.SO">VAI - I.980278.20.SO</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980278.20.STHS">VAI - I.980278.20.STHS</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980279.1.EX">VAI - I.980279.1.EX</OPTION>'+ 
  '<OPTION VALUE="VAI - I.980279.2">VAI - I.980279.2</OPTION>'+ 
  '<OPTION VALUE="VAI - T.5001448914.19904100">VAI - T.5001448914.19904100</OPTION>'+ 
  '<OPTION VALUE="VAI - U.MSC0.SPM08">VAI - U.MSC0.SPM08</OPTION>'+  
  '</SELECT></td>'+
  '<th></th>'+
  '<td><button style="width:120" disabled name="btnVAIKST2" onClick="Such(\'VAIKST2\')">Aktualisieren</button></td>'+
  '</tr>'+
  '</table></form>'
}

function EnableVAIKST2()
{
   document.form15.btnVAIKST2.disabled=false;
   Such("VAIKST");
}

function AendAuswVAIKST(kostenart)
{
 // do something
}

/* Homisin, 28.07.2009:
   Da immer der erste des aktuellen Verrechnungsmonat vorgegeben wird, soll
   das Programm das aktuelle Monat und den 1. vorgeben.
   Im Falle der Eingabe bis zum 5. eines Monates, wird immer voriges Monat angezeigt.
*/
function GetActualValidDateFrom()
{
  var currentDate = new Date()
  var day = currentDate.getDate()
  var month = currentDate.getMonth() + 1 //JavaScript beginnt von 0 = Januar
  var year = currentDate.getFullYear()
  
  if(day >=1 && day < 5) month--
  
// 3.1.2011, Hronec, Valo, Korrektur, falsche Berechnung im J�nner	 
  if (month == 0) {
    month = 12
    year = year - 1	
  }	
// 3.1.2011 end 

  if(month < 10) month = "0" + month  
  
  return "01." + month + "." + year
}

function GetActualValidDateTo(LeistungsArtTyp)
{
  if(LeistungsArtTyp == "SM")
  {
  	return "31.12.2999";    
  }
  else
  {	  
	var currentDate = new Date()
	var day = currentDate.getDate()
	var month = currentDate.getMonth() + 1 //JavaScript beginnt von 0 = Januar
	var year = currentDate.getFullYear()
	  
	if(day >= 5) month++
	
// 3.1.2011, Hronec, Valo, Korrektur, falsche Berechnung im Dezember	
        if (month == 13) {
          month = 1
          year = year + 1	
        }
// 3.1.2011 end  
	
	if(month < 10) month = "0" + month  
	
	return "04." + month + "." + year
  }
}

function SetActualValidDateTo()
{
  LeistungsArtTyp = document.form16.Typ.value;
  DefaultDateTo = GetActualValidDateTo(LeistungsArtTyp);
  
  if(LeistungsArtTyp == "SM")
  {
  	document.form16.Gueltigbis.value = DefaultDateTo;
  	document.form16.Gueltigbis.readOnly = false;
  }
  else
  {	  
  	document.form16.Gueltigbis.value = DefaultDateTo;
	document.form16.Gueltigbis.readOnly = true;
  }
} 


function IniAuswVAIERF()
{
  //Leistungsarten erfassen
  AuswVAIERF.innerHTML= ''+
  '<form NAME="form16">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="70"><col WIDTH="75"><col WIDTH="95"><col WIDTH="120"><col WIDTH="35">'+
  '<col WIDTH="110"><col WIDTH="70"><col WIDTH="80"><col WIDTH="35"><col WIDTH="50"><col WIDTH="15"><col WIDTH="120">'+
  '<tr height="14">'+
  '<th colspan="6">&nbsp;</th>'+
  '</tr>'+  
      
  '<tr colspan="12">'+  
  //statt einer Combobox, nur VAI
  //'<th>Firma&nbsp;&nbsp;</th>'+
  //'<td colspan="1"><SELECT name="Firma">'+
  //'<OPTION VALUE="ALLE">Alle</OPTION>'+   
  //'<OPTION VALUE="VAI">VAI</OPTION>'+
  //'</SELECT></td>'+  Leistungsart
  '<th>Firma&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Firma" maxlength="80" size="12" VALUE="SIEMENS VAI MT"></td>'+  
  '<th>Leistungsart&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Leistungsart" maxlength="30" size="15" VALUE=""></td>'+
  '<th>GNS&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="GNS" maxlength="80" size="15" VALUE=""></td>'+
  '<th>Gueltigab&nbsp;&nbsp;</th>'+
  // Monat jeden Monatsersten aktualisieren, Wunsch des Kunden 
  '<td><input oncontextmenu="fnLoad(this)" NAME="Gueltigab" maxlength="10" size="10" VALUE="'+ GetActualValidDateFrom() +'" ></td>'+ 
  '<td colspan="3"><b>&nbsp;mehrere GNS&nbsp;</b><INPUT TYPE=CHECKBOX NAME="dispPOOL" value="Alle"></td>'+
  '<td colspan="1"><b>&nbsp;&nbsp;&nbsp;mehrere KST&nbsp;</b><INPUT TYPE=CHECKBOX NAME="dispPOOLKST" value="Alle"></td>'+
  '</tr>'+

  '<tr colspan="12">'+  
  '<th>Betrag&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Betrag" maxlength="14" size="12" VALUE=""></td>'+  
  '<th>Bezeichnung&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Bezeichnung" maxlength="50" size="15" VALUE=""></td>'+    
  '<th>KST&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KST" maxlength="30" size="15" VALUE=""></td>'+ 
  '<th>Gueltigbis&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Gueltigbis" maxlength="10" size="10" readOnly="true" VALUE="'+ GetActualValidDateTo("EG") +'"></td>'+ 
  '<th>Typ&nbsp;&nbsp;</th>'+
  //SM: Standardverrechnung monatlich  (werden immer bei "Leistungsarten pflegen" aufgelistet und nicht aus der Leistungsartenliste gel�scht)
  //SE: Standardverrechnung einmalig   (werden immer bei "Leistungsarten pflegen" aufgelistet und nicht aus der Leistungsartenliste gel�scht)
  //EG: Einzelverrechnung Ger�t        (werden nach der mtl. Abrechnung aus der Leistungsartenliste gel�scht)
  //EK: Einzelverrechnung Kostenstelle (werden nach der mtl. Abrechnung aus der Leistungsartenliste gel�scht)
  '<td colspan="1"><SELECT name="Typ" onChange="javascript:SetActualValidDateTo();">'+
  '<OPTION VALUE="EG">EG</OPTION>'+ 
  '<OPTION VALUE="EK">EK</OPTION>'+  
  '<OPTION VALUE="SM">SM</OPTION>'+
  '</SELECT></td>'+  
  '<th></th>'+
  '<td><button style="width:120" onClick="Such(\'VAIERF\')">Erfassen</button></td>'+      
  '</tr>'+
   
  '<tr colspan="6">'+ 
  '<th>Anzahl&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KOARTANZ" maxlength="4" size="4" VALUE="1"></td>'+
  '<th>Leistungsart&nbsp;&nbsp;</th>'+
  '<td colspan="6"><span id="SELLeistungsarten3" style="display:none"></span></td>'+ 
  '<td></td>'+
  '</tr>'+  
   
  '</table></form>'
}
function IniAuswVAIAEN()
{
  AuswVAIAEN.innerHTML= ''+
  '<form NAME="form17">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="70"><col WIDTH="75"><col WIDTH="80"><col WIDTH="100"><col WIDTH="45"><col WIDTH="110"><col WIDTH="70"><col WIDTH="80"><col WIDTH="60"><col WIDTH="50"><col WIDTH="15"><col WIDTH="120">'+
  '<tr height="14">'+
  '<th colspan="6">&nbsp;</th>'+
  '</tr>'+  
      
  '<tr colspan="10">'+  
  //statt einer Combobox, nur VAI
  //'<th>Firma&nbsp;&nbsp;</th>'+
  //'<td colspan="1"><SELECT name="Firma">'+
  //'<OPTION VALUE="ALLE">Alle</OPTION>'+   
  //'<OPTION VALUE="VAI">VAI</OPTION>'+
  //'</SELECT></td>'+  
  '<th>Firma&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Firma" maxlength="50" size="14" VALUE="SIEMENS VAI MT"></td>'+  
  '<th>Leistungsart&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Leistungsart" maxlength="50" size="15"></td>'+
  '<th>Gueltigab&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Gueltigab" maxlength="10" size="10" VALUE="01.01.2007"></td>'+ 
  '<th>VerrKz&nbsp;&nbsp;</th>'+
  '<td colspan="1"><SELECT name="VerrKz">'+
  '<OPTION VALUE="J">J</OPTION>'+
  '</SELECT></td>'+
  '<th></th>'+
  '<td><button style="width:120" onClick="Such(\'VAIERF\')">Aendern</button></td>'+
  '</tr>'+

  '<tr colspan="12">'+  
  '<th>Betrag&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Betrag" maxlength="14" size="8" VALUE="0"></td>'+  
  '<th>Bezeichnung&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Bezeichnung" maxlength="50" size="15"></td>'+    
  '<th>KST&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="KST" maxlength="30" size="15" VALUE="0"></td>'+ 
  '<th>Gueltigbis&nbsp;&nbsp;</th>'+
  '<td><input oncontextmenu="fnLoad(this)" NAME="Gueltigbis" maxlength="10" size="10" VALUE="31.12.2999"></td>'+ 
  '<th>Typ&nbsp;&nbsp;</th>'+
  '<td colspan="1"><SELECT name="Typ">'+
  '<OPTION VALUE="EG">EG</OPTION>'+   
  '<OPTION VALUE="EK">EK</OPTION>'+
  '</SELECT></td>'+        
  '</tr>'+  
  '</table></form>'
}

function IniAuswVAIMON()
{
  AuswVAIMON.innerHTML=''+
  '<form NAME="form18">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="5">'+
  '<tr height="14">'+
  '<th colspan="1">&nbsp;</th>'+
  '</tr>'+      
  '<tr colspan="1">'+
  '<th>&nbsp;</th>'+
  '<td><button style="width:220" name="btnVAIMON" onClick="Such(\'VAIMON\')">Reaktivierungslauf starten</button></td>'+
  '</tr>'+ 
  '</table></form>'
}

function highlight(x,y)
  {
  document.forms[x].elements[y].focus()
  document.forms[x].elements[y].select()
  }

function clipcopy(x,y)
  {
  document.forms[x].elements[y].focus()
  document.forms[x].elements[y].select()
  document.forms[x].elements[y].createTextRange().execCommand("Copy")
  }
