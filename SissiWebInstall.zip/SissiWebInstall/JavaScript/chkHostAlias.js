function chkHostAlias(n,ip,ParkID,DienstArt,DNSName,DNSBemerkung)
// Sept. 2010; KMS 500133; Parameter erweitert um ParkID
// function chkHostAlias(n,ip,DienstArt,DNSName,DNSBemerkung)
{
  var s,was
  var underline=false
  if(DienstArt==2)
  { 
    s='-1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    was='Hostname'
  }
  else
  {
    s='_-1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    was='Aliasname'
  }  
  if(n=='') {alert('kein '+was+' angegeben'); return false}
  if('1234567890'.indexOf(n.substring(0,1))>-1) 
   {alert(was+' darf nicht mit Ziffer beginnen'); return false}
  for(var i=1; i< n.length;i++)
  {
    if(s.indexOf(n.substring(i,i+1))<0) 
    {
      if(n.substring(i,i+1)=='_')
      {
        underline=true
      }
      else
      {
        alert('Nicht erlaubtes Zeichen in '+was); 
        return false
      }  
    }
  }
  if(underline)
  {
    if(!confirm('Underline ist eigentlich nicht mehr zul�ssig\n\n'+
                'Wollen Sie trotzdem diesen Hostnamen verwenden?'))
    {
      return false
    }    
  } 
              
  var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  xmlhttp.Open("POST", "../ASP/chkHostAlias.asp", false);
  xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')

  // Sept. 2010; KMS 500133; Aufruf erweitert um ParkID
  xmlhttp.Send('n='+n+'&ip='+ip+'&ParkID='+ParkID+'&Dienstart='+DienstArt+'&DNSName='+DNSName)  
//xmlhttp.Send('n='+n+'&ip='+ip+'&Dienstart='+DienstArt+'&DNSName='+DNSName)

  if(xmlhttp.responseText!='OK') 
  {
    if(xmlhttp.responseText.substring(0,5)=='Frage')
    {
      if(confirm(xmlhttp.responseText.substring(5,100)+'\n\n'+
        'Wollen Sie trotzdem diesen Hostnamen verwenden?'))
      {
        return true
      }
      else
      {
        return false
      } 
    }
    else
    {
      alert(xmlhttp.responseText)
      return false
    }
  }
  else
  {
    if(DienstArt==3 && DNSBemerkung!='W2K=0' )
    {     
      var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
      xmlhttp.Open("POST","../PingLookup/NSLookup.asp?Alias="+n+"&Domain="+DNSName,false)
      xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;')
      xmlhttp.Send('<?xml version="1.0" ?>')
//alert(xmlhttp.responseText)      
      if(xmlhttp.responseText=='gefunden')
      { 
        if(confirm('Host oder Alias schon in DNS eingetragen (nslookup ' + n + '.' + DNSName+')\n\n'+
            'Wollen Sie trotzdem diesen Alias verwenden?'))
        {
          return true
        }
        else
        {
          return false
        }
      }
      else return true  
    } 
    else return true
  }  
}
