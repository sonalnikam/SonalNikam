logIP=false;
logIL=false;
logVA=false;
logUE=false;
logAU=false;
logVF=false;
logPV=false;
Werner=false;
AusscheidungSTO="";

PersKey=0;
AenPersKey=0;
ASPIDKey=0;

// WebShop
WSgnsnr='';
WSequip='';
WSorder='';
WSgid  ='';

/**/
WSsto = '';
WSobj = '';
WSGsh = '';
WSRau = '';
WSfic = '';
WSngd = '';

// WebShop

DiaStrHo="dialogHeight:330px;dialogWidth:360px;"+
         "dialogLeft:340;dialogTop:330;help:No;resizable:No;status:No;scroll:no"
DiaDetail="dialogHeight:630px;dialogWidth:300px;"+
         "dialogLeft:340;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
DiaStat="dialogHeight:350px;dialogWidth:280px;"+
         "dialogLeft:290;dialogTop:100;help:No;resizable:No;status:No;scroll:no"

//function dummy is used to set the timeout for the variable clockTimeoutID
function dummy(){;}

function Such(n)
{
  var noInput=false
  switch(n)
  {
    case 'IPGeraet': {
                      if(form1.IPNummer.value.length>0)  fnSave(form1.IPNummer);
                      if(form1.Equipment.value.length>0) fnSave(form1.Equipment);
                      if(form1.Inventar.value.length>0)  fnSave(form1.Inventar);
                      if(form1.HostAlias.value.length>0) fnSave(form1.HostAlias);
                      if(form1.GNS.value.length>0)       fnSave(form1.GNS);
                      if(form1.Stru.value.length>0)      fnSave(form1.Stru);
                      if(form1.MAC.value.length>0)       fnSave(form1.MAC);
                      noInput=(form1.IPNummer.value+form1.Inventar.value+form1.Equipment.value+
                      form1.HostAlias.value+form1.GNS.value+form1.MAC.value+form1.Stru.value).length<3;
                      break;
                     }
    case 'IPPers':   {
                      if(form2.Name.value.length>0)         fnSave(form2.Name);
                      if(form2.Vorname.value.length>0)      fnSave(form2.Vorname);
                      if(form2.Persnr.value.length>0)       fnSave(form2.Persnr);
                      if(form2.KST.value.length>0)          fnSave(form2.KST);
                      if(form2.BS2000.value.length>0)       fnSave(form2.BS2000);
                      if(form2.Druckershare.value.length>0) fnSave(form2.Druckershare);

                      noInput=(form2.Name.value+form2.Vorname.value+form2.Persnr.value+
                      form2.KST.value.length+form2.BS2000.value.length+
                      form2.Druckershare.value.length)<3;
                      break;
                     }
    case 'ILPers':   {
                      if(form3.Name.value.length>0)      fnSave(form3.Name);
                      if(form3.Vorname.value.length>0)   fnSave(form3.Vorname);
                      if(form3.Abteilung.value.length>0) fnSave(form3.Abteilung);
                      if(form3.Persnr.value.length>0)    fnSave(form3.Persnr);
                      if(form3.KST.value.length>0)       fnSave(form3.KST);
                      break;
                     }
    case 'ILGeraet': {
                      if(form4.STO.value.length>0)             fnSave(form4.STO);
                      if(form4.Raum.value.length>0)            fnSave(form4.Raum);
                      if(form4.Betriebsbereich.value.length>0) fnSave(form4.Betriebsbereich);
                      if(form4.KSTVerr.value.length>0)         fnSave(form4.KSTVerr);
                      if(form4.KSTBesitz.value.length>0)       fnSave(form4.KSTBesitz);
                      break;
                      }
    case 'W2KGeraet':{
                       noInput=(form5.IPNummer.value+form5.Equipment.value+
                                form5.Inventar.value+form5.HostAlias.value+
                                form5.GNS.value).length<1
                       break}
    case 'W2KMassenSuche':{
                            noInput=(form6.STO.value+form6.Raum.value+
                                     form6.KSTVerr.value+
                                     form6.Betriebsbereich.value+
                                     form6.Name.value+form6.Vorname.value+
                                     form6.Abteilung.value+
                                     form6.KSTBenutzer.value+
                                     form6.KSTBesitz.value).length<1
                            break;
                          }
    case 'Uebersiedeln': {
                            noInput=(form8.STO.value+form8.Raum.value+
                                     form8.KSTVerr.value+
                                     form8.Betriebsbereich.value+
                                     form8.Name.value+form8.Vorname.value+
                                     form8.Abteilung.value+
                                     form8.KSTBenutzer.value+
                                     form8.GNS.value).length<1
                            break;
                         }
     case 'IPGeraet': {
                        if(form11.IPNummer.value.length>0)  fnSave(form11.IPNummer);
                        if(form11.Equipment.value.length>0) fnSave(form11.Equipment);
                        if(form11.Inventar.value.length>0)  fnSave(form11.Inventar);
                        if(form11.HostAlias.value.length>0) fnSave(form11.HostAlias);
                        if(form11.GNS.value.length>0)       fnSave(form11.GNS);
                        if(form11.Stru.value.length>0)      fnSave(form11.Stru);
                        if(form11.MAC.value.length>0)       fnSave(form11.MAC);
                        noInput=(form11.IPNummer.value+form11.Inventar.value+form11.Equipment.value+
                        form1.HostAlias.value+form11.GNS.value+form1.MAC.value+form11.Stru.value).length<3;
                        break;
                      }
    case 'IPPers':    {
                        if(form12.Name.value.length>0)         fnSave(form12.Name);
                        if(form12.Vorname.value.length>0)      fnSave(form12.Vorname);
                        if(form12.Persnr.value.length>0)       fnSave(form12.Persnr);
                        if(form12.KST.value.length>0)          fnSave(form12.KST);
                        if(form12.BS2000.value.length>0)       fnSave(form12.BS2000);
                        if(form12.Druckershare.value.length>0) fnSave(form12.Druckershare);
                        noInput=(form12.Name.value+form12.Vorname.value+form12.Persnr.value+
                        form12.KST.value.length+form12.BS2000.value.length+
                        form12.Druckershare.value.length)<3;
                        break;
                     }
    case 'WSGeraet': {
                       noInput=(form11.IPNummer.value+form11.Equipment.value+
                                form11.Inventar.value+form11.HostAlias.value+
                                form11.GNS.value).length<1;
                       break;
                    }
    case 'WSPers':  {
                      noInput=(form12.STO.value+form12.Raum.value+
                               form12.KSTVerr.value+
                               form12.Betriebsbereich.value+
                               form12.Name.value+form12.Vorname.value+
                               form12.Abteilung.value+
                               form12.KSTBenutzer.value+
                               form12.KSTBesitz.value).length<1;
                      break;
                    }
    case 'VAIKOA':  {
                      if(form13.Firma.value.length>0) fnSave(form13.Firma);
                      if(form13.KOAKZ.value.length>0) fnSave(form13.KOAKZ);
                      noInput=(form13.Firma.value+form13.KOAKZ.value).length<1;
                      break;
                    }
    case 'VAIABR1': {
                      if(form14.Firma.value.length>0) fnSave(form14.Firma);
                      if(form14.KOAKZ.value.length>0) fnSave(form14.KOAKZ);
                      if(form14.KST.value.length>0) fnSave(form14.KST);
                      if(form14.GNS.value.length>0) fnSave(form14.GNS);
                      if(form14.EQUINR.value.length>0) fnSave(form14.EQUINR);
                      if(form14.VONJAHR.value.length>0) fnSave(form14.VONJAHR);
                      if(form14.VONMONAT.value.length>0) fnSave(form14.VONMONAT);
                      if(form14.BISJAHR.value.length>0) fnSave(form14.BISJAHR);
                      if(form14.BISMONAT.value.length>0) fnSave(form14.BISMONAT);  
                      noInput=(form14.Firma.value+form14.KOAKZ.value+form14.GNS.value+form14.EQUINR.value).length<3;
                      form14.ExcelStatus.value="Akt";
                      break;
                    }
    case 'VAIABR2': {
                      if(form14.Firma.value.length>0) fnSave(form14.Firma);
                      if(form14.KOAKZ.value.length>0) fnSave(form14.KOAKZ);
                      if(form14.KST.value.length>0) fnSave(form14.KST);
                      if(form14.GNS.value.length>0) fnSave(form14.GNS);
                      if(form14.EQUINR.value.length>0) fnSave(form14.EQUINR);
                      if(form14.VONJAHR.value.length>0) fnSave(form14.VONJAHR);
                      if(form14.VONMONAT.value.length>0) fnSave(form14.VONMONAT);
                      if(form14.BISJAHR.value.length>0) fnSave(form14.BISJAHR);
                      if(form14.BISMONAT.value.length>0) fnSave(form14.BISMONAT);  
                      noInput=(form14.Firma.value+form14.KOAKZ.value+form14.GNS.value+form14.EQUINR.value).length<3;
                      form14.ExcelStatus.value="Histo";
                      break;
                    } 
    case 'VAIABR3': {
                      if(form14.Firma.value.length>0) fnSave(form14.Firma);
                      if(form14.KOAKZ.value.length>0) fnSave(form14.KOAKZ);
                      if(form14.KST.value.length>0) fnSave(form14.KST);
                      if(form14.GNS.value.length>0) fnSave(form14.GNS);
                      if(form14.EQUINR.value.length>0) fnSave(form14.EQUINR);
                      if(form14.VONJAHR.value.length>0) fnSave(form14.VONJAHR);
                      if(form14.VONMONAT.value.length>0) fnSave(form14.VONMONAT);
                      if(form14.BISJAHR.value.length>0) fnSave(form14.BISJAHR);
                      if(form14.BISMONAT.value.length>0) fnSave(form14.BISMONAT);  
                      noInput=(form14.Firma.value+form14.KOAKZ.value+form14.GNS.value+form14.EQUINR.value).length<3;
                      break;
                    } 
    case 'VAIABR4': {
                      if(form14.Firma.value.length>0) fnSave(form14.Firma);
                      if(form14.KOAKZ.value.length>0) fnSave(form14.KOAKZ);
                      if(form14.KST.value.length>0) fnSave(form14.KST);
                      if(form14.GNS.value.length>0) fnSave(form14.GNS);
                      if(form14.EQUINR.value.length>0) fnSave(form14.EQUINR);
                      if(form14.VONJAHR.value.length>0) fnSave(form14.VONJAHR);
                      if(form14.VONMONAT.value.length>0) fnSave(form14.VONMONAT);
                      if(form14.BISJAHR.value.length>0) fnSave(form14.BISJAHR);
                      if(form14.BISMONAT.value.length>0) fnSave(form14.BISMONAT);  
                      noInput=(form14.Firma.value+form14.KOAKZ.value+form14.GNS.value+form14.EQUINR.value).length<3;
                      break;
                    }
    case 'VAIABR5': {
                      if(form14.Firma.value.length>0) fnSave(form14.Firma);
                      if(form14.KOAKZ.value.length>0) fnSave(form14.KOAKZ);
                      if(form14.KST.value.length>0) fnSave(form14.KST);
                      if(form14.GNS.value.length>0) fnSave(form14.GNS);
                      if(form14.EQUINR.value.length>0) fnSave(form14.EQUINR);
                      if(form14.VONJAHR.value.length>0) fnSave(form14.VONJAHR);
                      if(form14.VONMONAT.value.length>0) fnSave(form14.VONMONAT);
                      if(form14.BISJAHR.value.length>0) fnSave(form14.BISJAHR);
                      if(form14.BISMONAT.value.length>0) fnSave(form14.BISMONAT);  
                      noInput=(form14.Firma.value+form14.KOAKZ.value+form14.GNS.value+form14.EQUINR.value).length<3;
                      // vielleicht: form14.ExcelStatus.value="Akt";
                      break;
                    }
    case 'VAIKST':  {  
                      if(form15.Firma.value.length>0) fnSave(form15.Firma);
                      if(form15.BereichKZ.value.length>0) fnSave(form15.BereichKZ);
                      if(form15.KSTalt.value.length>0) fnSave(form15.KSTalt);
                      if(form15.KSTneu.value.length>0) fnSave(form15.KSTneu);
                      noInput=(form15.Firma.value+form15.BereichKZ.value+form15.KSTalt.value+form15.KSTneu.value).length<3;
                      break;
                    }
    case 'VAIKST2': {  
                      if(form15.Firma.value.length>0) fnSave(form15.Firma);
                      if(form15.BereichKZ.value.length>0) fnSave(form15.BereichKZ);
                      if(form15.KSTalt.value.length>0) fnSave(form15.KSTalt);
                      if(form15.KSTneu.value.length>0) fnSave(form15.KSTneu);
                      noInput=(form15.Firma.value+form15.BereichKZ.value+form15.KSTalt.value+form15.KSTneu.value).length<3;
                      break;
                    }
    case 'VAIERF':  { 
                      if(form16.Firma.value.length>0) fnSave(form16.Firma);
                      if(form16.Leistungsart.value.length>0) fnSave(form16.Leistungsart);
                      if(form16.GNS.value.length>0) fnSave(form16.GNS);
                      if(form16.Gueltigab.value.length>0) fnSave(form16.Gueltigab);
                      if(form16.Betrag.value.length>0) fnSave(form16.Betrag);
                      if(form16.Bezeichnung.value.length>0) fnSave(form16.Bezeichnung);
                      if(form16.KST.value.length>0) fnSave(form16.KST);
                      if(form16.Gueltigbis.value.length>0) fnSave(form16.Gueltigbis);
                      if(form16.Typ.value.length>0) fnSave(form16.Typ);
                      if(form16.KOARTANZ.value.length>0) fnSave(form16.KOARTANZ);
                      noInput=(form16.Firma.value+form16.Leistungsart.value+form16.GNS.value+form16.Betrag.value+form16.Bezeichnung.value+form16.KST.value).length<3;
                      break;
                    }          
  } //switch(n)

  if(noInput) 
  {
     alert('keine g�ltige Eingabe');
  }
  else
  {
    if (n=='IPFehler1' || n=='IPFehler2')
    {
       top.lastIPSuche='IPFehler';
    }
    else 
    {
       top.lastIPSuche=n;
    }
       
    switch(n)
    {
      case 'IPGeraet' : 
      case 'IPFehler1': 
      case 'IPFehler2': 
      case 'IPFehler3': 
      case 'IPFehler4': 
      case 'IPPers'   : {clockTimeoutID=setTimeout("top.LoadGBaum('"+n+"')",100,"JavaScript");break;}
      case 'ILPers'   : {clockTimeoutID=setTimeout("top.LoadInventarListe('"+n+"')",100,"JavaScript");break;}
      case 'ILGeraet' : {clockTimeoutID=setTimeout("top.LoadInventarListe('"+n+"')",100,"JavaScript");break;}
      case 'W2KGeraet': {clockTimeoutID=setTimeout("top.LoadW2KListe('"+n+"')",100,"JavaScript");break;}
      case 'W2KMassenSuche': {clockTimeoutID=setTimeout("top.LoadW2KListe('"+n+"')",100,"JavaScript");break;}
      case 'Uebersiedeln': {clockTimeoutID=setTimeout("top.LoadUebersiedeln('"+n+"')",100,"JavaScript");break;}
      case 'Ausscheiden' : {clockTimeoutID=setTimeout("top.LoadAusscheiden('"+n+"')",100,"JavaScript");break;}
      case 'WSGeraet' : 
      case 'WSPers'   : {clockTimeoutID=setTimeout("top.LoadWSGBaum('"+n+"')",100,"JavaScript");break;}
      case 'VAIKOA'   : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIABR1'  : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIABR2'  : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIABR3'  : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIABR4'  : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIABR5'  : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIKST'   : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIKST2'  : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
      case 'VAIERF'   : {clockTimeoutID=setTimeout("top.LoadVAIListe('"+n+"')",100,"JavaScript");break;}
    }
  } //if(noInput)
  //alert('Ende such:'+n+'');
} //function Such(n)

function HandleKey(evt)
{
  evt = (evt) ? evt : window.event;
  if (evt.keyCode=='13')
  {
    //alert ('evt.keycode=13');
    if (AuswILPers.style.display=="block") {Such("ILPers");}
    if (AuswILGeraet.style.display=="block") {Such("ILGeraet");}
    if (AuswW2KPers.style.display=="block") {Such("W2KMassenSuche");}
    if (AuswW2KGeraet.style.display=="block") {Such("W2KGeraet");}
    if (AuswVAIKOA.style.display=="block") {Such("VAIKOA");}
    if (AuswVAIABR.style.display=="block") {Such("VAIABR");}
    if (AuswVAIKST.style.display=="block") {Such("VAIKST");}
    if (AuswVAIERF.style.display=="block") {Such("VAIERF");}
  }
  /*
  var f=top.form
  if (event.keyCode == 13)
  {
    for(var i=0; i<f.length;i++)
    {
      if(t.name!=f.elements(i).name && f.elements(i).name!='x' && f.elements(i).name!='h')
      {
        top.form.elements(i).value=''
      }
    }
    event.returnValue=false;
    form.x.click()
  }
  */
}

function toggle(was,wie,Bild)
{
  var d,i,wie1;
  if(wie=='expand')
  {
    d='none';
    Bild.src= '../Images/PLUS.gif';
    wie1='collapse';
  }
  else
  {
    d='block';
    Bild.src= '../Images/MINUS.gif';
    wie1='expand';
  }
  switch (was)
  {
    case A: {IPwie=wie1;break;}
    case I: {ILwie=wie1;break;}
    case W: {WLwie=wie1;break;}
    case D: {Dwie=wie1;break;}
    case V: {Vwie=wie1;break;}
  }
  for(var i=0;i<was.length;i++) 
  {
    was(i).style.display=d;
  }
} //function toggle(was,wie,Bild)

function chcolor()
{
  IPE.runtimeStyle.color='black';
  IPM.runtimeStyle.color='black';
  IPF.runtimeStyle.color='black';
  IPS.runtimeStyle.color='black';
  ILG.runtimeStyle.color='black';
  ILP.runtimeStyle.color='black';
  WKE.runtimeStyle.color='black';
  WKM.runtimeStyle.color='black';
  UEB.runtimeStyle.color='black';
  AUS.runtimeStyle.color='black';
  SCH.runtimeStyle.color='black';
  DD.runtimeStyle.color='black';
  DW.runtimeStyle.color='black';
  DK.runtimeStyle.color='black';
  DI1.runtimeStyle.color='black';
  DI2.runtimeStyle.color='black';
  KOA.runtimeStyle.color='black';
  ABR.runtimeStyle.color='black';
  KST.runtimeStyle.color='black'; 
  ERF.runtimeStyle.color='black';
  KB21T.runtimeStyle.color='black';
  KB21M.runtimeStyle.color='black';

} //function chcolor()

function IPEinzelSuche()
{
  chcolor();
  IPE.runtimeStyle.color='red';
  render(AuswIPGeraet,GeraeteDiv);
} //function IPEinzelSuche()

function IPMassenSuche()
{
  chcolor();
  IPM.runtimeStyle.color='red';
  render(AuswIPPers,GeraeteDiv);
} //function IPMassenSuche()

function WSEinzelSuche()
{
  chcolor();
  IPE.runtimeStyle.color='red';
  render(AuswWSGeraet,GeraeteDiv);
} //function WSEinzelSuche()

function WSMassenSuche()
{
  chcolor();
  IPM.runtimeStyle.color='red';
  render(AuswWSPers,GeraeteDiv);
} //function WSMassenSuche()

function IPFehlerSuche()
{
  chcolor();
  IPF.runtimeStyle.color='red';
  if(!SELStandorte_2)
  {
    SELStandorte2.innerHTML=LadeSELStandorte('Fehler');
    SELStandorte2.style.display='block';
    SELStandorte_2=true;
    FillSelSegment('ADDIT');
    //NS.style.display='block';
  }
  render(AuswIPFehler,GeraeteDiv);
} //function IPFehlerSuche()

function SegmentSuche()
{
  chcolor()
  IPS.runtimeStyle.color='red'
  if(!SELStandorte_1)
  {
    SELStandorte1.innerHTML=LadeSELStandorte('Segmente');
    SELStandorte1.style.display='block'
    SELStandorte_1=true
    FillSelSegment('ADDIT')
    NS.style.display='block'
  }
  render(AuswIPSegment,SegmenteDiv)
} //function SegmentSuche()

function ScriptAnzeigen()
{
  var DiaDetail="dialogHeight:500px;dialogWidth:900px;"+
                "dialogLeft:5;dialogTop:90;help:No;resizable:No;status:No;scroll:no"
  r=window.showModalDialog("../DHCP_Recover/DHCPAnzeigen.asp","",DiaDetail)
}

function dynScriptAnzeigen()
{
/*
  var DiaDetail="dialogHeight:500px;dialogWidth:900px;"+
                "dialogLeft:5;dialogTop:90;help:No;resizable:No;status:No;scroll:no"
  r=window.showModalDialog("../dynDNS/dynDNSAnzeigen.asp","",DiaDetail)
*/
  window.open("../dynDNS/dynDNSAnzeigen.asp","","width=910,height=500,top=120,left=10,scrollbars=no",false)  
}

function dynProtokoll()
{
/*
  var DiaDetail="dialogHeight:500px;dialogWidth:900px;"+
                "dialogLeft:5;dialogTop:90;help:No;resizable:No;status:No;scroll:no"
  r=window.showModalDialog("../dyn_DNS/Fehler.txt","",DiaDetail)
*/
  window.open("../dyn_DNS/Fehler.txt","","width=850,height=400,top=120,left=10,scrollbars=yes",false)
}

function MaskeDHCP()
{
  if(chkPW('IP'))
  {
    var DiaDetail="dialogHeight:260px;dialogWidth:400px;"+
                  "dialogLeft:10;dialogTop:120;help:No;resizable:No;status:No;scroll:no"
    r=window.showModalDialog("../DHCP_Recover/MaskeDHCP.asp","",DiaDetail)
  }
}

function DHCPProtokoll()
{
  window.open("../DHCP/Fehler.TXT","","width=850,height=400,top=120,left=150,scrollbars=yes",false)
}

function DNSProtokoll()
{
  window.open("../DNS/DNS.TXT","","width=500,height=400,top=120,left=150,scrollbars=yes",false)
}

function VAIKostenarten()
{
  chcolor();
  KOA.runtimeStyle.color='red';
  // Leistungsarten werden vorher dynamisch aus DB geladen
//  if(!SELLeistungsartenKOA)
//  {
    SELLeistungsarten1.innerHTML=LadeSELLeistungsarten1();
    SELLeistungsarten1.style.display='block';
    SELLeistungsartenKOA=true;
//  }
  // VAI-Verrechnung, Leistungsarten pflegen
  render(AuswVAIKOA,VaiDiv);
}

function VAIKostenstellenErfassen()
{
  chcolor();
  ERF.runtimeStyle.color='red';
  // Leistungsarten und Betr�ge werden vorher aus DB geladen (=> Listbox zweispaltig)
//  if(!SELLeistungsartenERF)
//  {
    SELLeistungsarten3.innerHTML=LadeSELLeistungsarten2();
    SELLeistungsarten3.style.display='block';
    SELLeistungsartenERF=true;
//  }
  // VAI-Verrechnung, Leistungsarten erfassen
  render(AuswVAIERF,VaiDiv);
}

function VAIHistAbrechnungsdaten()
{
  chcolor();
  ABR.runtimeStyle.color='red';
  // Leistungsarten werden vorher dynamisch aus DB geladen
//  if(!SELLeistungsartenABR)
//  {
    SELLeistungsarten2.innerHTML=LadeSELLeistungsarten1();
    SELLeistungsarten2.style.display='block';
    SELLeistungsartenABR=true;
//  }
  // VAI-Verrechnung, Abrechnungsdaten
  render(AuswVAIABR,VaiDiv);
}

function VAIKostenstellenVerwalten()
{
  chcolor();
  KST.runtimeStyle.color='red';
  // VAI-Verrechnung, Kostenstellen Massen�nderung
  render(AuswVAIKST,VaiDiv);
}

function ILGeraeteSuche()
{
  chcolor();
  ILG.runtimeStyle.color='red';
  if(!SELArbeitsplaetze)
  {
    SELArbeitsplaetze1.innerHTML=LadeSELArbeitsplaetze();
    SELArbeitsplaetze1.style.display='block';
    SELArbeitsplaetze=true;
  }
  render(AuswILGeraet,InventarDiv);
}

function ILPersonenSuche()
{
  chcolor();
  ILP.runtimeStyle.color='red';
  render(AuswILPers,InventarDiv);
}

function W2KEinzelSuche()
{
  chcolor();
  WKE.runtimeStyle.color='red';
  render(AuswW2KGeraet,W2KDiv);
  W2KDiv.document.getElementById("TabW2KOben").innerText = "   Beauftragung  Einzelsuche";
}

function W2KMassenSuche()
{
  chcolor();
  WKM.runtimeStyle.color='red';
  render(AuswW2KPers,W2KDiv);
  W2KDiv.document.getElementById("TabW2KOben").innerText = "   Beauftragung  Massensuche";
}

function Uebersiedeln()
{
  chcolor();
  UEB.runtimeStyle.color='red';
  Firma.innerHTML=LadeSELFirma();
  Firma.style.display='block';
  render(AuswMassen,MassenDiv);
}

function AAusscheiden()
{
  // autm 040711 beg
  var AsArr = new Array();
  AsArr[0]=0;
  AsArr[1]=0;
  AsArr[2]=0;
  r=window.showModalDialog("../a/sperre.htm",AsArr,"dialogHeight:50px;dialogWidth:300px;"+
                           "center:yes;help:No;resizable:Yes;status:No;scroll:no");
  //alert(r);
  if (r=="verw12")
  {
   // autm 040711 end
    //orig
      chcolor();
      AUS.runtimeStyle.color='red';
        //alert('Ausscheiden')

      if(!SELStandorte_3)
      {
        SELStandorte3.innerHTML=LadeSELStandorte('Ausscheid');
        SELStandorte3.style.display='block';
        SELStandorte_3=true;
        FillSelSegment('ADDIT');
        //NS.style.display='block';
      }
      // alert(SELStandorte3.innerHTML);
      render(AuswAussch,AusschDiv);
    //orig
  // autm 040711 beg
  }
  // autm 040711 end

}

function Schnittstellen()
{
  chcolor();
  SCH.runtimeStyle.color='red';
  if(!SELRollen)
  {
    SELRollen1.innerHTML=LadeSELRollen();
    SELRollen1.style.display='block';
    SELRollen=true;
  }
  render(AuswVerfahren,VerfahrenDiv);
  VerfahrenDiv.style.width=880;
  SchnittstDiv.style.display='none';
  VerfahrenDiv.style.display='block';
  VDiv.style.display='block';
  VDiv.innerHTML='Liste wird geladen';
  window.setTimeout("LoadVerfahren()",1);
}

function home()
{
  VerfahrenDiv.style.width=880;
  GeraeteDiv.style.width=880;
  DiensteDiv.style.display='none';
  SchnittstDiv.style.display='none';
  Diverses1.style.display='none';
  VaiDiv.style.display='none';
  aktDiv.style.display='none';
  aktWahl.style.display='none';
  NochNichtGewaehlt=true;
  //alert('home');
}

function render(neuWahl,neuDiv)
{
  //alert ('Beginn render' + neuWahl + '')
  VerfahrenDiv.style.width=880;
  SchnittstDiv.style.display='none';
  Diverses1.style.display='none';
  if(neuWahl!=aktWahl || NochNichtGewaehlt)
  {
    if(!NochNichtGewaehlt) aktWahl.style.display='none';
    neuWahl.style.display='block';
    aktWahl=neuWahl;
  }
  if(neuDiv!=aktDiv || NochNichtGewaehlt)
  {
    if(!NochNichtGewaehlt) aktDiv.style.display='none';
    neuDiv.style.display='block';
    aktDiv=neuDiv;
  }
  NochNichtGewaehlt=false;
  //alert ('Ende render,nw=' + neuWahl+',nd=' + neuDiv+'');
}


function BetragUndLeistungsartVersorgen()
{

//  if(form16.AlleLeistungsarten.value.length>0 && form16.AlleLeistungsarten.value <> 'Alle Leistungsarten')
//  { 
//    alert ('Leistungsart ausgew�hlt, SELECT')
//    //Show ASP parameters for test purposes
//    //alert("../ASP/LoadVAIBetragUndLeistungsart.asp?KOAKZ="+form16.AlleLeistungsarten.value+");
//    VaiDiv.style.display='block';
//    VADiv.style.display='block';
//    VADiv.innerHTML='';
//    VAIsource = new ActiveXObject("Microsoft.XMLDOM");
//    VAIsource.async = false;
//    VAIsource.load('../ASP/LoadVAIBetragUndLeistungsart.asp'+
//                     '?KOAKZ='+form16.AlleLeistungsarten.value+);
//         if(VAIsource.parseError != 0)
//         {
//            VaiDiv.innerHTML='';
//            alert('Keinen Treffer gefunden');
//            // nur f�r den Test:   
//            // alert(VAIsource.parseError.reason);
//            return;
//         }
//         else
//         {
//            //statt VAILKOA() etwas anderes aufrufen, hier Felder Betrag und Leistungsart versorgen;
//            VaiDiv.style.display='block';
//         }
//  }
//  else
//  {  
//    return false;
//  }

}

function LadeSELFirma()
{
  var s1=''+
  '<SELECT name="Firma" CLASS="Firma" style="width:150">'+
  '<option value="ALLE">Alle</option>';

  FirmaSource = new ActiveXObject("Microsoft.XMLDOM");
  FirmaSource.async = false;
  FirmaSource.load('../Massendaten/SELFirma.asp');
  //alert ('LAsource' + LAsource.xml + '');
  if (FirmaSource.parseError != 0)
  {
    //alert(FirmaSource.parseError.reason)
    alert('Datenbankfehler');
  }
  else
  {
     var LAroot=FirmaSource.firstChild;
     for (i=0; i<LAroot.childNodes.length-1; i++)
     {
       LAc=LAroot.childNodes(i);
       s1+='<OPTION value="'+LAc.text+'">'+LAc.text+'</OPTION>';
     }
  }
  FirmaSource=null;
  return s1+='</SELECT>';

}

function LadeSELLeistungsarten1()
{
  var s1=''+
  '<SELECT ID="KOAKZ" CLASS="KOAKZ" style="width:320">'+
  '<option value="ALLE">Alle Leistungsarten</option>';

  LAsource = new ActiveXObject("Microsoft.XMLDOM");
  LAsource.async = false;
  LAsource.load('../ASP/LoadVAILeistungsart.asp');
  //alert ('LAsource' + LAsource.xml + '');
  if (LAsource.parseError != 0)
  {
    //alert(LAsource.parseError.reason)
    alert('Datenbankfehler');
  }
  else
  {
     var LAroot=LAsource.firstChild;
     for (i=0; i<LAroot.childNodes.length-1; i++)
     {
       LAc=LAroot.childNodes(i);
       s1+='<OPTION value=\''+LAc.text+'\'>'+LAc.text.replace('"','\"')+'</OPTION>';
     }
  }
  LAsource=null;
  return s1+='</SELECT>';

}

function LadeSELLeistungsarten2()
{
  var s1=''+
  '<SELECT ID="KOAKZ" CLASS="KOAKZ" style="width:380">'+
  '<option value="ALLE">Alle Leistungsarten</option>';

  LAsource = new ActiveXObject("Microsoft.XMLDOM");
  LAsource.async = false;
  LAsource.load('../ASP/LoadVAILeistungsartUndBetrag.asp');
  if (LAsource.parseError != 0)
  {
    //alert(LAsource.parseError.reason)
    alert('Datenbankfehler');
  }
  else
  {
     var LAroot=LAsource.firstChild;
     for (i=0; i<LAroot.childNodes.length-1; i++)
     {
       LAc=LAroot.childNodes(i);
       s1+='<OPTION value="'+LAc.text+'">'+LAc.text+'</OPTION>';       
     }
  }
  LAsource=null;
  return s1+='</SELECT>';

}

function LadeSELArbeitsplaetze()
{
  var s1=''+
  '<SELECT ID="ARBEITSPL1" CLASS="ARBEITSPL1" style="width:200">'+
  '<option value="ALLE">Alle Arbeitspl�tze</option>';

  APsource = new ActiveXObject("Microsoft.XMLDOM");
  APsource.async = false;
  APsource.load('../ASP/LoadArbeitsPlatz.asp');
  if (APsource.parseError != 0)
  {
    //alert(APsource.parseError.reason)
    alert('Datenbankfehler');
  }
  else
  {
     var AProot=APsource.firstChild;
     for (i=0; i<AProot.childNodes.length-1; i++)
     {
       APc=AProot.childNodes(i);
       s1+='<OPTION value="'+APc.text+'">'+APc.text+'</OPTION>';
     }
  }
  APsource=null;
  return s1+='<option value="FEHLER">Fehlerliste</option></SELECT>';
}

function LadeSELRollen()
{
  var s1=''+
  '<SELECT ID="ROLLEN11" CLASS="ROLLEN1" name=Rolle style="width:200">'+
  '<option value="0">Alle</option>';

  Rsource = new ActiveXObject("Microsoft.XMLDOM");
  Rsource.async = false;
  Rsource.load('../ASP/LoadRollen.asp');
  if (Rsource.parseError != 0)
  {
    //alert(Rsource.parseError.reason)
    alert('Datenbankfehler');
  }
  else
  {
    var Rroot=Rsource.firstChild;
    for (var i=0; i<Rroot.childNodes.length-1; i++)
    {
      c=Rroot.childNodes(i);
      s1+='<OPTION VALUE="' +  c.getElementsByTagName("Rolle")(0).text+
           '" >' +c.getElementsByTagName("BEZ")(0).text+'</OPTION>';
    }
  }
  Rsource=null;
  return s1+='</SELECT>';
}

function LadeSELStandorte(was)
{
  var s1=''
  if(was=='Segmente')
  {
     s1+='<SELECT ID="STANDORT1" CLASS="STANDORT1" style="width:200" '+
    'onchange="FillSelSegment(form7.STANDORT1.options[STANDORT1.selectedIndex].value)">';
  Standortesource = new ActiveXObject("Microsoft.XMLDOM");
  Standortesource.async = false;
  Standortesource.load('../ASP/LoadStandOrtKZ.asp');
  if (Standortesource.parseError != 0)
  {
    //alert(Standortesource.parseError.reason);
    alert('Datenbankfehler1');
  }
  else
  {
     var root=Standortesource.firstChild;
     for (i=0; i<root.childNodes.length-1; i++)
     {
       c=root.childNodes(i);
       s1+='<OPTION value="'+c.text+'">'+c.text+'</OPTION>';
     }
  }
  }
  else
  {
   if(was=='Ausscheid')
   {
    s1+='<SELECT ID="STANDORT2" CLASS="STANDORT2" style="width:200" >';
    // s1+='<OPTION value=alle selected>Alle Pools</OPTION>';
    Standortesource = new ActiveXObject("Microsoft.XMLDOM");
    Standortesource.async = false;
    Standortesource.load('../DialogW2KAusscheidung/LoadStandOrtKZ.asp');
    if (Standortesource.parseError != 0)
    {
    //alert(Standortesource.parseError.reason)
      alert('Datenbankfehler1');
    }
    else
    {
     var root=Standortesource.firstChild;
     // alert(root.childNodes.length);
     for (i=0; i<root.childNodes.length-1; i=i+2)
     {
       c=root.childNodes(i);
       // alert(i+'  '+c.text);
       d=root.childNodes(i+1);
       // alert(i+'  '+d.text);
       s1+='<OPTION value="'+d.text+'">'+c.text+'</OPTION>';
     }
    }
   }
   else
   {
    s1+='<SELECT ID="STANDORT2" CLASS="STANDORT2" style="width:200" >';
    Standortesource = new ActiveXObject("Microsoft.XMLDOM");
    Standortesource.async = false;
    Standortesource.load('../ASP/LoadStandOrtKZ.asp');
    if (Standortesource.parseError != 0)
    {
      //alert(Standortesource.parseError.reason)
      alert('Datenbankfehler1');
    }
    else
    {
     var root=Standortesource.firstChild;
     for (i=0; i<root.childNodes.length-1; i++)
     {
       c=root.childNodes(i);
       s1+='<OPTION value="'+c.text+'">'+c.text+'</OPTION>';
     }
    }
   }
  }
  Standortesource=null;
  return s1+'</SELECT>';
}

function FillSelSegment(STO)
{
  Segmentsource = new ActiveXObject("Microsoft.XMLDOM");
  Segmentsource.async = false;
  Segmentsource.load('../ASP/LoadSegment.asp?KZ='+escape(STO.toUpperCase()));

  if(Segmentsource.parseError != 0)
  {
    //alert(Segmentsource.parseError.reason)
    alert('Datenbankfehler');
  }
  else
  {
    var root=Segmentsource.firstChild;
    var FirstItem,w;
    if(root.childNodes.length>1)
    {
      FirstItem='Alle Segmente';
      w='A';
    }
    else
    {
      FirstItem='Kein Segment vorhanden';
      w='K';
    }
    var str='<SELECT ID="NETZSEG" CLASS="NETZSEG" style="width:200">'+
    '<OPTION SELECTED VALUE="'+w+'" >'+FirstItem+'</OPTION>';
    for (var i=0; i<root.childNodes.length-1; i++)
    {
      c=root.childNodes(i);
      str+='<OPTION VALUE="' +  c.getElementsByTagName("NI")(0).text+
           '" >' +c.getElementsByTagName("NN")(0).text+'</OPTION>';
    }
    NS.innerHTML=str+'</SELECT>';
    Segmentsource=null;
  }
}

function SegmentListeExcel()
{
  var segm = form7.NETZSEG.options[form7.NETZSEG.selectedIndex].value;
  var sto  = form7.STANDORT1.options[form7.STANDORT1.selectedIndex].value;
  var Menge = form7.Menge.options[form7.Menge.selectedIndex].value;

  top.FOOT1.location.replace('../ASP/IPSegmentListe.asp'+
                   '?SEG='+escape(segm)+
                   '&sto='+escape(sto)+
                   '&Menge='+Menge+
                   '&was=Excel');
}

function InventarGeraetExcel()
{
  x=window.open('../Excel/BitteWarten.htm',"","width=350,height=100,top=50,left=150,menubar=no,scrollbars=no",false);
  top.FOOT1.location.replace('../Excel/InvG.asp'+
                   '?STO='      +escape(form4.STO.value)+
                   '&KSTVerr='  +form4.KSTVerr.value+
                   '&Betriebsbereich='+form4.Betriebsbereich.value+
                   '&Raum='     +form4.Raum.value+
                   '&Elemente=' +form4.Elemente.value+
                   '&Menge='    +form4.Menge.value+
                   '&FKZ='      +form4.FKZ.value+
                   '&KSTBesitz='+form4.KSTBesitz.value+
                   '&was=Excel');
}

function InventarPersExcel()
{
  x=window.open('../Excel/BitteWarten.htm',"","width=350,height=100,top=50,left=150,menubar=no,scrollbars=no",false);
  top.FOOT1.location.replace('../Excel/InvP.asp'+
                     '?Name='     +form3.Name.value+
                     '&VName='    +form3.Vorname.value+
                     '&Persnr='   +form3.Persnr.value+
                     '&Abteilung='+escape(form3.Abteilung.value)+
                     '&Elemente=' +form3.Elemente.value+
                     '&Menge='    +form3.Menge.value+
                     '&KST='      +form3.KST.value+
                     '&was=Excel');
}

function XInventarGeraetExcel()
{
  //form4.target='xxxx';
  form4.method='POST';
  form4.action='../Excel/InvG.asp';
  form4.submit();
}

function XInventarPersExcel()
{
  form3.target='xxxx';
  form3.method='POST';
  form3.action='../Excel/InvP.asp';
  form3.submit();
}

function ExcelW2K()
{
  x=window.open('../Excel/BitteWarten.htm',"","width=350,height=100,top=50,left=150,menubar=no,scrollbars=no",false);
/*  x=window.open('../Excel/W2K.asp'+
                     '?STO='            +escape(form6.STO.value)+
                     '&Raum='           +escape(form6.Raum.value)+
                     '&KSTVerr='        +escape(form6.KSTVerr.value)+
                     '&Betriebsbereich='+escape(form6.Betriebsbereich.value)+
                     '&Name='           +escape(form6.Name.value)+
                     '&VName='          +escape(form6.Vorname.value)+
                     '&Abteilung='      +escape(form6.Abteilung.value)+
                     '&KSTBenutzer='    +escape(form6.KSTBenutzer.value)+
                     '&KSTBesitz='      +escape(form6.KSTBesitz.value)+
                     '&Zustand='        +escape(form6.Zustand.value)+
                     '&ORDER='          +escape(form6.order.value));*/

  top.FOOT1.location.replace('../Excel/W2K.asp'+
                     '?STO='            +escape(form6.STO.value)+
                     '&Raum='           +escape(form6.Raum.value)+
                     '&KSTVerr='        +escape(form6.KSTVerr.value)+
                     '&Betriebsbereich='+escape(form6.Betriebsbereich.value)+
                     '&Name='           +escape(form6.Name.value)+
                     '&VName='          +escape(form6.Vorname.value)+
                     '&Abteilung='      +escape(form6.Abteilung.value)+
                     '&KSTBenutzer='    +escape(form6.KSTBenutzer.value)+
                     '&KSTBesitz='      +escape(form6.KSTBesitz.value)+
                     '&Zustand='        +escape(form6.Zustand.value)+
                     '&ORDER='          +escape(form6.order.value));

} // function ExcelW2K()

function loeschZentralPool()
{
  //KK: 	Diese Funktion ladet die Seite "../Asp/loeschZentralPool.htm"
  //		in das hidden-frame "top.FOOT1.location"

  x= new Date();
  top.FOOT1.location.replace("../Asp/loeschZentralPool.htm?"+PersKey);
  //KK: zu testzwecken: window.open("../Asp/loeschZentralPool.htm?"+PersKey,"asd")
}

function DruckeInventar()
{
  x= new Date();
  top.FOOT1.location.replace("../Drucken/DruckeInventar.htm?"+x);
}

function DruckeAusscheiden()
{
  x= new Date();
  top.FOOT1.location.replace("../Drucken/DruckeAusscheiden.htm?"+x);
}

function DruckeSegment()
{
  x= new Date();
  top.FOOT1.location.replace("../Drucken/DruckeSegment.htm?"+x);
}

function DruckeBestandsaufnahme(pid)
{
  var root=Gsource.firstChild;
  var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  xmlhttp.Open("POST","../Drucken/DruckeBestandsaufnahme.asp?PARKID="+pid,false);
  xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;');

  var str1='<K></K>';
  xmlhttp.Send('<?xml version="1.0" ?>'+str1);
  //alert(xmlhttp.responseText)
  if(xmlhttp.responseText=='XXX')
  {
    alert('Keine Bestandaufnahme vorhanden');
  }
  else
  {
    a=window.open("\\\\VIES118A.sie.siemens.at\\itpark\\PC-Reports\\"+xmlhttp.responseText,"",
                  'width=800,height=600,top=0,left=0,resizable,scrollbars=yes,toolbar=yes',false);
  }
}

function DruckeRolloutAuftrag(mpid)
{
  var root=Gsource.firstChild;
  var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  var str1='<K></K>';
  xmlhttp.Open("POST","../Drucken/DruckenRolloutEine.asp?pid="+mpid+"&PersKey="+PersKey,false);
  xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;');
  xmlhttp.Send('<?xml version="1.0" ?>'+str1);
  //alert(xmlhttp.responseText);
  top.Drst=xmlhttp.responseText;
  top.FOOT1.location.replace("Javascript:top.Drst");
}

function DruckeW2KMassenSuche()
{
  if(typeof(Gsource)=='undefined')
  {
    alert('nichts ausgew�hlt');
    return;
  }
  var OK=true;
  var keinesAusgewaehlt=true;
  var root=Gsource.firstChild;
  var i=0;
  if(false) {;} //(!top.W2KGesichert) alert('�nderungen zuerst sichern')
  else
  {
    while(i<W2KListeMassenSuche.elements.length-1 && OK)
    {
      if(W2KListeMassenSuche.elements(i+1).checked)
      {
        keinesAusgewaehlt=false;
        if(InvL.childNodes(1).children(i+1).children(2).innerHTML=='' ||
           InvL.childNodes(1).children(i+1).children(2).innerHTML=='') 
        {
           OK=false;
        }
      }
      i++;
    }
    if (keinesAusgewaehlt) 
    {
      alert('nichts ausgew�hlt');
    }
    else
    {
      if(OK)
      {
        var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        xmlhttp.Open("POST","../Drucken/DruckRolloutGesamt.asp?PersKey="+PersKey,false);
        xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;');
        var str1='<K><PARKIDs>';
        for (i=0; i<W2KListeMassenSuche.elements.length-1; i++)
        {
          if(W2KListeMassenSuche.elements(i+1).checked)
          {
            c=root.childNodes(i);
            var pid = c.getElementsByTagName("PARKID")(0).text;
            str1+='<PARKID>'+pid+'</PARKID>';
          }
        }
        str1+='</PARKIDs></K>';
        xmlhttp.Send('<?xml version="1.0" ?>'+str1);
        top.Drst=xmlhttp.responseText;
        top.FOOT1.location.replace("Javascript:top.Drst");
      }
      else 
      {
        alert('Angaben unvollst�ndig');
      }
    }
  }
} //function DruckeW2KMassenSuche()

function Hier()
{
  top.FOOT1.Dr1();
}

function DruckeW2Kgeladen()
{
  top.FOOT1.DrW2K();
}

function LoescheForm(t)
{
  var f=eval(t.form.name);
  for(var i=0;i<f.elements.length-1;i++)
  {
    if(f.elements[i].type=='text') f.elements[i].value='';
  }
}

function Left(str, n){
	if (n <= 0)
	    return "";
	else if (n > String(str).length)
	    return str;
	else
	    return String(str).substring(0,n);
}
function Right(str, n){
    if (n <= 0)
       return "";
    else if (n > String(str).length)
       return str;
    else {
       var iLen = String(str).length;
       return String(str).substring(iLen, iLen - n);
    }
}

function check_date(field){
var checkstr = "0123456789";
var DateField = field;
var Datevalue = "";
var DateTemp = "";
var seperator = ".";
var day;
var month;
var year;
var leap = 0;
var err = 0;
var i;
   err = 0;
   DateValue = DateField.value;
   /* Delete all chars except 0..9 */
   for (i = 0; i < DateValue.length; i++) {
	  if (checkstr.indexOf(DateValue.substr(i,1)) >= 0) {
	     DateTemp = DateTemp + DateValue.substr(i,1);
	  }
   }
   DateValue = DateTemp;
   /* Always change date to 8 digits - string*/
   /* if year is entered as 2-digit / always assume 20xx */
   if (DateValue.length == 6) {
      DateValue = DateValue.substr(0,4) + '20' + DateValue.substr(4,2); }
   if (DateValue.length != 8) {
      err = 19;}
   /* year is wrong if year = 0000 */
   year = DateValue.substr(4,4);
   if (year == 0) {
      err = 20;
   }
   /* Validation of month*/
   month = DateValue.substr(2,2);
   if ((month < 1) || (month > 12)) {
      err = 21;
   }
   /* Validation of day*/
   day = DateValue.substr(0,2);
   if (day < 1) {
     err = 22;
   }
   /* Validation leap-year / february / day */
   if ((year % 4 == 0) || (year % 100 == 0) || (year % 400 == 0)) {
      leap = 1;
   }
   if ((month == 2) && (leap == 1) && (day > 29)) {
      err = 23;
   }
   if ((month == 2) && (leap != 1) && (day > 28)) {
      err = 24;
   }
   /* Validation of other months */
   if ((day > 31) && ((month == "01") || (month == "03") || (month == "05") || (month == "07") || (month == "08") || (month == "10") || (month == "12"))) {
      err = 25;
   }
   if ((day > 30) && ((month == "04") || (month == "06") || (month == "09") || (month == "11"))) {
      err = 26;
   }
   /* if 00 ist entered, no error, deleting the entry */
   if ((day == 0) && (month == 0) && (year == 00)) {
      err = 0; day = ""; month = ""; year = ""; seperator = "";
   }
   /* if no error, write the completed date to Input-Field (e.g. 13.12.2001) */
   if (err == 0) {
      DateField.value = day + seperator + month + seperator + year;
   }
   /* Error-message if err != 0 */
   else {
      alert("Eingegebenes Datum " + day + "." + month + "." + year + " ist falsch!");
      DateField.select();
	  DateField.focus();
   }
}