function SL() 
{
  var nCols=2; 
  var x1=x2=0
  var str1=persnr=pid=''
  mparkid='XXXX' 
  doppelt=false 
  var root=Ssource.firstChild;
 
  str1+='<table id="InvL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="15"><col WIDTH="15"><col WIDTH="140"><col WIDTH="120"><col WIDTH="80">'+
  '<col WIDTH="90"><col WIDTH="100"><col WIDTH="40"><col WIDTH="40"><col WIDTH="150">'+
  '<col WIDTH="60"><col WIDTH="100"><col WIDTH="500">'+ 
  '<tr>'+
  '<th id="InvTH">&nbsp;</th>'+
  '<th id="InvTH" colspan="2">Standort<br>Bezeichnung</th>'+
  '<th id="InvTH">Bezeichnung<br>Bezeichnungs-Erg.</th>'+
  '<th id="InvTH">GNS<br>Equip.nr</th>'+
  '<th id="InvTH">IPNR<br>Inventarnr</th>'+
  '<th id="InvTH">Macadr.<br>Stru.Nr.</th>'+
  '<th id="InvTH">Status<br>Status</th>'+
  '<th id="InvTH">VKST<br>BKST</th>'+
  '<th id="InvTH">Benutzer<br></th>'+
  '<th id="InvTH">Persnr<br></th>'+
  '<th id="InvTH">Domain<br></th>'+  
  '<th id="InvTH">Host/Alias-name(n)<br></th>'+
  '</tr>'
  //if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)  
  for (i=0; i<root.childNodes.length-1; i++)   
  {
    c=root.childNodes(i)

    if(c.firstChild.tagName=='PLATZ')
    {
      mparkid='XXX'
      doppelt=false   
	  str1+='<tr onclick="detailGB('+"'"+c.getElementsByTagName("PARKID")(0).text+"'"+')">';	
	  str1+='<td valign=top>'+
	      '<img src="../Images/replytoauthor.gif"></td>' +     

	      '<td id="H" colspan="2">'+c.getElementsByTagName("ORT")(0).text+' '+c.getElementsByTagName("RAUM")(0).text+'</td>'+
	      '<td id="H">'+c.getElementsByTagName("ANLTXT")(0).text.substring(0,15)+'</td>'+
	      '<td id="H">'+c.getElementsByTagName("BEZ")(0).text+'</td>'+
	      '<td id="H">'+c.getElementsByTagName("IPNR")(0).text+'</td>'+	            
	      '<td id="H">'+c.getElementsByTagName("MACADR")(0).text+'</td>'+
	      '<td id="H">'+c.getElementsByTagName("STAT")(0).text+'</td>'+
	      '<td id="H">'+c.getElementsByTagName("VKST")(0).text+'</td>'+
	      '<td id="H">'+
	      (c.getElementsByTagName("FNAME")(0).text+' '+c.getElementsByTagName("VNAME")(0).text).substring(0,20)+
	      '</td>'+
	      '<td id="H">'+c.getElementsByTagName("PERSNR")(0).text+'</td>'+
	      '<td id="H">'+c.getElementsByTagName("DOMAIN")(0).text+'</td>'+	      
	      '<td id="H">'+c.getElementsByTagName("HOST")(0).text+'</td>'+
	      '</tr>';
	}
	else
	{
	  if(c.firstChild.tagName=='FREI')
	  {
	    str1+='<tr>';	
	    str1+='<td valign=top>'+
	          '<img src="../Images/replytoauthor.gif"></td>'
	    if(c.getElementsByTagName("INUSE")(0).text=='0')
	    { 
	      str1+='<td id="H" colspan="2">FREI</td>'
	    }
	    else
	    {
	      str1+='<td id="H" colspan="2">BELEGT '+c.getElementsByTagName("BEMERKUNG")(0).text+'</td>'    
	    }  
	    str1+='<td id="H"></td><td id="H"></td>'+
 	          '<td id="H" colspan="2">'+c.getElementsByTagName("IPNR")(0).text+'</td></tr>'; 
	  }
	  else
	  {
        var stat = c.getElementsByTagName("STAT")(0).text	  
        if(mparkid==c.getElementsByTagName("MPARKID1")(0).text)
        {
          if(stat>10 && stat<32) doppelt=true
        }
        if(stat>10 && stat<32)
        {
          mparkid=c.getElementsByTagName("MPARKID1")(0).text
        }
        else mparkid='XXX'  
    
        if(doppelt)
        {
	      str1+='<tr style="background-color:red"'
	    }
	    else
	    {
	      str1+='<tr'
	    }
	    str1+=' onclick="detailGB('+"'"+c.getElementsByTagName("PARKID")(0).text+"'"+')">';	
	          
	          
	          
	    str1+='<td>&nbsp;</td><td valign=top>'+
	    '<img src="../Images/leaf.gif"></td>'+
	      //'<td id="D">'+c.getElementsByTagName("MPARKID1")(0).text+'</td>'+
	      '<td id="D">'+c.getElementsByTagName("ANLTXT")(0).text+'</td>'+	      
	      '<td id="D">'+c.getElementsByTagName("BEZ")(0).text.substring(0,15)+'</td>'+
	      '<td id="D">'+c.getElementsByTagName("EQU")(0).text+'</td>'+
	      '<td id="D">'+c.getElementsByTagName("INVNR")(0).text.substring(0,8)+'</td>'+
	      '<td id="D">'+c.getElementsByTagName("STRU")(0).text+'</td>'+	        
	      '<td id="D">'+c.getElementsByTagName("STAT")(0).text+'</td>'+
	      '<td id="D">'+c.getElementsByTagName("BKST")(0).text+'</td>'+ 
	      
	      '</tr>';
	     } 
	}
  }
  str1+='</table>';
  //alert(str1)

  clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")
  
  Fortschritt.innerText=''
  SDiv.innerHTML=str1
}




