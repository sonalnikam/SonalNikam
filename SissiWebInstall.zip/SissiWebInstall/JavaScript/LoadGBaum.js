function LoadGBaum(n)
{ 
  var mit 
  GIPsource = new ActiveXObject("Microsoft.XMLDOM")
  
  if(n=='IPPers')   
  { 
    if(form2.BS2000.value.length>0 || form2.Druckershare.value.length>0)
    {
      if(form2.mitgeloeschtDienst.checked==true) mit='JA'
      else mit='NEIN'
      
      if(form2.BS2000.value!='') was='BS2000'
      else if(form2.Druckershare.value!='') was='Druckershare'   
    
      GIPsource.load('../ASP/PARKIDLoadGBaum.asp'+
                   '?was='+was+
                   '&BS2000='+form2.BS2000.value+ 
                   '&Druckershare='+form2.Druckershare.value+
                   '&mitgeloeschtDienst='+mit)
      GBDivUnten.innerHTML=''    
    }
    else
    {
      GIPsource.load('../ASP/LoadGBaum.asp'+
                   '?Name='+form2.Name.value+
                   '&VName='+form2.Vorname.value+
                   '&Persnr='+form2.Persnr.value+
                   '&KST='+form2.KST.value);
      GBDivUnten.innerHTML=''+
      'Klicken auf den Text -&gt; Bearbeitung bzw. Anzeigen des Dienstebaums<br>'+   
      '<IMG height=15 src="../Images/PLUS.GIF" width=16>&nbsp;Anlagendetails anzeigen&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
      '<IMG height=15 src="../Images/MINUS.GIF" width=16>&nbsp;Anlagendetails verbergen' 
    }              
  }
  else
  {
    if(n=='IPGeraet')
    {
      if(form1.IPNummer.value!='') was='IPNR'
      else if(form1.Inventar.value!='') was='INVNR'
      else if(form1.Equipment.value!='') was='EQU'
      else if(form1.HostAlias.value!='') was='HOSTALIAS'
      else if(form1.GNS.value!='') was='GNS'
      else if(form1.MAC.value!='') was='MACADR'
      else if(form1.Stru.value!='') was='STRU'
 
      if(form1.mitgeloeschtDienst.checked==true) mit='JA'
      else mit='NEIN'  
   
      GIPsource.load('../ASP/PARKIDLoadGBaum.asp'+
                 '?was='+was+
                 '&IPNR='+form1.IPNummer.value+
                 '&EQU='+form1.Equipment.value+
                 '&INVNR='+form1.Inventar.value+
                 '&HOSTALIAS='+form1.HostAlias.value+             
                 '&GNS='+form1.GNS.value+             
                 '&MACADR='+form1.MAC.value+
                 '&STRU='+form1.Stru.value+
                 '&mitgeloeschtDienst='+mit)
      GBDivUnten.innerHTML=''             
    }
    else
    {
      switch(n)
      {
        case 'IPFehler1': was='1';break;
        case 'IPFehler2': was='2';break;
        case 'IPFehler3': was='3';break;
      }  
      //if(n=='IPFehler1') was='1'
      //else was='2'
      GIPsource.load('../ASP/LoadFehler.asp?STO='+FehlerForm.STANDORT2.value+'&was='+was)
    }
  }
  checkReadyState("I")
}

function checkReadyState(n)  
{
  var nr=n  
  if(GIPsource.readyState ==4)
  { 
    if (GIPsource.parseError != 0)
    {
      GBDiv.innerHTML='Keine Ger�te gefunden'
      clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")
      Fortschritt.innerText=''
    }
    else 
    {
      Fortschritt.innerText='Ausgabe wird vorbereitet'     
      window.setTimeout("GB('0',true)",1)      
    }           
  }
  else 
  {
    if(nr.length<200) nr+="I"
    else nr="I"
    Fortschritt.innerText=nr
    window.setTimeout("checkReadyState('"+nr+"')",50)    
  }  
}