function IniAuswSegmente()
{ 
  AuswIPSegment.innerHTML='<form NAME="form7"><table CLASS="Such" border="0" cellspacing="0" cellpadding="0">\
  <col WIDTH="60"> <col WIDTH="200"><col WIDTH="150"><col WIDTH="200"><col WIDTH="70"> <col WIDTH="100"><col WIDTH="85">\
  <tr><th CLASS="U" colspan="6">&nbsp;</th\
  </tr><tr>\
  <th>Standorte</th><td><span id="SELStandorte1" style="display:none"></span></td>\
  <th>zugeh�rige Segmente</th><td valign=top><span id="NS" style="display:none"></span></td>\
  <th>&nbsp;</th>\
  <td><button onClick="LoadSegmentListe()" name="h">Suchen</button></td>\
  <th>&nbsp;</th>\
  </tr><tr>\
  <th colspan=2>&nbsp;</th>\
  <th>IP-Adressen</th>\
  <th colspan="2" style="text-align: left;"><select name="Menge">\
  <option value="1">freie und belegte </option>\
  <option value="2">freie</option>\
  <option value="3">belegte</option>\
  <option value="4">nur dyn. Adressen</option>\
  </select></th>\
  <th>&nbsp;</th>\
  <th>&nbsp;</th>\
  </tr><tr>\
  <th colspan=5>&nbsp;</th>\
  <td>&nbsp;</td>\
  <th>&nbsp;</th>\
  </tr><tr>\
  <th CLASS="U" colspan="6">&nbsp;</th>\
  </tr></table></form>'
}  
