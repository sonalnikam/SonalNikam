function WL(vonWo)
{
  var nCols=3;
  var x1=x2=0
  var str1=persnr=pid=''
  var root=GEsource.firstChild;

x = new Image()
x.src = '../Images/replytoauthor.gif'

  str1+='<table id="InvL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="15"><col WIDTH="15"><col WIDTH="15"><col WIDTH="140"><col WIDTH="120">'+
  '<col WIDTH="110"><col WIDTH="90"><col WIDTH="110"><col WIDTH="40"><col WIDTH="40">'+
  '<col WIDTH="150"><col WIDTH="60"><col WIDTH="80"><col WIDTH="40">'+
  '<tr>'+
  '<th id="InvTH">&nbsp;</th>'+
  '<th id="InvTH" colspan="3">Standort<br>Bezeichnung</th>'+
  '<th id="InvTH">Bezeichnung<br>Bezeichnungs-Erg.</th>'+
  '<th id="InvTH">GNS<br>Equip.nr</th>'+
  '<th id="InvTH">IPNR<br>Inventarnr</th>'+
  '<th id="InvTH">Betriebsbereich<br>Strukturnr</th>'+
  '<th id="InvTH">Status<br>Status</th>'+
  '<th id="InvTH">VKST<br>BKST</th>'+
  '<th id="InvTH">Benutzer<br>&nbsp;</th>'+
  '<th id="InvTH">Persnr<br>&nbsp;</th>'+
  '<th id="InvTH">Abteilung<br>&nbsp;</th>'+
  '<th id="InvTH">MAKST<br>&nbsp;</th>'+
  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)
  for (i=0; i<root.childNodes.length-1; i++)
  {
    c=root.childNodes(i)

if(c.getElementsByTagName("ANLTX")(0).text=='PC') top.PARKID=c.getElementsByTagName("PARKID")(0).text

    var pid   = c.getElementsByTagName("PARKID")(0).text
    var anltx = c.getElementsByTagName("ANLTX")(0).text

    if(c.firstChild.tagName=='PLATZ')
    {
    str1+='<tr>';
    str1+='<td valign=top>'+
        '<img src="../Images/replytoauthor.gif"></td>' +
        '<td id="H" colspan="3">'+c.getElementsByTagName("ORT")(0).text+' '+c.getElementsByTagName("RAUM")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("ANLTX")(0).text.substring(0,15)+'</td>'+
        '<td id="H">'+c.getElementsByTagName("BEZ")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("IPNR")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("BETRBEREICH")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("STAT")(0).text.substring(0,5)+'</td>'+
        '<td id="H">'+c.getElementsByTagName("VKST")(0).text+'</td>'+
        '<td id="H">'+
        (c.getElementsByTagName("NAME")(0).text+' '+c.getElementsByTagName("VNAME")(0).text).substring(0,20)+
        '</td>'+
        '<td id="H">'+c.getElementsByTagName("PERSNR")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("ABT")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("KST")(0).text+'</td>'+
        '</tr>';
  }
  else
  {
    if(c.firstChild.tagName=='UITEM')
    {
      str1+='<tr>';
      str1+='<td>&nbsp;</td>'
      str1+='<td>&nbsp;</td>'
      str1+='<td>'
      str1+='<img src="../Images/leaf.gif"></td><td id="D">'+c.getElementsByTagName("ANLTX")(0).text+'</td>'
    }
    else
    {
        var mpid=c.getElementsByTagName("MPARKID")(0).text
      str1+='<tr onclick="a41('+"'"+pid+"'"+','+"'"+mpid+"'"+','+"'"+anltx+"'"+','+"'"+vonWo+"'"+')">';
      str1+='<td>&nbsp;</td>'
      str1+='<td valign=top>'
      str1+='<img src="../Images/leaf.gif"></td>'
      str1+='<td colspan="2" id="D">'+c.getElementsByTagName("ANLTX")(0).text+'</td>'
    }
    str1+='<td id="D">'+c.getElementsByTagName("GERAET")(0).text.substring(0,15)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("EQU")(0).text+'</td>'+
        '<td id="D">'+c.getElementsByTagName("INVNR")(0).text.substring(0,10)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("STRU")(0).text+'</td>'+
        '<td id="D">'+c.getElementsByTagName("STAT")(0).text.substring(0,5)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("KST")(0).text+'</td>'+
        '</tr>';
  }
  }
  str1+='</table>';
  //alert(str1)

  //clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")

  WDiv.innerHTML=str1
  if(vonWo=='DIV') Fortschritt.innerText=''
  GEsource=null

}

function WS(vonWo)
{
// Ausscheidungsauftrag Start
  var len=0;
  var nCols=3;
  var x1=x2=0
  var str1=persnr=pid=''
  var root=GAsource.firstChild;

x = new Image()
x.src = '../Images/replytoauthor.gif'

  str1+='<table id="InvAus" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="20"><col WIDTH="10"><col WIDTH="15"><col WIDTH="140"><col WIDTH="120">'+
  '<col WIDTH="110"><col WIDTH="90"><col WIDTH="110"><col WIDTH="40"><col WIDTH="40">'+
  '<col WIDTH="150"><col WIDTH="60"><col WIDTH="80"><col WIDTH="40">'+
  '<tr>'+
  '<th id="InvTH">&nbsp;</th>'+
  '<th id="InvTH" colspan="3">Standort<br>Bezeichnung</th>'+
  '<th id="InvTH">Bezeichnung<br>Bezeichnungs-Erg.</th>'+
  '<th id="InvTH">GNS<br>Equip.nr</th>'+
  '<th id="InvTH">IPNR<br>Inventarnr</th>'+
  '<th id="InvTH">Betriebsbereich<br>Strukturnr</th>'+
  '<th id="InvTH">Status<br>Status</th>'+
  '<th id="InvTH">VKST<br>BKST</th>'+
  '<th id="InvTH">Benutzer<br>&nbsp;</th>'+
  '<th id="InvTH">Persnr<br>&nbsp;</th>'+
  '<th id="InvTH">Abteilung<br>&nbsp;</th>'+
  '<th id="InvTH">MAKST<br>&nbsp;</th>'+
  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)

  for (i=0; i<root.childNodes.length-1; i++)
  {
    c=root.childNodes(i)

if(c.getElementsByTagName("ANLTX")(0).text=='PC') top.PARKID=c.getElementsByTagName("PARKID")(0).text

    var pid   = c.getElementsByTagName("PARKID")(0).text
    var anltx = c.getElementsByTagName("ANLTX")(0).text

    if(c.firstChild.tagName=='PLATZ')
    {
    str1+='<tr>';
    str1+='<td valign=top>'+
        '<img src="../Images/replytoauthor.gif"></td>' +
        '<td id="H" colspan="3">'+c.getElementsByTagName("ORT")(0).text+' '+c.getElementsByTagName("RAUM")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("ANLTX")(0).text.substring(0,15)+'</td>'+
        '<td id="H">'+c.getElementsByTagName("BEZ")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("IPNR")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("BETRBEREICH")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("STAT")(0).text.substring(0,5)+'</td>'+
        '<td id="H">'+c.getElementsByTagName("VKST")(0).text+'</td>'+
        '<td id="H">'+
        (c.getElementsByTagName("NAME")(0).text+' '+c.getElementsByTagName("VNAME")(0).text).substring(0,20)+
        '</td>'+
        '<td id="H">'+c.getElementsByTagName("PERSNR")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("ABT")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("KST")(0).text+'</td>'+
        '</tr>';
  }
  else
  {
    if(c.firstChild.tagName=='UITEM')
    {
      str1+='<tr>';
      str1+='<td>&nbsp;</td>'
      str1+='<td>&nbsp;</td>'
      str1+='<td>'
      str1+='<img src="../Images/leaf.gif"></td><td id="D">'+c.getElementsByTagName("ANLTX")(0).text+'</td>'
    }
    else
    {
        var mpid=c.getElementsByTagName("MPARKID")(0).text
      str1+='<tr>';

      var auss = c.getElementsByTagName("AUSS")(0).text

      if (c.getElementsByTagName("ANLTX")(0).text.substring(0,8)!='Software')
      {
      str1+='<td valign=top>'
      str1+='<input type="checkbox" Name="ChB"'+auss+'>&nbsp;</td>'
      str1+='<td>&nbsp;</td>'
      }
      else
      {
      str1+='<td align=right>'
      str1+='<img src="../Images/leaf.gif"></td>'
      str1+='<td>&nbsp;</td>'
      }


      str1+='<td colspan="2" id="D">'+c.getElementsByTagName("ANLTX")(0).text+'</td>'
    }
    str1+='<td id="D">'+c.getElementsByTagName("GERAET")(0).text.substring(0,15)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("EQU")(0).text+'</td>'+
        '<td id="D">'+c.getElementsByTagName("INVNR")(0).text.substring(0,10)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("STRU")(0).text+'</td>'+
        '<td id="D">'+c.getElementsByTagName("STAT")(0).text.substring(0,5)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("KST")(0).text+'</td>'+
        '</tr>';
  }
  }
  str1+='</table>';
  str1+='<hr>';
  str1+='<table><tr><td align=left style="width:120mm;font-weight:bolder;color:red;">Markierte Eintr�ge mit &quot;�bernehmen&quot; zur Ausscheidung �bernehmen';
  str1+='<br>diese Auswahl kann nicht mehr r�ckg�ngig gemacht werden</td>';
  str1+='<td align=center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button onClick="Ausscheiden()" STYLE="width: 70; height:20" name="x1">�bernehmen</button>';
  str1+='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp';
  str1+='<button onClick="AusscheidenClose()" STYLE="width: 50; height:20" name="x1">Beenden</button>';
  str1+='</td><td style="width:20mm;"></td></tr></table>';
  //alert(str1)

  //clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")

  WDiv.innerHTML=str1
  if(vonWo=='DIV') Fortschritt.innerText=''
  // GAsource=null

 // Ausscheidungsauftrag Ende
}

function WSWS(vonWo)
{
// WebShop Start
  var len=0;
  var nCols=3;
  var x1=x2=0
  var str1=persnr=pid=''
  var root=GAWSsource.firstChild;

x = new Image()
x.src = '../Images/replytoauthor.gif'

  str1+='<table id="InvAus" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="20"><col WIDTH="10"><col WIDTH="15"><col WIDTH="140"><col WIDTH="120">'+
  '<col WIDTH="110"><col WIDTH="90"><col WIDTH="110"><col WIDTH="40"><col WIDTH="40">'+
  '<col WIDTH="150"><col WIDTH="60"><col WIDTH="80"><col WIDTH="40">'+
  '<tr>'+
  '<th id="InvTH">&nbsp;</th>'+
  '<th id="InvTH" colspan="3">Standort<br>Bezeichnung</th>'+
  '<th id="InvTH">Bezeichnung<br>Bezeichnungs-Erg.</th>'+
  '<th id="InvTH">GNS<br>Equip.nr</th>'+
  '<th id="InvTH">IPNR<br>Inventarnr</th>'+
  '<th id="InvTH">Betriebsbereich<br>Strukturnr</th>'+
  '<th id="InvTH">Status<br>Status</th>'+
  '<th id="InvTH">VKST<br>BKST</th>'+
  '<th id="InvTH">Benutzer<br>&nbsp;</th>'+
  '<th id="InvTH">Persnr<br>&nbsp;</th>'+
  '<th id="InvTH">Abteilung<br>&nbsp;</th>'+
  '<th id="InvTH">MAKST<br>&nbsp;</th>'+
  '</tr>'
  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)

  for (i=0; i<root.childNodes.length-1; i++)
  {
    c=root.childNodes(i)

if(c.getElementsByTagName("ANLTX")(0).text=='PC') top.PARKID=c.getElementsByTagName("PARKID")(0).text

    var pid   = c.getElementsByTagName("PARKID")(0).text
    var anltx = c.getElementsByTagName("ANLTX")(0).text

    if(c.firstChild.tagName=='PLATZ')
    {
    WSgnsnr   = c.getElementsByTagName("BEZ")(0).text

    str1+='<tr>';
    str1+='<td valign=top>'+
        '<img src="../Images/replytoauthor.gif"></td>' +
        '<td id="H" colspan="3">'+c.getElementsByTagName("ORT")(0).text+' '+c.getElementsByTagName("RAUM")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("ANLTX")(0).text.substring(0,15)+'</td>'+
        '<td id="H">'+c.getElementsByTagName("BEZ")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("IPNR")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("BETRBEREICH")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("STAT")(0).text.substring(0,5)+'</td>'+
        '<td id="H">'+c.getElementsByTagName("VKST")(0).text+'</td>'+
        '<td id="H">'+
        (c.getElementsByTagName("NAME")(0).text+' '+c.getElementsByTagName("VNAME")(0).text).substring(0,20)+
        '</td>'+
        '<td id="H">'+c.getElementsByTagName("PERSNR")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("ABT")(0).text+'</td>'+
        '<td id="H">'+c.getElementsByTagName("KST")(0).text+'</td>'+
        '</tr>';
  }
  else
  {
    if(c.firstChild.tagName=='UITEM')
    {
      str1+='<tr>';
      str1+='<td>&nbsp;</td>'
      str1+='<td>&nbsp;</td>'
      str1+='<td>'
      str1+='<img src="../Images/leaf.gif"></td><td id="D">'+c.getElementsByTagName("ANLTX")(0).text+'</td>'
    }
    else
    {
        var mpid=c.getElementsByTagName("MPARKID")(0).text
      str1+='<tr>';

      // THOM 20040728: Kontrolle Ausscheidung korrekt
      var auss = c.getElementsByTagName("AUSS")(0).text
      //alert('AUSS=['+auss+']');

      if (c.getElementsByTagName("ANLTX")(0).text.substring(0,8)!='Software')
      {
      str1+='<td valign=top>'
      str1+='<input type="checkbox" Name="ChB"'+auss+'>&nbsp;</td>'
      str1+='<td>&nbsp;</td>'
      }
      else
      {
      str1+='<td align=right>'
      str1+='<img src="../Images/leaf.gif"></td>'
      str1+='<td>&nbsp;</td>'
      }


      str1+='<td colspan="2" id="D">'+c.getElementsByTagName("ANLTX")(0).text+'</td>'
    }
    str1+='<td id="D">'+c.getElementsByTagName("GERAET")(0).text.substring(0,15)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("EQU")(0).text+'</td>'+
        '<td id="D">'+c.getElementsByTagName("INVNR")(0).text.substring(0,10)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("STRU")(0).text+'</td>'+
        '<td id="D">'+c.getElementsByTagName("STAT")(0).text.substring(0,5)+'</td>'+
        '<td id="D">'+c.getElementsByTagName("KST")(0).text+'</td>'+
        '</tr>';
  }
  }
  str1+='</table>';

  var OI_IUK_Liste=LadeSELIukListe();

  str1+='<hr>';
  str1+='<table>';

  str1+='<tr><td align=left style="width:70mm;font-weight:bolder;color:red;"><SELECT ID="Ordertype">'+
  '<OPTION VALUE="A">Ersatzbestellung mit Ausscheidung</OPTION>'+
  '<OPTION VALUE="E">Ersatzbestellung ohne Ausscheidung</OPTION>'+
  '<OPTION VALUE="B" selected>Zusatz zu Bestehendem Hauptger�t</OPTION>'+
  '</SELECT></td><td align=left style="width:70mm;font-weight:bolder;color:red;">'+OI_IUK_Liste+'</td>'+
  '<td align=left><button onClick="WSAusscheiden()" STYLE="width: 70; height:20" name="Ueber">�bernehmen</button>'+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button onClick="WSAusscheidenClose()" STYLE="width: 70; height:20" name="Beend">Abbrechen</button>'+
  '</tr>';

  str1+='</table>'
  //alert(str1)

  //clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")

  WDiv.innerHTML=str1
  if(vonWo=='DIV') Fortschritt.innerText=''
  // GAsource=null

  // WebShop Ende
}

function a41(pid,mpid,anltx,vonWo)
{
  // alert('a41')
  if(vonWo=='DIV')
  {
    if(anltx.substring(0,2)=='PC')
    {
      r=window.showModalDialog("../Dialogs/W2KDialog.htm","","dialogHeight:150px;dialogWidth:200px;"+
                               "center:yes;help:No;resizable:No;status:No;scroll:no");
      switch(r)
      {
        case 'Detail': detailGB(pid);break;
        case 'RolloutAuftrag'   : DruckeRolloutAuftrag(mpid);  break;
        case 'Bestandsaufnahme' : DruckeBestandsaufnahme(pid); break;
      }
    }
    else
    {
      var DiaDetail="dialogHeight:715px;dialogWidth:420px;"+
         "dialogLeft:340;dialogTop:5;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailParkData.asp?pid='+pid
      window.showModalDialog(x11,'',DiaDetail)
    }
  }
  else
  {
    //top.FOOT1.location.replace("../Drucken/DruckeBestandsaufnahme.asp?PARKID="+pid)
  }
}

function WSAusscheiden()
{

var indexTB=0;
var root=GAWSsource.firstChild;
var iAnzahl=0;

  for (i=0; i<root.childNodes.length-1; i++)
  {
    c=root.childNodes(i)

    //alert(c.firstChild.tagName);

    if (c.firstChild.tagName=='ITEM' && c.getElementsByTagName("ANLTX")(0).text.substring(0,8)!='Software')
    {
      var TestChB = (typeof window.ChB.length=="undefined") ? window.ChB.checked : window.ChB[indexTB].checked;
      if (TestChB)
      {
        iAnzahl++;
        var pid   = c.getElementsByTagName("PARKID")(0).text
        var anltx = c.getElementsByTagName("ANLTX")(0).text
        var equip = c.getElementsByTagName("EQU")(0).text
        var invnr = c.getElementsByTagName("INVNR")(0).text
        var auss = c.getElementsByTagName("AUSS")(0).text
        var irestwert = c.getElementsByTagName("RWERT")(0).text
      }
      var TestChB = (typeof window.ChB.length=="undefined") ? window.ChB.checked : window.ChB[indexTB].checked;

      //alert(pid+"/"+anltx+"/"+TestChB);
    }
    if (c.firstChild.tagName=='PLATZ')
    {
      var nSto = c.getElementsByTagName("STO")(0).text
      var nObj = c.getElementsByTagName("OBJ")(0).text
      var nGesch = c.getElementsByTagName("GESCH")(0).text
      var nRaum = c.getElementsByTagName("RAUM")(0).text
      var nFICode = c.getElementsByTagName("FICODE")(0).text
      var nGID = c.getElementsByTagName("NGID")(0).text
    }

    if (c.firstChild.tagName=='ITEM')  indexTB++;
  }
  if (iAnzahl==1)
  {
    if (window.Ordertype.options[window.Ordertype.selectedIndex].value=="A")
    {
      if (isNaN(invnr) == true || invnr=='')
      {
        alert('Ausscheidung ohne Inventarnummer nicht m�glich!');
        return;
      }
      if (auss!='')
      {
        alert('Ger�t bereits zur Ausscheidung vorgemerkt!');
        return;
      }
      //alert('irestwert: '+irestwert);
      if (irestwert > 0)
      {
        alert('Restwert des Ger�tes ist nicht 0!');
        return;
      }
      //alert('GID-AUSSIUK:['+window.Iukliste.options[window.Iukliste.selectedIndex].value+']')
      if (window.Iukliste.options[window.Iukliste.selectedIndex].value == '0')
      {
        alert('F�r Ausscheidung muss ein IuK-Ansprechpartner gew�hlt werden!');
        return;
      }
    }

    window.returnValue=WSgnsnr+'@'+equip+'@'+
                      window.Ordertype.options[window.Ordertype.selectedIndex].value+'@'+
                      window.Iukliste.options[window.Iukliste.selectedIndex].value+'@'+
                      nSto+'@'+nObj+'@'+nGesch+'@'+nRaum+'@'+nFICode+'@'+nGID;
    window.close();
  }
  else
  {
    alert("Ein Ger�t muss gew�hlt werden!");
    return;
  }
}

function WSAusscheidenClose()
{
window.returnValue='';

window.close();
}

function LadeSELIukListe()
{
  var s1=''

    s1+='<SELECT ID="Iukliste" CLASS="STANDORT2" style="width:200" ><OPTION value="'+'0'+'"></OPTION>'
    // s1+='<OPTION value=alle selected>Alle Pools</OPTION>'
    Iuklistesource = new ActiveXObject("Microsoft.XMLDOM")
    Iuklistesource.async = false;
debugger;
    Iuklistesource.load('../WebShop/LoadIukListe.asp')

    if (Iuklistesource.parseError != 0)
    {
      //alert(Iuklistesource.parseError.reason)
      alert('Fehler beim Parsen der IuK-Liste!')
    }
    else
    {
     var root=Iuklistesource.firstChild;
     // alert(root.childNodes.length);
     for (i=0; i<root.childNodes.length-1; i=i+2)
     {
       c=root.childNodes(i);
       // alert(i+'  '+c.text);
       d=root.childNodes(i+1)
       // alert(i+'  '+d.text);
       s1+='<OPTION value="'+d.text+'">'+c.text+'</OPTION>'
      }

    }
  return s1+'</SELECT>'
}

