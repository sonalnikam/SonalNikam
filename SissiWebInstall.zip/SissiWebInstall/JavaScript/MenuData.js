function fnSave(t)
{
  if(t.value!='')
  { 
    try
    { 
      with (top.oPersistDiv)
      {
        setAttribute(t.name,t.value);	
	    save("oXMLStore");
      }
    }
    catch(e) {} 
  }    
}

function fnLoad(t)
{
  try
  {
    top.oPersistDiv.load("oXMLStore");
    if(oPersistDiv.getAttribute(t.name)==null)
    {
      t.value=''
    }
    else
    {  
      t.value=oPersistDiv.getAttribute(t.name);
    }
  }   
  catch(e) {}     
}

