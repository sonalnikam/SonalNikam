function LoadSegmentListe()
{
  if(form7.NETZSEG.options[form7.NETZSEG.selectedIndex].value!='K')
  {    
    clockTimeoutID=setTimeout("LoadSegmentListe2()",1000,"JavaScript")
  }  
}

function LoadSegmentListe2()
{
  var segm = form7.NETZSEG.options[form7.NETZSEG.selectedIndex].value
  var sto  = form7.STANDORT1.options[form7.STANDORT1.selectedIndex].value 
  var Menge = form7.Menge.options[form7.Menge.selectedIndex].value 
  
  //fuer Test: alert (segm + sto + Menge);
  
  Ssource = new ActiveXObject("Microsoft.XMLDOM")
  if(Menge!=4)
  {    
    Ssource.load('../ASP/IPSegmentListe.asp?SEG='+escape(segm)+'&sto='+escape(sto)+'&Menge='+Menge); 
  }
  else
  {
    Ssource.load('../ASP/IPdynSegment.asp?SEG='+escape(segm)+'&sto='+escape(sto)+'&Menge='+Menge); 
  }
  SegmenteDiv.style.display='block'
  top.Abbrechen=false
  Abbr.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>'

  SLcheckReadyState('I')
} 

function SLcheckReadyState(n)  
{
  var nr=n
  if(top.Abbrechen)
  { 
    top.Abbrechen=false
    Abbr.innerHTML=''
    Fortschritt.innerText=''
    
    alert('Suche abgebrochen')
  }
  else
  { 
    if(Ssource.readyState ==4)
    {
      Abbr.innerHTML='' 
      if (Ssource.parseError != 0)
      {
        SDiv.innerHTML='Keine Ger�te gefunden'
        clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")
        Fortschritt.innerText=''
      }
      else 
      {
        Fortschritt.innerText='Ausgabe wird vorbereitet'
        SDiv.style.display='block'
        window.setTimeout("SL()",1)
        Abbr.innerHTML=''+
        '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
        '<button onClick="DruckeSegment()" STYLE="HEIGHT: 20px; WIDTH: 120px">Drucken</button>'+
        '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
        '<button onClick="SegmentListeExcel()" STYLE="HEIGHT: 20px; WIDTH: 120px">Excel</button>'  

      }           
    }
    else 
    {
      if(nr.length<200) nr+="I"
      else nr="I"
      Fortschritt.innerText=nr
      window.setTimeout("SLcheckReadyState('"+nr+"')",50)    
    }  
  }
}    