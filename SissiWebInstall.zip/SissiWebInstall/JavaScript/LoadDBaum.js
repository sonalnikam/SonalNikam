function LoadDBaum(wer,pid,msg)
{ 
  DiensteDiv.style.display='block'
  DBDiv.style.display='block'

  Dsource = new ActiveXObject("Microsoft.XMLDOM")
  Dsource.async = false;
  Dsource.load('../ASP/LoadDBaum.asp?Pid='+pid); 
  if(Dsource.parseError != 0)
  {
    //alert(pid)
    //alert(Dsource.parseError.reason)
  }
  else
  {
    DB('0',true)
    GeraeteDiv.style.width='480'
    DBDiv.style.display='block'
    var root=Dsource.firstChild;
  
    if(root.childNodes.length<2 && msg)
    {    
      var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
      xmlhttp.Open("POST", "../ASP/chkIP_faehig.asp", false);
      xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
      xmlhttp.Send('MPARKID='+pid)
      {    
        //alert(xmlhttp.responseText)     
        if(xmlhttp.responseText!='OK')
        {
          alert('kein IP-f�higes Ger�t')
        }
        else
        { 
          if(confirm('neue IP-Nr einrichten?')) 
          {
            if(chkPW('IP'))
            {
              var DiaStrIP="dialogHeight:680px;dialogWidth:480px;"+
                           "dialogLeft:190;dialogTop:50;help:No;resizable:No;status:No;scroll:no"
         
              r=window.showModalDialog("../MaskeIPNummer/IP.asp?persnr="+wer+
                                                              "&pid="+pid+
                                                              "&ErsterDienst=J"+
                                                              "&PersKey="+PersKey+
                                                              "&AenPersKey="+AenPersKey,"",DiaStrIP)
              top.LoadDBaum(wer,pid,false)
            }  
          }      
        }
      } 
    }    
  }
}

   
