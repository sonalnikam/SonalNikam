function IL(von,bis,was) 
{ 
  var root=ILsource.firstChild;
 
  max =bis+20 //plus 20 am 9.10.2008 wegen Fehler bei 502 Eintr�gen
  SaetzeProSeite=(max-von) //9.10.2008 statt bis-von jetzt max-von
  ersteAusgabe=von+23 //erste //23
  str1=''
  imgx = new Image()
  imgx.src = '../Images/replytoauthor.gif'
  imgy = new Image()
  imgy.src = '../Images/leaf.gif'  
  
  kopf='<table id="InvL1" border=0 cellspacing=0 cellpadding=0>\
  <col WIDTH="15"><col WIDTH="15"><col WIDTH="140"><col WIDTH="120">\
  <col WIDTH="110"><col WIDTH="90"><col WIDTH="60"><col WIDTH="40"><col WIDTH="40">\
  <col WIDTH="150"><col WIDTH="60"><col WIDTH="80"><col WIDTH="70">\
  <tr>\
  <th id="InvTH">&nbsp;</th>\
  <th id="InvTH" colspan="2">Standort<br>Bezeichnung</th>\
  <th id="InvTH">Bezeichnung<br>Bezeichnungs-Erg.</th>\
  <th id="InvTH">GNS<br>Equip.nr</th>\
  <th id="InvTH">IPNR<br>Inventarnr</th>\
  <th id="InvTH">Betr.ber.<br>Stru.Nr.</th>\
  <th id="InvTH">Status<br>Status</th>\
  <th id="InvTH">VKST<br>BKST</th>\
  <th id="InvTH">Benutzer<br>Lieferdatum</th>\
  <th id="InvTH">Persnr<br>A-Wert</th>\
  <th id="InvTH">Abteilung<br>R-Wert</th>\
  <th id="InvTH">MAKST<br>AFA-Ende</th>\
  </tr>'
 
  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)
  
  if(root.childNodes.length-1<ersteAusgabe) ersteAusgabe=root.childNodes.length-1
  if(root.childNodes.length-1>max)
  {
    //alert('Anzahl der S�tze gr��er als max')
    anz=max
    msg='Die S�tze '+(von+1)+' bis  '+anz+' von insgesamt '+(root.childNodes.length-1)+
        ' S�tzen werden angezeigt'         
  }
  else
  {
    //alert('Anzahl der S�tze kleiner als max')
    anz=root.childNodes.length-1
    msg=''
  }
 
  var flag=true
  for(var i=von; i<ersteAusgabe; i++)   
  {
    if(i>400 && flag && root.childNodes(i).firstChild.text.substring(4,5)!='A') 
    {
      
    }
    else
    {
      flag=false    
      str1+=root.childNodes(i).firstChild.text+'</tr>';
    }  	
  }
  IDiv.innerHTML=kopf+str1+'</table>'
  
  IDiv.style.display='block'    
  InventarDiv.style.display='block'
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout("ILweiter('"+was+"')",1)
  }
  else
  {
    Fortschritt.innerText=''
    ZeigeButton(von+SaetzeProSeite,root.childNodes.length-1,was)
   
    IDiv.innerHTML=kopf+str1+'</table>'
    //ILsource=null 
  }  
}  

function ILweiter(was)
{ 
//  try
  {
    var root=ILsource.firstChild;
    var str2=''    
   
    for(var i=ersteAusgabe; i < anz; i++)
    {
      str2+=root.childNodes(i).firstChild.text+'</tr>';	
    }
    
    if(i < root.childNodes.length-1)
    {
      if(root.childNodes(i).firstChild.text.substring(4,5)!='A')
      {
        var ii=i
        var str5=''
        while(root.childNodes(ii).firstChild.text.substring(4,5)!='A' && ii < root.childNodes.length-1)
        {
          str5+=root.childNodes(ii).firstChild.text
          ii++
        }   
        str2+=str5
        str2+=root.childNodes(ii).firstChild.text   
      }
      else
      {
        str2+=root.childNodes(i).firstChild.text 
      } 
    }  
    Fortschritt.innerText=msg
    
    ZeigeButton(i,root.childNodes.length-1,was)   
    IDiv.innerHTML=kopf+str1+str2+'</table>'  
  }
//  catch(e)
//  {
//    alert('zu viele Datens�tze')
//  }  
  //ILsource=null 
}

function ZeigeButton(i,gesamt,was)
{
  var weiterbutton=zurueckbutton=''
  
  if(i < gesamt)
  {
    weiterbutton=''+
    '<button STYLE="position:absolute; left:750px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'IDivUnten.innerHTML=\'\';IL('+i+','+(i+SaetzeProSeite)+',\''+was+'\')">'+    
    'n�chste Seite anzeigen</button>'    
  }
  if(i > SaetzeProSeite)
  {
    if(i-(SaetzeProSeite*2)<0) j=SaetzeProSeite*2    
    else j=i
    zurueckbutton=''+
    '<button STYLE="position:absolute; left:1px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'IDivUnten.innerHTML=\'\';IL('+(j-(SaetzeProSeite*2))+','+(j-SaetzeProSeite)+',\''+was+'\')">'+    
    'vordere Seite anzeigen</button>'       
  }
  
    var s=''+
  zurueckbutton+'&nbsp;&nbsp;&nbsp;'+weiterbutton+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
  '<button onClick="DruckeInventar()" STYLE="position:absolute; left:300px; HEIGHT: 20px; WIDTH: 120px">Drucken</button>'+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
 
  if(was=='ILPers')
  {
    s+='<button STYLE="position:absolute; left:450px; HEIGHT: 20px; WIDTH: 120px" onClick="InventarPersExcel()"'
  }
  else
  {
    s+='<button STYLE="position:absolute; left:450px; HEIGHT: 20px; WIDTH: 120px" onClick="InventarGeraetExcel()"'
  }     
  IDivUnten.innerHTML=s+' STYLE="HEIGHT: 20px; WIDTH: 120px">Excel</button>'  
}



