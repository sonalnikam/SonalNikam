function WSGB(currentNumber,currentIsExpanded)
{
  DiensteDiv.style.display='none'
  DBDiv.style.display='none'
  GeraeteDiv.style.width='880'
  var x1=x2=0
  var str1=ausg=persnr=pid=img=nam=''
  var root=GIPsource.firstChild;
  var currentNumArray = currentNumber.split(".");

  imgx = new Image()
  imgx.src = '../Images/PLUS.gif'
  imgy = new Image()
  imgy.src = '../Images/MINUS.gif'
  imgz = new Image()
  imgz.src = '../Images/LEAF.gif'
  imgr = new Image()
  imgr.src = '../Images/replytoauthor.gif'

  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)

  str1+='<table id="IPL1" border=0 cellspacing=1 cellpadding=0><col WIDTH="20"><col WIDTH="20"><col WIDTH="730">';

  for (i=0; i<root.childNodes.length-1; i++)
  {
    c=root.childNodes(i)
    if(c.firstChild.tagName=='PLATZ')
    {
      thisLevel=0
      x1++
      x2=0
      thisNumber=x1+''
    }
    else
    {
      thisLevel=1
      x2++
      thisNumber=x1+'.'+x2
    }
  var thisNumArray=thisNumber.split(".");

  var toDisplay=true;
  if(thisLevel>0)
  {
    toDisplay = toDisplay && (thisNumArray[0] == currentNumber)
    }

    thisIsExpanded = toDisplay && (thisNumArray[thisLevel] == currentNumArray[thisLevel])
    if(currentIsExpanded)
    {
    toDisplay = toDisplay && (thisLevel<=0);
      if(thisNumber==currentNumber) thisIsExpanded=false;
    }
    if(toDisplay || root.tagName=='Ys')
    {
      var ausgTD=(thisNumber==currentNumber)?'Exp':'notExp'
    str1+='<tr>';

    if(c.firstChild.tagName=='PLATZ')
    {
var pid1=c.getElementsByTagName("PARKID")(0).text
        nam=c.getElementsByTagName("NAME")(0).text+' '+c.getElementsByTagName("VNAME")(0).text+' '
        var keinBenutzer = true
        if(nam=='  ') nam=' kein Benutzer angegeben '
        else
        {
          if(c.getElementsByTagName("PERSNR")(0).text=='')
          {
            nam+='Personalnummer fehlt !!!'
          }
          else keinBenutzer = false
        }

        var gns=c.getElementsByTagName("BEZ")(0).text;

        ausg=c.getElementsByTagName("ORT")(0).text+' '+
             c.getElementsByTagName("ANLTX")(0).text+' '+
             c.getElementsByTagName("BEZ")(0).text+' '+
             nam+
             c.getElementsByTagName("PERSNR")(0).text.replace('"','')
        if(c.getElementsByTagName("STAT")(0).text>='37') ausg+=' demon/gel�scht!! '
        var okl=c.getElementsByTagName("OBJKLASSE")(0).text

        if(okl!='3048' && okl!='3051') ausg+=' Fehler - kein Arbeitsplatz '
        //if(okl!='3048') ausg+=' Fehler - kein Arbeitsplatz '


        persnr=c.getElementsByTagName("PERSNR")(0).text
        pid=c.getElementsByTagName("PARKID")(0).text

      img = imgr.src;

      str1+='<td valign=top>'+
            '<img src="'+img+'" '+'></td>'+
            '<td ID="'+ausgTD+'" colspan="2" '

      //if((c.getElementsByTagName("STAT")(0).text=='40' || (okl!='3048')) && root.tagName!='Zs' ) str1+=' >'
      if((c.getElementsByTagName("STAT")(0).text=='40' || (okl!='3048' && okl!='3051')) && root.tagName!='Zs' ) str1+=' >'
      else str1+=' onclick="WSa1('+"'"+thisNumber+"',"+thisIsExpanded+",'"+persnr+"','"+
                                pid+"'"+','+keinBenutzer+','+"'"+okl+"'"+','+"'"+
                                root.tagName+"'"+','+"'"+gns+"'"+');">'
    }
    else
    {
     ausg='';
    }
    str1+=ausg+'</td></tr>';
    }
  }
  str1+='</table>';
  //alert(str1)
  clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")

  GBDiv.innerHTML=''
  GeraeteDiv.style.display='block'
  GBDiv.innerHTML=str1
  GBDiv.innerHTML=GBDiv.innerHTML
  GBDiv.style.display='block'
  Fortschritt.innerText=''

}

function WSa1(thisNumber,thisExpanded,persnr,pid,keinBenutzer,objklasse,roottagname,gns)
{
  if(objklasse!='3048' && objklasse!='3051' && roottagname!='Zs')
  //if(objklasse!='3048' && roottagname!='Zs')
  {
    alert('Kein Arbeitsplatz - Struktur des Parkelements ist nicht korrekt!')
    return
  }
  var AsArr = new Array();
  AsArr[0]=gns;
  AsArr[1]=ASPIDKey;
  AsArr[2]=ASPIDKey;
  r=window.showModalDialog("../WebShop/DialogWebShop.asp",AsArr,"dialogHeight:500px;dialogWidth:740px;"+
                                                                "center:yes;help:No;resizable:Yes;status:No;scroll:no");
  if(typeof(r) =='undefined') r="";

  var ss;
  ss=r.split('@');
  //alert(r+'\n'+ss.length);
  if (ss.length==10)
  {
    WSgnsnr=ss[0];
    WSequip=ss[1];
    WSorder=ss[2];
    WSgid=ss[3];
    WSsto=ss[4];
    WSobj=ss[5];
    WSGsh=ss[6];
    WSRau=ss[7];
    WSfic=ss[8];
    WSngd=ss[9];
    //window.close();
    ReturnToWebshop();
  }
  else
  {
    //alert("Kein Arbeitsplatz gew�hlt!!");
  }
}
