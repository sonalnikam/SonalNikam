function IniAuswVerfahren()
{ 
  AuswVerfahren.innerHTML= ''+
  '<form NAME="form9">'+
  '<table CLASS="Such" border="0" cellspacing="0" cellpadding="0">'+   
  '<col WIDTH="70"><col WIDTH="150"><col WIDTH="70"><col WIDTH="150"><col WIDTH="70">'+
  '<col WIDTH="200"><col WIDTH="30"><col WIDTH="100"><col WIDTH="20">'+
  '<tr>'+
  '<th CLASS="U" colspan="9">&nbsp;</th>'+
  '</tr>'+
  '<th>Verfahren</th><td><input name="Verfahren" size="20" maxlength="20"></td>'+
  '<th>Name</th><td><input name="Name" size="20" maxlength="20"></td>'+
  '<th>Rolle</th>'+
  '<td colspan="2"><span id="SELRollen1" style="display:none"></span></td>'+   
/*
  <td><select name="Rolle">'+
  '<option value="0">Alle</option>'+
  '<option value="6003">Verantwortlicher</option>'+
  '<option value="6012">Lizenzverantwortlicher</option>'+
  '<option value="6013">Bereichsansprechpartner</option>'+
  '<option value="6014">Lieferantenansprechpartner</option>'+
  '<option value="6002">System-Administrator</option>'+
  '<option value="6001">Nutzer</option>'+
  '</select></td><td>&nbsp;</td>'+
*/  
  '<td><button onclick="Schnittstellen()">Verfahren suchen</button></td>'+
  '<td>&nbsp;</td>'+      
  '<tr>'+ 
  '</tr>'+    
  '<tr>'+
  '<th colspan=7>&nbsp;</th>'+
  '<td><button onClick="LoescheForm(this)">Eingaben l�schen</button></td>'+
  '</tr>'+ 
  '<tr><th colspan="9">&nbsp;</th></tr>'+        
  '</table></form>'
}

