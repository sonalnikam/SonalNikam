function ShowBearbeit(PersKey)
{
      var DiaDetail="dialogHeight:170px;dialogWidth:350px;"+
          "dialogLeft:520;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailBearbeit.asp?PersKey='+PersKey
	  window.showModalDialog(x11,'',DiaDetail)
}
function Show(pid)
{
      var DiaDetail="dialogHeight:220px;dialogWidth:340px;"+
          "dialogLeft:380;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailPark_Rollen.asp?pid='+pid
	  window.showModalDialog(x11,'',DiaDetail)   	  	

}
function ShowSegment(segmentid)
{
      var DiaDetail="dialogHeight:540px;dialogWidth:340px;"+
          "dialogLeft:520;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailSegment.asp?segmentid='+segmentid
	  window.showModalDialog(x11,'',DiaDetail)
}
function ShowAlleDienstID(mdid)
{
      var DiaDetail="dialogHeight:250px;dialogWidth:630px;"+
          "dialogLeft:120;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/AlleDIENSTID.asp?mdid='+mdid
	  window.showModalDialog(x11,'',DiaDetail)
}
function ShowKunde(kdid)
{
      var DiaDetail="dialogHeight:540px;dialogWidth:350px;"+
          "dialogLeft:520;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailKUNDE.asp?kdid='+kdid
	  window.showModalDialog(x11,'',DiaDetail)   	  	

}
function ShowKDANSPRECH(aspid)
{
      var DiaDetail="dialogHeight:320px;dialogWidth:345px;"+
          "dialogLeft:460;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailKDANSPRECH.asp?aspid='+aspid
	  window.showModalDialog(x11,'',DiaDetail)   	  	

}
function ShowAllePARKID(mpid)
{
      var DiaDetail="dialogHeight:430px;dialogWidth:800px;"+
          "dialogLeft:300;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/AllePARKID.asp?mpid='+mpid
	  window.showModalDialog(x11,'',DiaDetail)
}
function ShowSTATUS()
{
  var DiaStat="dialogHeight:350px;dialogWidth:280px;"+
              "dialogLeft:290;dialogTop:100;help:No;resizable:No;status:No;scroll:no"

  window.showModalDialog("../Details/DetailSTATUS.asp","",DiaStat)
}
function ShowAnlagenklasse(AnlKlasse)
{
      var DiaDetail="dialogHeight:170px;dialogWidth:400px;"+
          "dialogLeft:300;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailANLKLASSE.asp?AnlKlasse='+AnlKlasse
	  window.showModalDialog(x11,'',DiaDetail)
}
function ShowParkObjekt(PONR)
{
      var DiaDetail="dialogHeight:170px;dialogWidth:400px;"+
          "dialogLeft:300;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailPARKOBJEKT.asp?PONR='+PONR
	  window.showModalDialog(x11,'',DiaDetail)
}
function ShowDomain(Domain)
{
      var DiaDetail="dialogHeight:320px;dialogWidth:320px;"+
          "dialogLeft:300;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Details/DetailDomain.asp?Domain='+Domain
	  window.showModalDialog(x11,'',DiaDetail)
}