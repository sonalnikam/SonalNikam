function LoadAusscheiden(n)
{
var f=top.form


  // alert(AuswAussch.innerHTML)
  //alert(form10.STANDORT2.value);
  //alert(escape(form10.STANDORT2.value.toUpperCase()))

  AusscheidungSTO=escape(form10.STANDORT2.value.toUpperCase())
   //alert(AusscheidungSTO);
   if (AusscheidungSTO=="ALLE") form10.btnLoe.style.visibility="visible"
   else form10.btnLoe.style.visibility="hidden"

    AusschDiv.style.display='block'
    ADiv.style.display='block'
    ADiv.runtimeStyle.cursor='wait'
    ADiv.innerHTML=''

    Asource = new ActiveXObject("Microsoft.XMLDOM")
    // Asource.load('../ASP/LoadAusscheiden.asp')

    Asource.load('../ASP/LoadAusscheiden.asp?STO='+escape(form10.STANDORT2.value.toUpperCase()));

    //window.open('../ASP/LoadAusscheiden.asp?STO='+escape(form10.STANDORT2.value.toUpperCase()),'sdfs');

    //KK: window.open('../ASP/LoadAusscheiden.asp?STO='+escape(form10.STANDORT2.value.toUpperCase()),'ssdf');
    //  Asource.load('../ASP/LoadAusscheiden.asp?STO=')

    ADivUnten.innerHTML=''

    AcheckReadyState('I',n)

    //alert('LoadAusscheiden/LoadAusscheiden'+Asource.xml);
}

function AcheckReadyState(n,was)
{

  var nr=n
  if(Asource.readyState ==4)
  {
    if (Asource.parseError != 0)
    {

      AusschDiv.style.display='block'
      ADiv.style.display='block'
      ADiv.innerHTML=Asource.parseError.reason

      clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")

      Fortschritt.innerText=''
    }
    else
    {

      ADiv.style.display='block'
      AusschDiv.style.display='block'
      Fortschritt.innerText='Ausgabe wird vorbereitet - '+
                               (Asource.firstChild.childNodes.length-1)+' S�tze'

      //top.W2KGesichert=true

      window.setTimeout("AL()",1)

    }
  }
  else
  {

    if(nr.length<200) nr+="I"
    else nr="I"
    Fortschritt.innerText=nr

    window.setTimeout("AcheckReadyState('"+nr+"','"+was+"')",50)
  }
}

