function LoadWSGBaum(n)
{
  var mit
  GIPsource = new ActiveXObject("Microsoft.XMLDOM")

  if(n=='WSPers')
  {
    GIPsource.load('../ASP/WSLoadGBaum.asp'+
                   '?was=WSPers'+
                   '&STO='            +escape(form12.STO.value)+
                   '&Raum='           +escape(form12.Raum.value)+
                   '&KSTVerr='        +escape(form12.KSTVerr.value)+
                   '&Betriebsbereich='+escape(form12.Betriebsbereich.value)+
                   '&Name='           +escape(form12.Name.value)+
                   '&VName='          +escape(form12.Vorname.value)+
                   '&Abteilung='      +escape(form12.Abteilung.value)+
                   '&KSTBenutzer='    +escape(form12.KSTBenutzer.value)+
                   //'&Zustand='        +escape(form12.Zustand.value)+
                   '&KSTBesitz='      +escape(form12.KSTBesitz.value));
    GBDivUnten.innerHTML=''
  }
  else
  {
    if(n=='WSGeraet')
    {
      if(form11.IPNummer.value!='') was='IPNR'
      else if(form11.Inventar.value!='') was='INVNR'
      else if(form11.Equipment.value!='') was='EQU'
      else if(form11.HostAlias.value!='') was='HOSTALIAS'
      else if(form11.GNS.value!='') was='GNS'

      GIPsource.load('../ASP/WSLoadGBaum.asp'+
                 '?was='+was+
                 '&IPNR='+form11.IPNummer.value+
                 '&EQU='+form11.Equipment.value+
                 '&INVNR='+form11.Inventar.value+
                 '&HOSTALIAS='+form11.HostAlias.value+
                 '&GNS='+form11.GNS.value);
      GBDivUnten.innerHTML=''
    }
  }
  checkReadyWS("I")
}

function checkReadyWS(n)
{
  var nr=n
  if(GIPsource.readyState ==4)
  {
    if (GIPsource.parseError != 0)
    {
      GBDiv.innerHTML='Keine Ger�te gefunden:'+GIPsource.parseError.errorCode+'___'+GIPsource.parseError.reason+'___'+GIPsource.parseError.srcText
      clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")
      Fortschritt.innerText=''
    }
    else
    {
      Fortschritt.innerText='Ausgabe wird vorbereitet'
      window.setTimeout("WSGB('0',true)",1)
    }
  }
  else
  {
    if(nr.length<200) nr+="I"
    else nr="I"
    Fortschritt.innerText=nr
    window.setTimeout("checkReadyWS('"+nr+"')",50)
  }
}