function LoadUebersiedeln(n)
{ 
    MassenDiv.style.display='block'
    MDiv.style.display='block'
    MDiv.runtimeStyle.cursor='wait'
    MDiv.innerHTML=''  
  
    Msource = new ActiveXObject("Microsoft.XMLDOM")     
    Msource.load('../ASP/LoadUebersiedeln.asp'+
                     '?STO='            +escape(form8.STO.value)+ 
                     '&Raum='           +escape(form8.Raum.value)+
                     '&KSTVerr='        +escape(form8.KSTVerr.value)+
                     '&Betriebsbereich='+escape(form8.Betriebsbereich.value)+
                     '&Name='           +escape(form8.Name.value)+
                     '&VName='          +escape(form8.Vorname.value)+
                     '&Abteilung='      +escape(form8.Abteilung.value)+                
                     '&KSTBenutzer='    +escape(form8.KSTBenutzer.value)+
                     '&GNS='            +escape(form8.GNS.value)+
                     '&Firma='          +escape(form8.Firma.value))                     

    MDivUnten.innerHTML=''
    McheckReadyState('I',n)
     
}

function McheckReadyState(n,was)  
{ 
  var nr=n  
  if(Msource.readyState ==4)
  { 
    if (Msource.parseError != 0)
    {
      
      MassenDiv.style.display='block'
      MDiv.style.display='block' 
      MDiv.innerHTML=Msource.parseError.reason

      clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")
      
      Fortschritt.innerText=''     
    }
    else 
    { 
      MDiv.style.display='block'      
      MassenDiv.style.display='block'
      Fortschritt.innerText='Ausgabe wird vorbereitet - '+
                               (Msource.firstChild.childNodes.length-1)+' S�tze' 
      
      //top.W2KGesichert=true
      window.setTimeout("UL()",1)

    }
  }
  else 
  {
    if(nr.length<200) nr+="I"
    else nr="I"
    Fortschritt.innerText=nr
    window.setTimeout("McheckReadyState('"+nr+"','"+was+"')",50)    
  }  
}





