function VAILKOA() 
{  
  top.aktVAILZeile='';
  var root=VAIsource.firstChild;
  max=250;
  ersteAusgabe=200;
  str1='';
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=300>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=300>'+
  '<col WIDTH=60><col WIDTH=50><col WIDTH=150><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=30><col WIDTH=30>'+
  '<tr>'+
  '<th id="VaiTH">Firma</th><th id="VaiTH">Leistungsart</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Bezeichnung</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">Typ</th><th id="VaiTH">LKZ</th>'+
  '</tr>';

  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
  }
  
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+' S�tzen anzeigen';
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='';
  }
    
  for (i=0; i<ersteAusgabe; i++)   
  {
    var strChild = root.childNodes(i).firstChild.text;
    var strx2 = strChild.substr(14,1);
    var strx = strChild.substr(17,1);
    var strText = '';    
    // rein f�r Test am 10.1.:
    // alert (strChild.substr(14,1));    
    if (strx == "_")
    {
      strText=strChild.replace(/_/g,"");
      str1+='<tr id="VaiListenelemBlue">'+strText+'</tr>';
    }
    else if (strx == "-")
    {
      strText=strChild.replace(/-/g,"");
      str1+='<tr id="VaiListenelemRed">'+strText+'</tr>';
    }
    else if (strx == "~")
    {
      strText=strChild.replace(/~/g,"");
      str1+='<tr id="VaiListenelemOrange">'+strText+'</tr>';
    }
    else
    {      
      if (strx2 == "2")
      {
       //aufgrund der Erweiterung der Response-Zeile mit einer onclick-Funktion,
       // steht nun f�r blau markierte Zeilen an der 14.Stelle eine 2 (-> function a23!!) 
        strText=strChild.replace(/_/g,"");
        str1+='<tr id="VaiListenelemBlue">'+strText+'</tr>';
      }
      else if (strx2 == "3")
      {
        //aufgrund der Erweiterung der Response-Zeile mit einer onclick-Funktion, 
        //steht nun f�r orange markierte Zeilen an der 14.Stelle eine 3 (-> function a33!!) 
        strText=strChild.replace(/~/g,"");
        str1+='<tr id="VaiListenelemOrange">'+strText+'</tr>';
      }
      else
      { 
        str1+='<tr id="VaiListenElem">'+strChild+'</tr>';
      }
    }
  }
  //kommt weg?  VADiv.innerHTML=kopf+str1+'</table>'
  //Show HTML code
  //alert('VADiv.innerHTML=' + VADiv.innerHTML + '');
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    //alert('vor window.setTimeout('VAIweiter()');
    window.setTimeout('VAIweiter()',1);
  }
  else
  {
    Fortschritt.innerText='';
    //alert('KOPF=' + kopf + '');
    //alert('STR1=' + str1 + '');
    //VADiv.innerHTML=kopf+'</table></form>';
    VADiv.innerHTML=kopf+str1+'</table></form>';
    VADiv.runtimeStyle.cursor='hand';
  }
  //alert('VAILKOA Ende');
}

function VAILKOAneu(von,bis) 
{ 
  top.aktVAILZeile=''; 
  var root=VAIsource.firstChild;
  max=bis;
  SaetzeProSeite=(bis-von);
  ersteAusgabe=von+200;    
  str1='';
  
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=300>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=300>'+
  '<col WIDTH=60><col WIDTH=50><col WIDTH=150><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=30><col WIDTH=30>'+
  '<tr>'+
  '<th id="VaiTH">Firma</th><th id="VaiTH">Leistungsart</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Bezeichnung</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">Typ</th><th id="VaiTH">LKZ</th>'+
  '</tr>';

  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
    //alert(ersteAusgabe); 
  }
  
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Die S�tze '+(von+1)+' bis '+anz+' von insgesamt '+(root.childNodes.length-1)+' S�tzen werden angezeigt.'; 
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='Die letzten S�tze von insgesamt '+(root.childNodes.length-1)+' S�tzen werden angezeigt.'; 
  }
    
  for (var i=von; i<ersteAusgabe; i++)   
  {
    var strChild = root.childNodes(i).firstChild.text;
    var strx2 = strChild.substr(14,1);
    var strx = strChild.substr(17,1);
    var strText = '';    
    // rein f�r Test am 10.1.:
    // alert (strChild.substr(14,1));    
    if (strx == "_")
    {
      strText=strChild.replace(/_/g,"");
      str1+='<tr id="VaiListenelemBlue">'+strText+'</tr>';
    }
    else if (strx == "-")
    {
      strText=strChild.replace(/-/g,"");
      str1+='<tr id="VaiListenelemRed">'+strText+'</tr>';
    }
    else if (strx == "~")
    {
      strText=strChild.replace(/~/g,"");
      str1+='<tr id="VaiListenelemOrange">'+strText+'</tr>';
    }
    else
    {      
      if (strx2 == "2")
      {
        //aufgrund der Erweiterung der Response-Zeile mit einer onclick-Funktion,
        // steht nun f�r blau markierte Zeilen an der 14.Stelle eine 2 (-> function a23!!) 
        strText=strChild.replace(/_/g,"");
        str1+='<tr id="VaiListenelemBlue">'+strText+'</tr>';
      }
      else if (strx2 == "3")
      {
        //aufgrund der Erweiterung der Response-Zeile mit einer onclick-Funktion, 
        //steht nun f�r orange markierte Zeilen an der 14.Stelle eine 3 (-> function a33!!) 
        strText=strChild.replace(/~/g,"");
        str1+='<tr id="VaiListenelemOrange">'+strText+'</tr>';
      }
      else
      { 
        str1+='<tr id="VaiListenElem">'+strChild+'</tr>';
      }
    }
  }
  VADiv.innerHTML=kopf+str1+'</table>'
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  //Show HTML code
  //alert('VADiv.innerHTML=' + VADiv.innerHTML + '');
  
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    //alert('vor window.setTimeout');
    window.setTimeout('VAIweiterMitButtonKOA()',1);             
  }
  else
  {
    //Fortschritt.innerText='';
    Fortschritt.innerText=msg;
    ZeigeButtonKOA(von+SaetzeProSeite,root.childNodes.length-1);
    //alert('KOPF=' + kopf + '');
    //alert('STR1=' + str1 + '');
    VADiv.innerHTML=kopf+str1+'</table></form>';   
    VADiv.runtimeStyle.cursor='hand';
  }
  //alert('VAILKOAneu Ende');
}

function VAILABR(typ) 
{  
  top.aktVAILZeile=''
  var root=VAIsource.firstChild;
  max = 250
  ersteAusgabe=200  
  str1=''
  
  if (typ == "Akt")
  {
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=200>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=200><col WIDTH=200>'+
  '<col WIDTH=100><col WIDTH=80><col WIDTH=120><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=50<col WIDTH=30><col WIDTH=30>'+
  '<tr>'+
  '<th id="VaiTH">Firma1</th><th id="VaiTH">Leistungsart</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Leistungsartbeschreibung</th><th id="VaiTH">Poolname</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">VerrKZ</th><th id="VaiTH">Typ</th>'+
  '</tr>'
  }
  else if (typ == "Histo")
  {
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=200><col WIDTH=200><col WIDTH=200>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=200>'+
  '<col WIDTH=100><col WIDTH=80><col WIDTH=120><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=50><col WIDTH=70><col WIDTH=30>'+
  '<tr>'+
  '<th id="VaiTH">Firma2</th><th id="VaiTH">Leistungsart</th><th id="VaiTH">Leistungsartbeschreibung</th><th id="VaiTH">Poolname</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Freitextbeschreibung</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">VerrKZ</th><th id="VaiTH">VerrDatum</th><th id="VaiTH">Typ</th>'+
  '</tr>'  
  }
  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
  }
  
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+
        ' S�tzen anzeigen';
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='';
  }
    
  for (i=0; i<ersteAusgabe; i++)   
  {
    str1+='<tr>'+root.childNodes(i).firstChild.text+'</tr>';
  }
  
  VADiv.innerHTML=kopf+str1+'</table>'
  //Show HTML code
  //alert(VADiv.innerHTML)
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout('VAIweiter()',1);
  }
  else
  {
    Fortschritt.innerText='';
    VADiv.innerHTML=kopf+str1+'</table>';
    VADiv.runtimeStyle.cursor='hand';
  }
}

function VAILABR1neu(von,bis) 
{  
  top.aktVAILZeile=''; 
  var root=VAIsource.firstChild;
  max=bis;
  SaetzeProSeite=(bis-von);
  ersteAusgabe=von+200;    
  str1='';
  
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=140>'+
  '<col WIDTH=120><col WIDTH=200>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=200><col WIDTH=200>'+
  '<col WIDTH=100><col WIDTH=80><col WIDTH=120><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=50<col WIDTH=30><col WIDTH=30><col WIDTH=60>'+
  '<tr>'+
  '<th id="VaiTH">Verr.Datum</th>'+
  '<th id="VaiTH">Firma</th><th id="VaiTH">Leistungsart</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Leistungsartbeschreibung</th><th id="VaiTH">Poolname</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">VerrKZ</th><th id="VaiTH">Typ</th><th id="VaiTH">GID</th>'+
  '</tr>'

  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
  }
  
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Die S�tze '+(von+1)+' bis '+anz+' von insgesamt '+(root.childNodes.length-1)+ ' S�tzen werden angezeigt';
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='Die letzten S�tze von insgesamt '+(root.childNodes.length-1)+' S�tzen werden angezeigt.'; 
  }
    
  for (var i=von; i<ersteAusgabe; i++)   
  {
    str1+='<tr>'+root.childNodes(i).firstChild.text+'</tr>';
  }
  
  VADiv.innerHTML=kopf+str1+'</table>'
  //Show HTML code
  //alert(VADiv.innerHTML)
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    //alert('vor window.setTimeout');
    window.setTimeout('VAIweiterMitButtonABR1()',1);             
  }
  else
  {
    Fortschritt.innerText=msg;
    ZeigeButtonABR1(von+SaetzeProSeite,root.childNodes.length-1);
    //alert('KOPF=' + kopf + '');
    //alert('STR1=' + str1 + '');
    VADiv.innerHTML=kopf+str1+'</table></form>';   
    VADiv.runtimeStyle.cursor='hand';
  }
}

function VAILABR2neu(von,bis) 
{  
  top.aktVAILZeile=''; 
  var root=VAIsource.firstChild;
  max=bis;
  SaetzeProSeite=(bis-von);
  ersteAusgabe=von+200;    
  str1='';
  
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=200><col WIDTH=200><col WIDTH=200>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=200>'+
  '<col WIDTH=100><col WIDTH=80><col WIDTH=120><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=50><col WIDTH=70><col WIDTH=30><col WIDTH=30>'+
  '<tr>'+
  '<th id="VaiTH">Firma4</th><th id="VaiTH">Leistungsart</th><th id="VaiTH">Leistungsartbeschreibung</th><th id="VaiTH">Poolname</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Freitextbeschreibung</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">VerrKZ</th><th id="VaiTH">VerrDatum</th><th id="VaiTH">Typ</th><th id="VaiTH">GID</th>'+
  '</tr>';  

  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
  }
  
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Die S�tze '+(von+1)+' bis '+anz+' von insgesamt '+(root.childNodes.length-1)+ ' S�tzen werden angezeigt';
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='Die letzten S�tze von insgesamt '+(root.childNodes.length-1)+' S�tzen werden angezeigt.'; 
  }
    
  for (var i=von; i<ersteAusgabe; i++)   
  {
    str1+='<tr>'+root.childNodes(i).firstChild.text+'</tr>';
  }
  
  VADiv.innerHTML=kopf+str1+'</table>'
  //Show HTML code
  //alert(VADiv.innerHTML)
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    //alert('vor window.setTimeout');
    window.setTimeout('VAIweiterMitButtonABR2()',1);             
  }
  else
  {
    Fortschritt.innerText=msg;
    ZeigeButtonABR2(von+SaetzeProSeite,root.childNodes.length-1);
    //alert('KOPF=' + kopf + '');
    //alert('STR1=' + str1 + '');
    VADiv.innerHTML=kopf+str1+'</table></form>';   
    VADiv.runtimeStyle.cursor='hand';
  }
}

function VAILKST() 
{
  top.aktVAILZeile='';
  var root=VAIsource.firstChild;
  max = 250;
  ersteAusgabe=200;
  str1='';

  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=70><col WIDTH=150><col WIDTH=150>'+
  '<col WIDTH=150><col WIDTH=300><tr>'+
  '<th id="VaiTH">GNS</th><th id="VaiTH">Nachname</th><th id="VaiTH">Vorname</th>'+
  '<th id="VaiTH">Typ</th><th id="VaiTH">Bezeichnung</th>'+'</tr>'
  
  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
  }
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+ ' S�tze anzeigen';
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='';
  }
  for (i=0; i<ersteAusgabe; i++)   
  {
    str1+='<tr>'+root.childNodes(i).firstChild.text+'</tr>';
  }
  VADiv.innerHTML=kopf+str1+'</table>'
  //Show HTML code
  //alert(VADiv.innerHTML)
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout("VAIweiter()",1);
  }
  else
  {
    //Fortschritt.innerText=''
    VADiv.innerHTML=kopf+str1+'</table>';  
    VADiv.runtimeStyle.cursor='hand';
 
  }
} 

function VAILERF() 
{
 top.aktVAILZeile='';
  var root=VAIsource.firstChild;
  max = 250;
  ersteAusgabe=200;
  str1='';
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=300>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=300>'+
  '<col WIDTH=60><col WIDTH=50><col WIDTH=120><col WIDTH=80><col WIDTH=50><col WIDTH=30><tr>'+
  '<th id="VaiTH">Firma</th><th id="VaiTH">Leistungsart</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Bezeichnung</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH">Anzahl</th><th id="VaiTH">Kostenstelle</th><th id="VaiTH">GNS</th><th id="VaiTH">VerrKZ</th><th id="VaiTH">Typ</th>'+
  '</tr>';
  
  if(root.getElementsByTagName('Fehler')(0).text!='')
  {
    alert(root.getElementsByTagName('Fehler')(0).text);
  } 
  if(root.childNodes.length-1<ersteAusgabe) 
  {
    ersteAusgabe=root.childNodes.length-1;
  }
  if(root.childNodes.length-1>max)
  {
    anz=max;
    msg='Der Browser kann nur die ersten '+anz+' S�tze von '+(root.childNodes.length-1)+ ' S�tze anzeigen';
  }
  else
  {
    anz=root.childNodes.length-1;
    msg='';
  }
  for (i=0; i<ersteAusgabe; i++)   
  {
    str1+='<tr>'+root.childNodes(i).firstChild.text+'</tr>';
  }
  VADiv.innerHTML=kopf+str1+'</table>'
  //Show HTML code
  //alert(VADiv.innerHTML)
  VaiDiv.style.display='block';
  VADiv.style.display='block';
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout("VAIweiter()",1)
  }
  else
  {
    Fortschritt.innerText=''
    VADiv.innerHTML=kopf+str1+'</table>';  
    VADiv.runtimeStyle.cursor='hand'; 
  }
} 

function VAIweiter()
{  
  try
  {  
    var root=VAIsource.firstChild;
    var strChild='';
    var str2='';
    var strx='';
    for(var i=ersteAusgabe; i < anz; i++)
    {
      strChild = root.childNodes(i).firstChild.text;    
      //strx = strChild.substr(17,1);
      //if (strx == "V")
      //{
      //  str2+='<tr id="VaiListenelem">'+strChild+'</tr>';
      //  str2+=root.childNodes(i).firstChild.text+'</tr>';
      //}
      //else
      //{ 
        str2+=root.childNodes(i).firstChild.text+'</tr>';
      //}        
    }
    Fortschritt.innerText=msg;
    VADiv.innerHTML=kopf+str1+str2+'</table>';
    VADiv.runtimeStyle.cursor='hand';
  }
  catch(e)
  {
    alert('zu viele Datens�tze');
  }  
}

function VAIweiterMitButtonKOA()
{ 
//  try
  {  
    var root=VAIsource.firstChild;
    var strChild='';
    var str2='';
    var strx='';   
    for(var i=ersteAusgabe; i < anz; i++)
    {
      strChild = root.childNodes(i).firstChild.text;
      str2+=root.childNodes(i).firstChild.text+'</tr>';	
    }
    if(i < root.childNodes.length-1)
    {
      str2+=root.childNodes(i).firstChild.text; 
    }  
    Fortschritt.innerText=msg;
    ZeigeButtonKOA(i,root.childNodes.length-1);   
    VADiv.innerHTML=kopf+str1+str2+'</table>';  
  }
//  catch(e)
//  {
//    alert('zu viele Datens�tze')
//  }  
  //VAIsource=null 
}

function ZeigeButtonKOA(i,gesamt)
{
  var weiterbutton=zurueckbutton='';
  if(i < gesamt)
  {
    weiterbutton=''+
    '<button STYLE="position:absolute; left:750px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VADivUnten.innerHTML=\'\';VAILKOAneu('+i+','+(i+SaetzeProSeite)+')">'+    
    'n�chste Seite anzeigen</button>';    
  }
  if(i > SaetzeProSeite)
  {
    if(i-(SaetzeProSeite*2)<0) j=SaetzeProSeite*2    
    else j=i
    zurueckbutton=''+
    '<button STYLE="position:absolute; left:1px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VADivUnten.innerHTML=\'\';VAILKOAneu('+(j-(SaetzeProSeite*2))+','+(j-SaetzeProSeite)+')">'+    
    'vordere Seite anzeigen</button>';       
  }
  var s=''+
  zurueckbutton+'&nbsp;&nbsp;&nbsp;'+weiterbutton+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
  VADivUnten.innerHTML=s+' ';  
}

function VAIweiterMitButtonABR1()
{ 
//  try
  {  
    var root=VAIsource.firstChild;
    var strChild='';
    var str2='';
    var strx='';   
    for(var i=ersteAusgabe; i < anz; i++)
    {
      strChild = root.childNodes(i).firstChild.text;
      str2+=root.childNodes(i).firstChild.text+'</tr>';	
    }
    if(i < root.childNodes.length-1)
    {
      str2+=root.childNodes(i).firstChild.text; 
    }  
    Fortschritt.innerText=msg;
    ZeigeButtonABR1(i,root.childNodes.length-1);   
    VADiv.innerHTML=kopf+str1+str2+'</table>';  
  }
//  catch(e)
//  {
//    alert('zu viele Datens�tze')
//  }  
  //VAIsource=null 
}

function ZeigeButtonABR1(i,gesamt)
{
  var weiterbutton=zurueckbutton='';
  if(i < gesamt)
  {
    weiterbutton=''+
    '<button STYLE="position:absolute; left:750px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VADivUnten.innerHTML=\'\';VAILABR1neu('+i+','+(i+SaetzeProSeite)+')">'+    
    'n�chste Seite anzeigen</button>';    
  }
  if(i > SaetzeProSeite)
  {
    if(i-(SaetzeProSeite*2)<0) j=SaetzeProSeite*2    
    else j=i
    zurueckbutton=''+
    '<button STYLE="position:absolute; left:1px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VADivUnten.innerHTML=\'\';VAILABR1neu('+(j-(SaetzeProSeite*2))+','+(j-SaetzeProSeite)+')">'+    
    'vordere Seite anzeigen</button>';       
  }
  var s=''+
  zurueckbutton+'&nbsp;&nbsp;&nbsp;'+weiterbutton+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
  VADivUnten.innerHTML=s+' ';  
}

function VAIweiterMitButtonABR2()
{ 
//  try
  {  
    var root=VAIsource.firstChild;
    var strChild='';
    var str2='';
    var strx='';   
    for(var i=ersteAusgabe; i < anz; i++)
    {
      strChild = root.childNodes(i).firstChild.text;
      str2+=root.childNodes(i).firstChild.text+'</tr>';	
    }
    if(i < root.childNodes.length-1)
    {
      str2+=root.childNodes(i).firstChild.text; 
    }  
    Fortschritt.innerText=msg;
    ZeigeButtonABR2(i,root.childNodes.length-1);   
    VADiv.innerHTML=kopf+str1+str2+'</table>';  
  }
//  catch(e)
//  {
//    alert('zu viele Datens�tze')
//  }  
  //VAIsource=null 
}

function ZeigeButtonABR2(i,gesamt)
{
  var weiterbutton=zurueckbutton='';
  if(i < gesamt)
  {
    weiterbutton=''+
    '<button STYLE="position:absolute; left:750px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VADivUnten.innerHTML=\'\';VAILABR2neu('+i+','+(i+SaetzeProSeite)+')">'+    
    'n�chste Seite anzeigen</button>';    
  }
  if(i > SaetzeProSeite)
  {
    if(i-(SaetzeProSeite*2)<0) j=SaetzeProSeite*2    
    else j=i
    zurueckbutton=''+
    '<button STYLE="position:absolute; left:1px; HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VADivUnten.innerHTML=\'\';VAILABR2neu('+(j-(SaetzeProSeite*2))+','+(j-SaetzeProSeite)+')">'+    
    'vordere Seite anzeigen</button>';       
  }
  var s=''+
  zurueckbutton+'&nbsp;&nbsp;&nbsp;'+weiterbutton+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
  VADivUnten.innerHTML=s+' ';  
}