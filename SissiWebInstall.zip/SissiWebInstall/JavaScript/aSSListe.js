function SSL() 
{
//top.aktSLZeile='' 
  var root=SSsource.firstChild;
  str1=''
  
  kopf='<form name="SSListe"><table id="SSL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH="30"><col WIDTH="120"><col WIDTH="280"><col WIDTH="180">'

  if(root.getElementsByTagName("Fehler")(0).text!='')
  {
    alert(root.getElementsByTagName("Fehler")(0).text)
  }    
  for (i=0; i<root.childNodes.length-1; i++)   
  {
    str1+=root.childNodes(i).firstChild.text+'</tr>';
  }
  SSDiv.innerHTML=kopf+str1+'</table>'  
  SSDiv.style.display='block'  
  if(top.aktSLZeile!='')
  {  
    eval(top.aktSLZeile+'.runtimeStyle.backgroundColor="#99CCCC"')
  }
}

function a8(ParkID,HParkID,t)
{
  if(top.aktSLZeile!='') eval(top.aktSLZeile+'.runtimeStyle.backgroundColor="white"')  
  eval(t.id+'.runtimeStyle.backgroundColor="#99CCCC"')
  top.aktSLZeile=t.id

  r=window.showModalDialog("../Verfahren/Dialogs/VerfahrenDialog.htm",ParkID,"dialogHeight:140px;dialogWidth:200px;"+
                           "center:yes;help:No;resizable:No;status:No;scroll:no");
  switch (r)
  {  
    case 'Detail':                CallMaskeSchnittst(ParkID+"@A@"+HParkID+"@B@"+r+"@C@"+PersKey)                         
                                  break;    
    case 'Verfahrensmodul' :
    case 'Eingangsschnittstelle':
    case 'Ausgangsschnittstelle': {
                                    var save_r=r 
                                    if(chkPW('VF'))
                                    {
                                      CallMaskeSchnittst("Neu" +"@A@"+HParkID+"@B@"+save_r+"@C@"+PersKey)    
                                    }
                                    break;
                                  }
  }
}

function CallMaskeSchnittst(str)
{
  r=window.showModalDialog("../Verfahren/MaskeSchnittst.htm",
                           str,
                           "dialogHeight:620px;dialogWidth:730px;"+
                           "center:yes;help:No;resizable:No;status:No;scroll:No");
  if (typeof(r)!='undefined')
  {
    window.setTimeout("CallMaskeSchnittst('"+r+"')",1)    
  }
  //if(!top.Werner) 
  //LoadSchnittst(top.LastSchnittstParkID);
  //else 
  //LoadSchnittstelle(top.LastSchnittstParkID)      
}








