function chkPW(was)
{
  switch(was)
  {
    case 'IP':
    {
      if(logIP) return true
      else if(LogDialog(was)) return true
      break;
    }
    case 'IL':
    {
      if(logIL) return true
      else if(LogDialog(was)) return true
      break;
    }
    case 'VA':
    {
      if(logVA) return true
      else if(LogDialog(was)) return true
      break;
    }
    case 'UE':
    {
      if(logUE) return true
      else if(LogDialog(was)) return true
      break;
    }
    case 'AU':
    {
      if(logAU) return true
      else if(LogDialog(was)) return true
      break;
    }
    case 'VF':
    {
      if(logVF) return true
      else if(LogDialog(was)) return true
      break;
    }
    case 'PV':
    {
      if(logPV) return true
      else if(LogDialog(was)) return true
      break;
    }
    /*KK ENDE*/
  }
  return false
}

function LogDialog(was)
{
  r=window.showModalDialog("../Dialogs/LogOn.htm",
                            was,
                            "dialogHeight:130px;dialogWidth:300px;"+
                            "center:yes;help:No;resizable:No;status:No;");
  if(typeof(r)!='undefined')
  {
    if(r.substring(0,2)=='OK')
    {
      switch(r.substring(0,4))
      {
        case 'OKIP': logIP=true;break;
        case 'OKIL': logIL=true;break;
        case 'OKVA': logVA=true;break;
        case 'OKUE': logUE=true;break;
        case 'OKAU': logAU=true;break;
        case 'OKVF': logVF=true;break;
        case 'OKPV': logPV=true;break;
      }

      var a=r.indexOf('@')
      var b=r.indexOf('@@')
      var c=r.indexOf('@@@')
      var d=r.length


      // alert(r.substring(a+1,b))
      // alert(r.substring(b+2,c))
      // alert(r.substring(c+3,d))

      PersKey=r.substring(a+1,b)
      AenPersKey=r.substring(b+2,c)
      ASPIDKey=r.substring(c+3,d)
      return true;
    }
  }
  return false
}

function KennwortAendern()
{
  r=window.showModalDialog("../Dialogs/KennwortAendern.htm",
                            PersKey,
                            "dialogHeight:180px;dialogWidth:300px;"+
                            "center:yes;help:No;resizable:No;status:No;");
}