function VAI(von,bis,was) 
{ 
  var root=VAIsource.firstChild;  
  max =bis 
  SaetzeProSeite=(bis-von)
  ersteAusgabe=von+29 //ersten 29
  str1=''
    
  kopf='<form name="VAIListe"><table id="VAIL" border=0 cellspacing=0 cellpadding=0>'+
  '<col WIDTH=120><col WIDTH=200>'+
  '<col WIDTH=70><col WIDTH=70><col WIDTH=200>'+
  '<col WIDTH=100><col WIDTH=120><col WIDTH=80>'+
  '<col WIDTH=80><col WIDTH=50<col WIDTH=30><col WIDTH=30>'+
  '<tr>'+
  '<th id="VaiTH">Firma</th><th id="VaiTH">Leistungsart</th>'+
  '<th id="VaiTH">Gueltigab</th><th id="VaiTH">Gueltigbis</th><th id="VaiTH">Leistungsartbeschreibung</th>'+
  '<th id="VaiTHR">Betrag</th><th id="VaiTH" align="center">KST</th><th id="VaiTH">GNS</th>'+
  '<th id="VaiTH">EquipNr.</th><th id="VaiTH">VerrKZ</th><th id="VaiTH">Typ</th>'+
  '</tr>'
 
  if(root.getElementsByTagName("Fehler")(0).text!='') alert(root.getElementsByTagName("Fehler")(0).text)  
  
  
  if(root.childNodes.length-1<ersteAusgabe) ersteAusgabe=root.childNodes.length-1
  if(root.childNodes.length-1>max)
  {
    anz=max
    msg='Die S�tze '+(von+1)+' bis  '+anz+' von insgesamt '+(root.childNodes.length-1)+
        ' S�tzen werden angezeigt'         
  }
  else
  {
    anz=root.childNodes.length-1
    msg=''
  }
 
  var flag=true
  for(var i=von; i<ersteAusgabe; i++)   
  {
    if(i>400 && flag && root.childNodes(i).firstChild.text.substring(4,5)!='A') 
    {
      
    }
    else
    {
      flag=false    
      str1+=root.childNodes(i).firstChild.text+'</tr>';
    }  	
  }
  VaiDiv.innerHTML=kopf+str1+'</table>'
  
  VaiDiv.style.display='block'    
  VaiDiv.style.display='block'
  if(root.childNodes.length-1 > ersteAusgabe) 
  {
    window.setTimeout("VAIweiter('"+was+"')",1)
  }
  else
  {
    Fortschritt.innerText=''
    ZeigeButton(von+SaetzeProSeite,root.childNodes.length-1,was)
   
    VaiDiv.innerHTML=kopf+str1+'</table>'
    //VAIsource=null 
  }  
}  

function VAIweiter(was)
{ 
//  try
  {  
    var root=VAIsource.firstChild;
    var str2=''    
   
    for(var i=ersteAusgabe; i < anz; i++)
    {
      str2+=root.childNodes(i).firstChild.text+'</tr>';	
    }
    if(i < root.childNodes.length-1)
    {
      if(root.childNodes(i).firstChild.text.substring(4,5)!='A')
      {
        var ii=i
        var str5=''
        while(root.childNodes(ii).firstChild.text.substring(4,5)!='A' && ii < root.childNodes.length-1)
        {
          str5+=root.childNodes(ii).firstChild.text
          ii++
        }   
        str2+=str5
        str2+=root.childNodes(ii).firstChild.text   
      }
      else
      {
        str2+=root.childNodes(i).firstChild.text 
      } 
    }  
    Fortschritt.innerText=msg
    ZeigeButton(i,root.childNodes.length-1,was)   
    VaiDiv.innerHTML=kopf+str1+str2+'</table>'  
  }
//  catch(e)
//  {
//    alert('zu viele Datens�tze')
//  }  
  //VAIsource=null 
}

function ZeigeButton(i,gesamt,was)
{
  var weiterbutton=zurueckbutton=''
  if(i < gesamt)
  {
    weiterbutton=''+
    '<button STYLE="HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VaiDivUnten.innerHTML=\'\';IL('+i+','+(i+SaetzeProSeite)+',\''+was+'\')">'+    
    'N�chste Seite anzeigen</button>'    
  }
  if(i > SaetzeProSeite)
  {
    if(i-(SaetzeProSeite*2)<0) j=SaetzeProSeite*2    
    else j=i
    zurueckbutton=''+
    '<button STYLE="HEIGHT: 20px; WIDTH: 120px" '+
    'onClick="Fortschritt.innerText=\'\';'+
    'VaiDivUnten.innerHTML=\'\';IL('+(j-(SaetzeProSeite*2))+','+(j-SaetzeProSeite)+',\''+was+'\')">'+    
    'Vorige Seite anzeigen</button>'       
  }
  var s=''+
  zurueckbutton+' '+weiterbutton+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
  '<button onClick="DruckeInventar()" STYLE="HEIGHT: 20px; WIDTH: 120px">Drucken</button>'+
  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
   
  VaiDivUnten.innerHTML=s+' STYLE="HEIGHT: 20px; WIDTH: 120px">Excel</button>'  
}



