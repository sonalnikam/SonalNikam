function fnSave(n)
{
  try
  {
    with (top.oPersistLogDiv)
    {
      setAttribute("user",n);	
	  save("oXMLLogStore");
    }
  }
  catch(e) {}  
}

function fnLoad()
{
  try
  {
    top.oPersistLogDiv.load("oXMLLogStore");
    if(oPersistLogDiv.getAttribute("user")==null)
    {
      user.value=''
    }
    else
    {  
      user.value=oPersistLogDiv.getAttribute("user");
    }
  }   
  catch(e) {} 
}
