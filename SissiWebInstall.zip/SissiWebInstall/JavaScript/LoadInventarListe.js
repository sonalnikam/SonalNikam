function LoadInventarListe(n)
{ 
  var f=top.form
  if(false){}
  else
  {
    InventarDiv.style.display='block'
    IDiv.style.display='block'
    IDiv.innerHTML=''  
  
    ILsource = new ActiveXObject("Microsoft.XMLDOM")
     
    if(n=='ILPers')   
    {
      if(form3.Name.value.length==0 && form3.Vorname.value.length>0)
      {
        alert('Bitte Familiennamen eingeben')
        return false
      }
      else
      {         
        ILsource.load('../ASP/LoadInventarPers.asp'+
                     '?Name='     +form3.Name.value+
                     '&VName='    +form3.Vorname.value+
                     '&Persnr='   +form3.Persnr.value+
                     '&Abteilung='+escape(form3.Abteilung.value)+
                     '&Elemente=' +form3.Elemente.value+
                     '&Menge='    +form3.Menge.value+                
                     '&KST='      +form3.KST.value+
                     '&was=INVENTARLISTE');
      }                 
    }
    else
    { 
                   
      ILsource.load('../ASP/LoadInventarGeraet.asp'+
                   '?STO='      +escape(form4.STO.value)+
                   '&KSTVerr='  +form4.KSTVerr.value+
                   '&Betriebsbereich='+form4.Betriebsbereich.value+                   
                   '&Raum='     +form4.Raum.value+
                   '&Elemente=' +form4.Elemente.value+
                   '&Menge='    +form4.Menge.value+
                   '&FKZ='      +form4.FKZ.value+
                   '&KSTBesitz='+form4.KSTBesitz.value+
                   '&GeraeteArt='+escape(form4.GeraeteArt.value)+
                   '&ARBEITSPL='+escape(form4.ARBEITSPL1.value)+
                   '&was=INVENTARLISTE');              
    }
    
    top.Abbrechen=false    
    IDivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" '+
                        'onClick="top.Abbrechen=true">Suche abbrechen</button>'                    
    ILcheckReadyState("I",n)            
  }
}

function ILcheckReadyState(n,was)  
{ 
  var nr=n 
  var nr=n
  if(top.Abbrechen)
  { 
    top.Abbrechen=false
    IDivUnten.innerHTML=''
    Fortschritt.innerText=''
    
    alert('Suche abgebrochen')
  }
  else
  {
    if(ILsource.readyState ==4)
    { 
      IDivUnten.innerHTML='' 
      if (ILsource.parseError != 0)
      {
        IDiv.innerHTML=ILsource.parseError.reason
        //IDiv.innerHTML='Server �berlastet oder Treffermenge zu gross'
        
        Fortschritt.innerText=''
      }
      else 
      { 
        Fortschritt.innerText='Ausgabe wird vorbereitet - '+
                               (ILsource.firstChild.childNodes.length-1)+' S�tze'                       
        window.setTimeout("IL(0,500,'"+was+"')",1)
        
      }           
    }
    else 
    {
      if(nr.length<200) nr+="I"
      else nr="I"
      Fortschritt.innerText=nr
      window.setTimeout("ILcheckReadyState('"+nr+"','"+was+"')",100)    
    }
  }  
}
  
