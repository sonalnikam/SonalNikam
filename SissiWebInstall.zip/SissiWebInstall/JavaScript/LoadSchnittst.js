function LoadSchnittst(ParkID)
{ 
  top.LastSchnittstParkID=ParkID
  SchnittstDiv.style.display='block'
  SSDiv.style.display='block'
 
  SSsource = new ActiveXObject("Microsoft.XMLDOM")
  SSsource.async = false;
  SSsource.load('../Verfahren/ASP/LoadSchnittstellen.asp?PARKID='+ParkID); 
  if(SSsource.parseError != 0)
  {
    alert(SSsource.parseError.reason)
  }
  else
  {
    SB('0',true)
  }
}
