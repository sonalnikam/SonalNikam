function histoclose()
{
    window.close();
}

function checkIfDateFieldIsEmpty()
{
    if (form14.VONMONAT.value!=0 && form14.VONJAHR.value==0 && form14.BISMONAT.value==0 && form14.BISJAHR.value!=0)
    {
      alert('Ungueltige Kombination bei der Datumseingabe - bitte Dokumentation beachten');
      return false;
    }
    else if (form14.VONMONAT.value==0 && form14.VONJAHR.value!=0 && form14.BISMONAT.value!=0 && form14.BISJAHR.value==0)
    {
      alert('Ungueltige Kombination bei der Datumseingabe - bitte Dokumentation beachten');
      return false;
    }
    else if (form14.VONMONAT.value!=0 && form14.VONJAHR.value!=0 && form14.BISMONAT.value!=0 && form14.BISJAHR.value==0)
    {
      alert('Ungueltige Kombination bei der Datumseingabe - bitte Dokumentation beachten');
      return false;
    }
    else if (form14.VONMONAT.value==0 && form14.VONJAHR.value!=0 && form14.BISMONAT.value!=0 && form14.BISJAHR.value!=0)
    {
      alert('Ungueltige Kombination bei der Datumseingabe - bitte Dokumentation beachten');
      return false;
    }
}

function LoadVAIListe(n)
{ 
  var f=top.form;
  var vbTag;
  
  if(false){;}
  else
  {    
    VaiDiv.style.display='block';
    VADiv.style.display='block';
    //VADiv.runtimeStyle.cursor='wait';
    VADiv.innerHTML='';
    VAIsource = new ActiveXObject("Microsoft.XMLDOM");
    VAIsource.async = false;
                  
                  	
    if(n=='VAIKOA')
    {
      if(form13.Firma.value.length==0 && form13.KOAKZ.value.length>0)
      {
         alert('Bitte Firmennamen eingeben');
         return false;
      }
      else
      {  
         if (document.form13.dispAll.checked == true)
         {   
           //Show ASP parameters
           //alert("../ASP/LoadVAIKostenarten.asp?Firma="+form13.Firma.value+"&KOAKZ="+form13.KOAKZ.value+"&was=Alle");
           VAIsource.load('../ASP/LoadVAIKostenarten.asp'+
                    '?Firma='+form13.Firma.value+
                    '&KOAKZ='+form13.KOAKZ.value+
                    '&was=Alle');
           //alert ('KOA=' + VAIsource.xml + '');
         }
         else
         {
           //Show ASP parameters
           //alert("../ASP/LoadVAIKostenarten.asp?Firma="+form13.Firma.value+"&KOAKZ="+form13.KOAKZ.value+"&was=Kostenartenliste");
           VAIsource.load('../ASP/LoadVAIKostenarten.asp'+
                    '?Firma='+form13.Firma.value+
                    '&KOAKZ='+form13.KOAKZ.value+
                    '&was=Kostenartenliste');         
         }
         if(VAIsource.parseError != 0)
         {
           //VaiDiv.innerHTML='';
		   VaiDiv.innerHTML='  <div id="VADiv" class="AusgInnerDiv"></div>\n  <div id="VADivUnten" class="AusgUntenDiv"></div>\n';
           alert('Keinen Treffer gefunden 1');
           // nur f�r den Test:   
            alert(VAIsource.parseError.reason + ' - > ' + VAIsource.parseError.srcText);
			alert(VAIsource.sourceText);
           return;
         }
         else
         {
           //statt VAILKOA() und VAIcheckReadyState("I",n) -> nun nur mehr VAIcheckReadyStateNeu("I",n)
           VaiDiv.style.display='block';
           top.Abbrechen=false;
           VADivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>';
           //VADivUnten.innerHTML='';
           VAIcheckReadyStateNeu("I",n);
         }
      } //else
        // sollten irgendwann, undzwar im Zusammenhang mit msg, angezeigt werden 
        // Fortschritt.innerText='Legende: ROT=gel�schte, BLAU=abgelaufene, ORANGE=zuk�nftige und SCHWARZ=g�ltige Datens�tze';
    } //if(n=='VAIKOA')

    if(n=='VAIABR1')
    {
        if(form14.Firma.value.length==0)
        {
          alert('Bitte Firma eingeben');
          return false;
        }
        else
        {
          checkIfDateFieldIsEmpty();
          //Show ASP parameter
          //alert("LoadVAIAbrechnungsdatenAkt.asp,Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Akt");
          VAIsource.load('../ASP/LoadVAIAbrechnungsdatenAkt.asp'+
                       '?Firma='      +form14.Firma.value+
                       '&KOAKZ='      +form14.KOAKZ.value+
                       '&KST='        +form14.KST.value+
                       '&GNS='        +form14.GNS.value+
                       '&EQUINR='     +form14.EQUINR.value+
                       '&VONJAHR='    +form14.VONJAHR.value+
                       '&VONMONAT='   +form14.VONMONAT.value+
                       '&BISJAHR='    +form14.BISJAHR.value+
                       '&BISMONAT='   +form14.BISMONAT.value+                     
                       '&was=Akt');
          //alert ('Akt=' + VAIsource.xml + '');
          alert ('VAISource Parsing: '+ VAIsource.parseError);
          if(VAIsource.parseError != 0)
          {
            VaiDiv.innerHTML='';
            alert('keinen Treffer gefunden 2');
            // nur f�r den Test:    
             alert(VAIsource.parseError.reason);
            return;
          }
          else
          {
            // statt VAILABR('Akt') und  VAIcheckReadyState("I",n)-> nun nur VAIcheckReadyStateNeu("I",n)
            VaiDiv.style.display='block';
            top.Abbrechen=false
            VADivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>'
            VAIcheckReadyStateNeu("I",n);
            //VADivUnten.innerHTML=''
          }
        }                 
      } //if(n=='VAIABR1')
      if(n=='VAIABR2')
      {
        if(form14.Firma.value.length==0 && form14.KOAKZ.value.length>0 && form14.KST.value.length>0 && form14.GNS.value.length>0 && form14.EQUINR.value.length>0)
        {
          alert('Bitte Daten eingeben');
          return false;
        }
        else
        {
          checkIfDateFieldIsEmpty();
          //Show ASP parameters
          //alert("LoadVAIAbrechnungsdatenHisto.asp,Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Histo");
          VAIsource.load('../ASP/LoadVAIAbrechnungsdatenHisto.asp'+
                       '?Firma='      +form14.Firma.value+
                       '&KOAKZ='      +form14.KOAKZ.value+
                       '&KST='        +form14.KST.value+
                       '&GNS='        +form14.GNS.value+
                       '&EQUINR='     +form14.EQUINR.value+
                       '&VONJAHR='    +form14.VONJAHR.value+
                       '&VONMONAT='   +form14.VONMONAT.value+
                       '&BISJAHR='    +form14.BISJAHR.value+
                       '&BISMONAT='   +form14.BISMONAT.value+                     
                       '&was=Histo');
          //alert ('Histo=' + VAIsource.xml + '');
          if(VAIsource.parseError != 0)
          {
            VaiDiv.innerHTML='';
            alert('keinen Treffer gefunden 3');
            // nur f�r den Test:    
            //alert(VAIsource.parseError.reason);
            return;
          }
          else
          {
            //statt VAILABR('Histo') und VAIcheckReadyState("I",n) -> nun nur VAIcheckReadyStateNeu("I",n)
            VaiDiv.style.display='block';
            top.Abbrechen=false;
            VADivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>';
            VAIcheckReadyStateNeu("I",n);
            //VADivUnten.innerHTML=''
          }
        }                 
      } //if(n=='VAIABR2')
    
      if(n=='VAIABR3')
      { 
        //Freigabe ist an den Tagen 28.-31. des Monats nicht erlaubt
        now = new Date(); 
        vbTag = now.getDate();
               
        if((vbTag == "28") || (vbTag == "29") || (vbTag == "30") || (vbTag == "31"))
        {
          alert('Keine Freigabe an diesem Tag erlaubt');
          //document.form14.btnFREIGABE.disabled=true;
          return false;          
        }
        else 
        {  
          if(form14.Firma.value.length==0 && form14.KOAKZ.value.length>0 && form14.KST.value.length>0 && form14.GNS.value.length>0 && form14.EQUINR.value.length>0)
          {
            alert('Bitte Daten eingeben');
            return false;
          }
          else
          {
            if((form14.VONMONAT.value.length>0) || (form14.VONJAHR.value.length>0) || (form14.BISMONAT.value.length>0) || (form14.BISJAHR.value.length>0))
            {
              //Abrechnungslauf f�r einen bestimmten Monat: Hier ist es m�glich, in der Maske einen (mehrere) Monat(e) und ggf auch eine KST zu selektieren 
              //Show yesno-window before really starting with FREIGABE 
              AuswahlFreigabeMitSelektion()
            }
            else
            { 
              //Abrechnungslauf f�r Vormonat, keine Selektion
              //Show yesno-window before really starting with FREIGABE 
              AuswahlFreigabe()
            }
            //falls Buttons oder Texte von Vorfunktionen vorhanden sind, werden diese entfernen
            Fortschritt.innerText='';
            VADivUnten.innerHTML='';          
          }
        }  //if (Systemdatum...)
        
      } //if(n=='VAIABR3')    
      
      if(n=='VAIABR4')
      {
        if(form14.Firma.value.length==0 && form14.KOAKZ.value.length>0 && form14.KST.value.length>0 && form14.GNS.value.length>0 && form14.EQUINR.value.length>0)
        {
          alert('Bitte Daten eingeben');
          return false;
        }
        else
        {
          checkIfDateFieldIsEmpty();
          //Show ASP parameters
          //alert("LoadVAIAbrechnungsdatenExcel.asp?Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Akt");
          if (document.form14.ExcelStatus.value == "Akt")
          {
            // alert("LoadVAIAbrechnungsdatenAktExcel.asp?Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Akt");
            window.open('../Asp/LoadVAIAbrechnungsdatenAktExcel.asp'+
                       '?Firma='      +form14.Firma.value+
                       '&KOAKZ='      +form14.KOAKZ.value+
                       '&KST='        +form14.KST.value+
                       '&GNS='        +form14.GNS.value+
                       '&EQUINR='     +form14.EQUINR.value+
                       '&VONJAHR='    +form14.VONJAHR.value+
                       '&VONMONAT='   +form14.VONMONAT.value+
                       '&BISJAHR='    +form14.BISJAHR.value+
                       '&BISMONAT='   +form14.BISMONAT.value+                     
                       '&was=EXCEL');
          }
          else if (document.form14.ExcelStatus.value == "Histo")
          {
             // alert("LoadVAIAbrechnungsdatenHistoExcel.asp?Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Histo");
             window.open('../Asp/LoadVAIAbrechnungsdatenHistoExcel.asp'+
                       '?Firma='      +form14.Firma.value+
                       '&KOAKZ='      +form14.KOAKZ.value+
                       '&KST='        +form14.KST.value+
                       '&GNS='        +form14.GNS.value+
                       '&EQUINR='     +form14.EQUINR.value+
                       '&VONJAHR='    +form14.VONJAHR.value+
                       '&VONMONAT='   +form14.VONMONAT.value+
                       '&BISJAHR='    +form14.BISJAHR.value+
                       '&BISMONAT='   +form14.BISMONAT.value+                     
                       '&was=EXCEL');
          }
          else
          {
            // AUCH F�R DIE SCHNELLSUCHE soll eine EXCEL-Liste erzeugt werden k�nnen 
            // alert("LoadVAIAbrechnungsdatenAktExcel.asp?Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Akt");
            window.open('../Asp/LoadVAIAbrechnungsdatenAktExcel.asp'+
                       '?Firma='      +form14.Firma.value+
                       '&KOAKZ='      +form14.KOAKZ.value+
                       '&KST='        +form14.KST.value+
                       '&GNS='        +form14.GNS.value+
                       '&EQUINR='     +form14.EQUINR.value+
                       '&VONJAHR='    +form14.VONJAHR.value+
                       '&VONMONAT='   +form14.VONMONAT.value+
                       '&BISJAHR='    +form14.BISJAHR.value+
                       '&BISMONAT='   +form14.BISMONAT.value+                     
                       '&was=EXCEL');
          }
          //falls Buttons oder Texte von Vorfunktionen vorhanden sind, werden diese entfernen
          Fortschritt.innerText='';
          VADivUnten.innerHTML='';
        }                 
      } //if(n=='VAIABR4')
      if(n=='VAIABR5')
      {
        if(form14.Firma.value.length==0)
        {
          alert('Bitte Firma eingeben');
          return false;
        }
        else
        {
          checkIfDateFieldIsEmpty();
          //Show ASP parameter
          //alert("LoadVAIAbrechnungsdatenAnzAkt.asp,Firma="+form14.Firma.value+"&KOAKZ="+form14.KOAKZ.value+"&KST="+form14.KST.value+"&GNS="+form14.GNS.value+"&EQUINR="+form14.EQUINR.value+"&VONJAHR="+form14.VONJAHR.value+"&VONMONAT="+form14.VONMONAT.value+"&BISJAHR="+form14.BISJAHR.value+"&BISMONAT="+form14.BISMONAT.value+"&was=Akt");
          VAIsource.load('../ASP/LoadVAIAbrechnungsdatenAnzAkt.asp'+
                       '?Firma='      +form14.Firma.value+
                       '&KOAKZ='      +form14.KOAKZ.value+
                       '&KST='        +form14.KST.value+
                       '&GNS='        +form14.GNS.value+
                       '&EQUINR='     +form14.EQUINR.value+
                       '&VONJAHR='    +form14.VONJAHR.value+
                       '&VONMONAT='   +form14.VONMONAT.value+
                       '&BISJAHR='    +form14.BISJAHR.value+
                       '&BISMONAT='   +form14.BISMONAT.value+                     
                       '&was=Akt');
           //setze ExcelStatus auf Akt, da immer akuitelle Daten gelesen werden und beim EXCEL Export auf die
           //aktuellen Daten zugegriffen werden muss
           document.form14.ExcelStatus.value = "Akt";
          alert ('AnzAkt=' + VAIsource.xml + '');
          alert ('VAISource Parsing: '+ VAIsource.parseError);
          
          if(VAIsource.parseError != 0)
          {
            VaiDiv.innerHTML='';
            alert('keinen Treffer gefunden 4');
            // nur f�r den Test:    
             alert(VAIsource.parseError.reason);
            return;
          }
          else
          {
            // statt VAILABR('Anz') und  VAIcheckReadyState("I",n)-> nun nur VAIcheckReadyStateNeu("I",n)
            VaiDiv.style.display='block';
            top.Abbrechen=false
            VADivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>'
            VAIcheckReadyStateNeu("I",n);
            //VADivUnten.innerHTML=''
          }
        }                 
      } //if(n=='VAIABR5')  
      
    if(n=='VAIKST')
    {
        if(form15.Firma.value.length==0 || form15.KSTalt.value.length==0)
        {
          alert('Bitte Pflichtfelder Firmennamen, sowie alte und neue Kostenstelle eingeben');
          document.form15.btnVAIKST2.disabled=true;
          return false;
        }
        else if(form15.KSTneu.value=="ALLE")
        {
          alert('Bitte neue Kostenstelle ausw�hlen');
          document.form15.btnVAIKST2.disabled=true;
          return false;
        }
        else
        {         
          //Show ASP parameters
          //alert("LoadVAIKSTNeu.asp,Firma="+form15.Firma.value+"&BEREICHKZ="+form15.BEREICHKZ.value+"&KSTALT="+form15.KSTALT.value+"&KSTneu="+form15.KSTneu.value+"&was=Kostenstellenliste");
          VAIsource.load('../ASP/LoadVAIKSTNeu.asp'+
                       '?Firma='      +form15.Firma.value+
                       '&BEREICHKZ='  +form15.BereichKZ.value+
                       '&KSTALT='     +form15.KSTalt.value+
                       '&KSTNEU='     +form15.KSTneu.value+
                       '&was=Kostenstellenliste');

          //alert ('KST=' + VAIsource.xml + '');
          if(VAIsource.parseError != 0)
          {
            VaiDiv.innerHTML='';
            alert('keinen Treffer gefunden 5');
            // nur f�r den Test:      
            //alert(VAIsource.parseError.reason)
            return;
          }
          else
          {
            VAILKST();
            VaiDiv.style.display='block';
            top.Abbrechen=false
            VADivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>'
            VAIcheckReadyState("I",n)
            //VADivUnten.innerHTML=''
          }
        }                 
    } //if(n=='VAIKST')
    
    if(n=='VAIKST2')
    {
        if(form15.Firma.value.length==0 || form15.KSTalt.value.length==0)
        {
          alert('Bitte Pflichtfelder Firmennamen, sowie alte und neue Kostenstelle eingeben');
          document.form15.btnVAIKST2.disabled=true;
          return false;
        }
        else if(form15.KSTneu.value=="ALLE")
        {
          alert('Bitte neue Kostenstelle ausw�hlen');
          document.form15.btnVAIKST2.disabled=true;
          return false;
        }
        else
        {
          //Show ASP parameters
          //alert ('LoadVAIKSTNeu.asp?Firma='+form15.Firma.value+'&BEREICHKZ='+form15.BereichKZ.value+'&KSTALT='+form15.KSTalt.value+'&KSTNEU='+form15.KSTneu.value+'&was=KostenstellenUpdate');
          VAIsource.load('../ASP/LoadVAIKSTNeu.asp'+
                       '?Firma='      +form15.Firma.value+
                       '&BEREICHKZ='  +form15.BereichKZ.value+
                       '&KSTALT='     +form15.KSTalt.value+
                       '&KSTNEU='     +form15.KSTneu.value+
                       '&was=KostenstellenUpdate');
          //alert ('KST2=' + VAIsource.xml + '');
          if(VAIsource.parseError != 0)
          {
            VaiDiv.innerHTML='';
            alert('keinen Treffer gefunden 6');  
            // nur f�r den Test:    
            // alert(VAIsource.parseError.reason);
            return;
          }
          else
          {
            VAILKST();
            VaiDiv.style.display='block';
            top.Abbrechen=false
            VADivUnten.innerHTML='<button STYLE="HEIGHT: 20px; WIDTH: 100px" onClick="top.Abbrechen=true">Suche abbrechen</button>'
            VAIcheckReadyState("I",n)
            //VADivUnten.innerHTML=''
          }
        }                 
    } //if(n=='VAIKST2')
    
    if(n=='VAIERF')
    {
      {	 //Datum - �berpr�fung
	      strGueltigAb = document.form16.Gueltigab.value;
	      strGueltigBis = document.form16.Gueltigbis.value;
	      
	      leistungsArtGueltigAb = new Date();
	      leistungsArtGueltigBis = new Date();
	      rE = new RegExp("^[0-3]\\d.[0-1]\\d.[1-2]\\d\\d\\d$");
	      
	      try
	      {      	
	      	if(!rE.test(strGueltigAb))
	      	{
	      	  alert('Gueltigab darf nicht leer sein und muss ein korrektes Datum im Format "dd.mm.yyyy" enthalten!');
	      	  return false;
	      	}
	      	else
	      	  leistungsArtGueltigAb.setFullYear(strGueltigAb.substring(6), strGueltigAb.substring(3,5), strGueltigAb.substring(0,2)); //yyyy, mm, dd
	      }
	      catch(err)
	      {
	      	alert('Gueltigab enth�lt kein korrektes Datum!');
	      	return false;
	      }
	      
	      
	      try
	      {      	
	      	if(!rE.test(strGueltigBis))
	      	{
	      	  alert('Gueltigbis darf nicht leer sein und muss ein korrektes Datum in Format "dd.mm.yyyy" enthalten!');
	      	  return false;
	      	}
	      	else
	      	  leistungsArtGueltigBis.setFullYear(strGueltigBis.substring(6), strGueltigBis.substring(3,5), strGueltigBis.substring(0,2)); //yyyy, mm, dd
	      }
	      catch(err)
	      {
	      	alert('Gueltigbis enth�lt kein korrektes Datum!');
	      	return false;
	      }
	      
	      
	      if(leistungsArtGueltigBis < leistungsArtGueltigAb)
	      {
	      	alert('Gueltigbis Datum muss gr�sser sein als Gueltigab Datum!');
	      	return false;
	      }
      }
      
      if (document.form16.dispPOOL.checked == true && document.form16.dispPOOLKST.checked == true)
      {
        alert('-mehrere GNS- sowie -mehrere KST- gleichzeitig nicht erlaubt');
        return false;
      }
      else
      {
    
    
        if (form16.Typ.value == 'EG')
        {
          //GNS ist Pflichtfeld. Wenn aber das Hackerl f�r mehrere GNS gesetzt ist, dann braucht man keine GNS bei der Ersterfassung eingeben
          if (document.form16.dispPOOL.checked == true)
          {
           if (form16.Firma.value.length==0 || form16.Betrag.value.length==0 || form16.Leistungsart.value.length==0)
           {
             alert('Bitte Pflichtfelder Firma, Leistungsart und Betrag eingeben');
             return false;
           }
          }
          else
          { 
           if (form16.Firma.value.length==0 || form16.Betrag.value.length==0 || form16.Leistungsart.value.length==0 || form16.GNS.value.length==0)
           {
             alert('Bitte Pflichtfelder Firma, Leistungsart, GNS und Betrag eingeben');
             return false;
           }
           if (form16.GNS.value.length>0 && form16.GNS.value.substring(0,2) != 'at')
           {
             alert('GNS muss mit at beginnen');
             return false;
           }
          }
          if (form16.KST.value.length>0)
          {
            alert('Eingabe von KST ist f�r diesen Leistungstyp nicht erlaubt');
            return false;
          }          
        }
        else if (form16.Typ.value == 'EK')
        {
          //KOART (Kostenstelle) ist ein Pflichtfeld. Wenn aber das Hackerl f�r mehrere KST gesetzt ist, dann braucht man keine KST bei der Ersterfassung eingeben
          if (document.form16.dispPOOLKST.checked == true)
          {
           if (form16.Firma.value.length==0 || form16.Betrag.value.length==0 || form16.Leistungsart.value.length==0)
           {
             alert('Bitte Pflichtfelder Firma, Leistungsart und Betrag eingeben');
             return false;
           }
          }
          else
          { 
           if(form16.Firma.value.length==0 || form16.Betrag.value.length==0 || form16.Leistungsart.value.length==0 || form16.KST.value.length==0)
           {
             alert('Bitte Pflichtfelder Firma, Leistungsart, KST und Betrag eingeben');
             return false;
           }
           if (form16.KST.value.length>0 && form16.KST.value.substring(0,6) != 'VAI - ')
           {
             alert('KST muss mit VAI beginnen');
             return false;
           }
          }
          if (form16.GNS.value.length>0)
          {
            alert('Eingabe von GNS ist f�r diesen Leistungstyp nicht erlaubt');
            return false;
          }  
        }
        else if (form16.Typ.value == 'SM')
        {
          if (form16.Firma.value.length==0 || form16.Betrag.value.length==0 || form16.Leistungsart.value.length==0)
           {
             alert('Bitte Pflichtfelder Firma, Leistungsart und Betrag eingeben');
             return false;
           }
           
          //KOART sowie GNS sind keine Pflichtfelder! Wenn aber das Hackerl f�r mehrere KST bzw. GNS gesetzt ist, dann darf man keine KST bzw. GNS bei der Ersterfassung eingeben
          if (document.form16.dispPOOLKST.checked == true || document.form16.dispPOOL.checked == true)
          {
            if (form16.KST.value.length>0 || form16.GNS.value.length>0) 
            {
              alert('Eingabe von KST und GNS nicht erlaubt, wenn das Hackerl f�r mehrere KST bzw. GNS gesetzt ist!');
              return false;
            } 
          }
          else
          {
            if (form16.KST.value.length>0 && form16.GNS.value.length>0) 
            {
              alert('Eingabe von KST und GNS gleichzeitig nicht erlaubt');
              return false;
            } 
            else
            { 
              if (document.form16.dispPOOL.checked == true && form16.KST.value.length>0)
              {
                alert('-mehrere GNS- mit einer KST gleichzeitig nicht erlaubt');
                return false;
              }
              if (document.form16.dispPOOLKST.checked == true && form16.GNS.value.length>0)
              {
                alert('-mehrere KST- mit einer GNS gleichzeitig nicht erlaubt');
                return false;
              }
              if (form16.KST.value.length>0 && form16.KST.value.substring(0,6) != 'VAI - ')
              {
                alert('KST muss mit VAI beginnen');
                return false;
              }
              if (form16.GNS.value.length>0 && form16.GNS.value.substring(0,2) != 'at')
              {
                alert('GNS muss mit at beginnen');
                return false;
              }
            }
          }
        }  
//alt: �nderungsdatum 10.12. 2008      
//alt        {
//alt          //GNS ist kein Pflichtfeld
//alt           if(form16.Firma.value.length==0 || form16.Betrag.value.length==0 || form16.Leistungsart.value.length==0)
//alt           {
//alt               alert('Bitte Pflichtfelder Firma, Leistungsart und Betrag eingeben');
//alt               return false;
//alt           }
//alt           // bei diesem Typ ist weder GNS noch KST erlaubt, neu am 11.11. 2008
//alt           if(form16.GNS.value.length==0 && form16.KST.value.length==0)
//alt           {
//alt           }
//alt           else
//alt            {
//alt                alert('Bei Typ SM keine Eingabe KST / GNS erlaubt -> verwenden Sie bitte den Typ EK oder EG');
//alt                return false;
//alt            }          
//alt         }  
           //Show ASP parameters
           if (form16.Typ.value == 'EG')
           {
             if (document.form16.dispPOOL.checked == true)
             {
              if (form16.GNS.value.length==0)
              {
                //alert("../ASP/LoadVAIEinmalverrechnung.asp?Firma="+form16.Firma.value+"&KOART="+form16.Leistungsart.value+"&Gueltigab="+form16.Gueltigab.value+"&GNS="+form16.GNS.value+"&Betrag="+form16.Betrag.value+"&Bezeichnung="+form16.Bezeichnung.value+"&KST="+form16.KST.value+"&Gueltigbis="+form16.Gueltigbis.value+"&Typ="+form16.Typ.value+"&was=EG");
                VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+ 
                     '&KOARTANZ='    +form16.KOARTANZ.value+ 
                     '&Pool=Pool'+  
                     '&PoolKST=keinPool'+                             
                     '&was=EG');
              }
              else
              {  
                alert('Bitte entweder GNS eingeben und -mehrere GNS- deaktivieren ODER keine GNS eingeben und -mehrere GNS- aktivieren');
                return false;
              }       
             }
             else
             {
              //alert("../ASP/LoadVAIEinmalverrechnung.asp?Firma="+form16.Firma.value+"&KOART="+form16.Leistungsart.value+"&Gueltigab="+form16.Gueltigab.value+"&GNS="+form16.GNS.value+"&Betrag="+form16.Betrag.value+"&Bezeichnung="+form16.Bezeichnung.value+"&KST="+form16.KST.value+"&Gueltigbis="+form16.Gueltigbis.value+"&Typ="+form16.Typ.value+"&was=EG");
              VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+ 
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=keinPool'+   
                     '&PoolKST=keinPool'+                                          
                     '&was=EG');
             }                   
           }
           else if (form16.Typ.value == 'EK')
           {
             if (document.form16.dispPOOL.checked == true)
             {
              if (form16.GNS.value.length==0)
              {
                alert('Bitte GNS eingeben oder -mehrere GNS- deaktivieren');
                return false;
              }
              else
              {                
              //alert("../ASP/LoadVAIEinmalverrechnung.asp?Firma="+form16.Firma.value+"&KOART="+form16.Leistungsart.value+"&Gueltigab="+form16.Gueltigab.value+"&GNS="+form16.GNS.value+"&Betrag="+form16.Betrag.value+"&Bezeichnung="+form16.Bezeichnung.value+"&KST="+form16.KST.value+"&Gueltigbis="+form16.Gueltigbis.value+"&Typ="+form16.Typ.value+"&was=EK");
              VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+  
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=Pool'+  
                     '&PoolKST=keinPool'+                                            
                     '&was=EK'); 
              }         
             }
             else
             {
               if (document.form16.dispPOOLKST.checked == true)
               {
                 if (form16.KST.value.length==0)
                 {
                   VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+  
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=keinPool'+  
                     '&PoolKST=Pool'+                                            
                     '&was=EK'); 
                 }
                 else
                 {                
                   alert('Bitte KST eingeben oder -mehrere KST- deaktivieren');
                   return false;
                 }
               }
               else
               {             
                 VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+  
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=keinPool'+
                     '&PoolKST=keinPool'+                                               
                     '&was=EK'); 
               }             
             }
           }
           else if (form16.Typ.value == 'SM') 
           {
             if (document.form16.dispPOOL.checked == true)
             {
              if (form16.GNS.value.length==0)
              {                
              //alert("../ASP/LoadVAIEinmalverrechnung.asp?Firma="+form16.Firma.value+"&KOART="+form16.Leistungsart.value+"&Gueltigab="+form16.Gueltigab.value+"&GNS="+form16.GNS.value+"&Betrag="+form16.Betrag.value+"&Bezeichnung="+form16.Bezeichnung.value+"&KST="+form16.KST.value+"&Gueltigbis="+form16.Gueltigbis.value+"&Typ="+form16.Typ.value+"&was=EK");
              VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+  
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=Pool'+  
                     '&PoolKST=keinPool'+                                            
                     '&was=S'); 
              }
               else
              {  
                alert('Bitte entweder GNS eingeben und -mehrere GNS- deaktivieren ODER keine GNS eingeben und -mehrere GNS- aktivieren');
                return false;
              }                  
             }
             else
             {
               if (document.form16.dispPOOLKST.checked == true)
               {
                 if (form16.KST.value.length==0)
                 {
                   VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+  
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=keinPool'+  
                     '&PoolKST=Pool'+                                            
                     '&was=S'); 
                 }
                 else
                 {                
                alert('Bitte entweder KST eingeben und -mehrere KST- deaktivieren ODER keine KST eingeben und -mehrere KST- aktivieren');
                return false;
                 }
               }
               else
               {             
                 VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
                     '?Firma='       +form16.Firma.value+
                     '&KOART='       +form16.Leistungsart.value+
                     '&GNS='         +form16.GNS.value+
                     '&Gueltigab='   +form16.Gueltigab.value+
                     '&Betrag='      +form16.Betrag.value+
                     '&Bezeichnung=' +form16.Bezeichnung.value+
                     '&KST='         +form16.KST.value+
                     '&Gueltigbis='  +form16.Gueltigbis.value+
                     '&Typ='         +form16.Typ.value+  
                     '&KOARTANZ='    +form16.KOARTANZ.value+
                     '&Pool=keinPool'+
                     '&PoolKST=keinPool'+                                               
                     '&was=S'); 
               }             
             }
           }           
//alt 10.12. 2008           
//alt           {
//alt             if ((document.form16.dispPOOL.checked == true) || (document.form16.dispPOOLKST.checked == true))
//alt             {
//alt               alert('Benutzung von -mehrere GNS- sowie -mehrere KST- f�r diesen Typ nicht erlaubt');
//alt                return false;
//alt             }
//alt             else
//alt             {    
//alt               //alert("../ASP/LoadVAIEinmalverrechnung.asp?Firma="+form16.Firma.value+"&KOART="+form16.Leistungsart.value+"&Gueltigab="+form16.Gueltigab.value+"&GNS="+form16.GNS.value+"&Betrag="+form16.Betrag.value+"&Bezeichnung="+form16.Bezeichnung.value+"&KST="+form16.KST.value+"&Gueltigbis="+form16.Gueltigbis.value+"&Typ="+form16.Typ.value+"&was=S");
//alt               VAIsource.load('../ASP/LoadVAIEinmalverrechnung.asp'+
//alt                     '?Firma='       +form16.Firma.value+
//alt                     '&KOART='       +form16.Leistungsart.value+
//alt                     '&GNS='         +form16.GNS.value+
//alt                     '&Gueltigab='   +form16.Gueltigab.value+
//alt                     '&Betrag='      +form16.Betrag.value+
//alt                     '&Bezeichnung=' +form16.Bezeichnung.value+
//alt                     '&KST='         +form16.KST.value+
//alt                     '&Gueltigbis='  +form16.Gueltigbis.value+
//alt                     '&Typ='         +form16.Typ.value+
//alt                     '&KOARTANZ='    +form16.KOARTANZ.value+ 
//alt                     '&Pool=keinPool'+ 
//alt                     '&PoolKST=keinPool'+                                               
//alt                     '&was=S'); 
//alt             }                                   
//alt           }  
         
           //alert ('ERF=' + VAIsource.xml + '');         
           if(VAIsource.parseError != 0)
           {
               VaiDiv.innerHTML='';
               alert('Keinen Treffer gefunden 7');
               // nur f�r den Test:   
               //alert(VAIsource.parseError.reason);
               return;
           }
           else
           {
              VAILERF();
              VaiDiv.style.display='block';
              VADivUnten.innerHTML='';                  
              //nur f�r den Test
              //alert ('alles OK');
           }
      }     
    } //if(n=='VAIERF')
    if (n=='VAIMON')
    {
    	//var r
    	//r=window.showModalDialog("../ASP/LoadVAIMonatslauf.asp","","dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");)
    	
    	
    	
    	   if(VAIsource.parseError != 0)
           {
               VaiDiv.innerHTML='';
               alert('Ein Problem ist aufgetreten, bitte wenden Sie sich an ihren Administrator!');
               // nur f�r den Test:   
               //alert(VAIsource.parseError.reason);
               //return;
           }
           else
           {
              /*
              //Freigabe ist an den Tagen 28.-31. des Monats nicht erlaubt
        	now = new Date(); 
        	vbTag = now.getDate();
               
        	if((vbTag == "24") || (vbTag == "25") || (vbTag == "26") || (vbTag == "27") || (vbTag == "28") || (vbTag == "29") || (vbTag == "30") || (vbTag == "31"))
        	//if((vbTag >= "10") & (vbTag <= "31")
		{
		  document.form18.btnVAIMON.disabled=true;
		  //return false;
		}
		else
		{
		  AuswahlFreigabeMonatslauf()	
		}
		*/
		
		AuswahlFreigabeMonatslauf()
		              
              VaiDiv.style.display='block';
              Fortschritt.innerText='';
              VADivUnten.innerHTML='';
              //nur f�r den Test
              //alert ('alles OK');
           } 
    }//if(n=='VAIMON')
  } //else bei if(false){}
} //LoadVAIListe(n)

function VAIcheckReadyState(n,MenueWas)  
{ 
  var nr=n;
  var was=MenueWas;
  //alert('n='+n+', was='+was+'');
  if(top.Abbrechen)
  { 
    top.Abbrechen=false;
    //VADivUnten.innerHTML='';
    Fortschritt.innerText='';
    alert('Suche abgebrochen');
  }
  else
  {
    if(VAIsource.readyState ==4)
    { 
      VADivUnten.innerHTML=''; 
      if (VAIsource.parseError != 0)
      {
        VADiv.innerHTML=VAIsource.parseError.reason;
        VADiv.innerHTML='Server �berlastet oder Treffermenge zu gross';
        Fortschritt.innerText='';
        return;
      }
      else 
      { 
//        Fortschritt.innerText='Ausgabe wird vorbereitet - '+
//                               (VAIsource.firstChild.childNodes.length-1)+' S�tze'
//        N�chste Zeile wurde auskommentiert, da wegen der XML Darstellung in einer zus�tzlichen Zeile Infos wie Gesamtsumme eingef�gt wurden. 
//        Fortschritt.innerText=''+ (VAIsource.firstChild.childNodes.length-1)+' S�tze gefunden'
        VADivUnten.innerHTML='';
        //alert('Fortschritt: '+Fortschritt.innertext);         
        window.setTimeout("VAIcheckReadyState(0,200,'"+was+"')",1);
        }
    }
    else //readyState <> 4
    {
      if(nr.length<200) {nr+="I";}
      else {nr="I";}
      Fortschritt.innerText=nr;
      window.setTimeout("VAIcheckReadyState('"+nr+"','"+was+"')",100);
    } //f(VAIsource.readyState ==4)
  }  //if(top.Abbrechen)
} //function VAIcheckReadyState(n,MenueWas)


function VAIcheckReadyStateNeu(n,was)  
{ 
  var nr=n; 
  if(top.Abbrechen)
  { 
    top.Abbrechen=false;
    VADivUnten.innerHTML='';
    Fortschritt.innerText='';    
    alert('Suche abgebrochen');
  }
  else
  {
    if(VAIsource.readyState ==4)
    { 
      VADivUnten.innerHTML=''; 
      if (VAIsource.parseError != 0)
      {
        VADiv.innerHTML=VAIsource.parseError.reason;
        VADiv.innerHTML='Server �berlastet oder Treffermenge zu gross';
        Fortschritt.innerText='';
        return;
      }
      else 
      { 
        Fortschritt.innerText='Ausgabe wird vorbereitet - '+
                              (VAIsource.firstChild.childNodes.length-1)+' S�tze';                                

        if(was=='VAIKOA')
        {
          window.setTimeout("VAILKOAneu(0,200)",1); 
        }
        if(was=='VAIABR1')
        {
          window.setTimeout("VAILABR1neu(0,200)",1); 
        }
        if(was=='VAIABR2')
        {
          window.setTimeout("VAILABR2neu(0,200)",1); 
        } 
        if(was=='VAIABR5')
        {
          window.setTimeout("VAILABR1neu(0,200)",1); 
        }      
      }           
    }
    else 
    {
      if(nr.length<200) {nr+="I";}
      else {nr="I";}
      Fortschritt.innerText=nr;
      window.setTimeout("VAIcheckReadyStateNeu('"+nr+"','"+was+"')",100);    
    }
  }  
}


function a33(koartid, firma, kostenart, typ, gueltigab, gueltigbis, bezeichnung, betrag, koartanz, kst, gns, mehrere_gns_kz, mehrere_kst_kz, sendkst, kostenartSAP)
{
  a13(koartid, firma, kostenart, typ, gueltigab, gueltigbis, bezeichnung, betrag, koartanz, kst, gns, mehrere_gns_kz, mehrere_kst_kz, sendkst, kostenartSAP)
}


function a13(koartid, firma, kostenart, typ, gueltigab, gueltigbis, bezeichnung, betrag, koartanz, kst, gns, mehrere_gns_kz, mehrere_kst_kz, sendkst, kostenartSAP)
{
  var r,treffer
  alert(kst);
  if(window.event.srcElement.tagName=='TD')
  {
    //linke Maustaste wurde gedr�ckt, Zeile ausgew�hlt      
 // ------------------------------------------------------------------------------------------------------------------------------  
    if (typ == 'SM')
    {
//alt 10.12. 2008
//alt r=window.showModalDialog("../Dialogs/VAIDialog.htm","","dialogHeight:150px;dialogWidth:250px;"+
//alt                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
//alt      if(typeof(r)!='undefined')
//alt      {
//alt          switch(r)
//alt          {
//alt          case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAI.asp?FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&GNS="+gns+
//alt                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
//alt                            "dialogHeight:280px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
//alt          case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
//alt                           "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
//alt                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
//alt          } 
//alt      } 

      // es wird festgestellt, ob f�r die Leistungsart der ausgew�hlten Zeile mindestens ein Eintrag in ERP_VERR_KOARTGNS vorhanden ist
      // Wenn ja, dann ist die Leistungsart ein POOL und die dazugeh�rigen GNS k�nnen angezeigt werden (ansonsten nicht)
      treffer=0;
      VAIsource = new ActiveXObject("Microsoft.XMLDOM");         
      VAIsource.async = false; 
      VAIsource.load('../ASP/LoadVAILeistungsartenGNS.asp'+
                    '?KOARTID='+koartid);  

      if(VAIsource.parseError != 0)
      {
        VaiDiv.innerHTML='';
        alert('Keinen Treffer gefunden 8');
        // nur f�r den Test:   
        //  alert(VAIsource.parseError.reason);
        return;
      }
      else
      {      	
        var root = VAIsource.firstChild;
        treffer = root.getElementsByTagName('Count')(0).text
        VaiDiv.style.display='block';
      }  
  
      if (treffer == 0)
      {
        if (mehrere_gns_kz == 'True')
        {
          // Leistungsart ist ein POOL, Kennzeichen ist bereits gesetzt, aber hat noch keine GNS
          r=window.showModalDialog("../Dialogs/VAIDialog4.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
// mehrere_gns_kz, mehrere_kst_kz

            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
            case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenGNSVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}    
            } 
          }
        }
        else
        {
          // Leistungsart kein POOL
          //alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
          if (gns != '') 
          { 
          r=window.showModalDialog("../Dialogs/VAIDialog.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
            } 
          }
          }
        }  
      }
      else
      {
        // Leistungsart ist ein POOL und hat mindestens eine GNS
        // alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
        r=window.showModalDialog("../Dialogs/VAIDialog2.htm","","dialogHeight:250px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
        if(typeof(r)!='undefined')
        {
          switch(r)
          {
          case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenGNSVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}      
          case 'Anzeigen': {r=window.showModalDialog("../DialogVAI/AnzeigenVAI.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'LoeschenGNS': {r=window.showModalDialog("../DialogVAI/LoeschenVAIvonGNS.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'AendernGNS': {r=window.showModalDialog("../DialogVAI/AendernVAIvonGNS.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          } 
        } 
      } //if(treffer == 0)   

//      else 
//      {

      // es wird festgestellt, ob f�r die Leistungsart der ausgew�hlten Zeile mindestens ein Eintrag in ERP_VERR_KOARTKST vorhanden ist
      // Wenn ja, dann ist die Leistungsart ein POOL und die dazugeh�rigen KST k�nnen angezeigt werden (ansonsten nicht)
      treffer=0;   
      VAIsource = new ActiveXObject("Microsoft.XMLDOM");         
      VAIsource.async = false; 
      VAIsource.load('../ASP/LoadVAILeistungsartenKST.asp'+
                     '?KOARTID='+koartid);  
    
      if(VAIsource.parseError != 0)
      {
        VaiDiv.innerHTML='';
        alert('Keinen Treffer gefunden 10');
        // nur f�r den Test:   
        //  alert(VAIsource.parseError.reason);
        return;
      }
      else
      {
        var root = VAIsource.firstChild;
        treffer = root.getElementsByTagName('Count')(0).text
        VaiDiv.style.display='block';
      }  
  
      if (treffer == 0)      
      {      
        if (mehrere_kst_kz == 'True')
        {
          // Leistungsart ist ein POOL, Kennzeichen ist bereits gesetzt, aber hat noch keine KST
          r=window.showModalDialog("../Dialogs/VAIDialogKST4.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
            case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenKSTVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}    
            } 
          }
        }
        else
        {
          // Leistungsart kein POOL
          //alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
          
  //weglassen, da auch solche Leistungsarten, bei denen weder GNS noch KST eingegeben worden sind, g�ltig sind
  //        if (kst != '')
  //        {
          r=window.showModalDialog("../Dialogs/VAIDialogKST.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}     
            } 
          }
  //        }
        } 
      }
      else
      {
        // Leistungsart ist ein POOL und hat mindestens eine KST
        // alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
        r=window.showModalDialog("../Dialogs/VAIDialogKST2.htm","","dialogHeight:250px;dialogWidth:250px;"+
                               "center:yes;help:No;resizable:Yes;status:No;scroll:no");
        if(typeof(r)!='undefined')
        {
          switch(r)
          {
          case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenKSTVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}      
          case 'Anzeigen': {r=window.showModalDialog("../DialogVAI/AnzeigenKSTVAI.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'LoeschenKST': {r=window.showModalDialog("../DialogVAI/LoeschenVAIvonKST.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'AendernKST': {r=window.showModalDialog("../DialogVAI/AendernVAIvonKST.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          } 
        } 
      } //if(treffer == 0)
//      } //if (kst != ' ')
//      }
    }  //if (typ == 'SM')
// ------------------------------------------------------------------------------------------------------------------------------
    if (typ == 'EG')
    {
      // es wird festgestellt, ob f�r die Leistungsart der ausgew�hlten Zeile mindestens ein Eintrag in ERP_VERR_KOARTGNS vorhanden ist
      // Wenn ja, dann ist die Leistungsart ein POOL und die dazugeh�rigen GNS k�nnen angezeigt werden (ansonsten nicht)
      treffer=0;   
      VAIsource = new ActiveXObject("Microsoft.XMLDOM");         
      VAIsource.async = false; 
      VAIsource.load('../ASP/LoadVAILeistungsartenGNS.asp'+
                    '?KOARTID='+koartid);  
    
      if(VAIsource.parseError != 0)
      {
        VaiDiv.innerHTML='';
        alert('Keinen Treffer gefunden 11');
        // nur f�r den Test:   
        //  alert(VAIsource.parseError.reason);
        return;
      }
      else
      {
        var root = VAIsource.firstChild;
        treffer = root.getElementsByTagName('Count')(0).text
        VaiDiv.style.display='block';
      }  
  
      if (treffer == 0)
      {
        if (mehrere_gns_kz == 'True')
        {
          // Leistungsart ist ein POOL, Kennzeichen ist bereits gesetzt, aber hat noch keine GNS
          r=window.showModalDialog("../Dialogs/VAIDialog4.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
            case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenGNSVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}    
            } 
          }
        }
        else
        {
          // Leistungsart kein POOL
          //alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
          r=window.showModalDialog("../Dialogs/VAIDialog.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
            } 
          }
        }  
      }
      else
      {
        // Leistungsart ist ein POOL und hat mindestens eine GNS
        // alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
        r=window.showModalDialog("../Dialogs/VAIDialog2.htm","","dialogHeight:250px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
        if(typeof(r)!='undefined')
        {
          switch(r)
          {
          case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenGNSVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}      
          case 'Anzeigen': {r=window.showModalDialog("../DialogVAI/AnzeigenVAI.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'LoeschenGNS': {r=window.showModalDialog("../DialogVAI/LoeschenVAIvonGNS.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'AendernGNS': {r=window.showModalDialog("../DialogVAI/AendernVAIvonGNS.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          } 
        } 
      } //if(treffer == 0)   
    } //if (typ == 'EG')
// ------------------------------------------------------------------------------------------------------------------------------
    if (typ == 'EK')
    {
      // es wird festgestellt, ob f�r die Leistungsart der ausgew�hlten Zeile mindestens ein Eintrag in ERP_VERR_KOARTKST vorhanden ist
      // Wenn ja, dann ist die Leistungsart ein POOL und die dazugeh�rigen KST k�nnen angezeigt werden (ansonsten nicht)
      treffer=0;   
      VAIsource = new ActiveXObject("Microsoft.XMLDOM");         
      VAIsource.async = false; 
      VAIsource.load('../ASP/LoadVAILeistungsartenKST.asp'+
                     '?KOARTID='+koartid);  
    
      if(VAIsource.parseError != 0)
      {
        VaiDiv.innerHTML='';
        alert('Keinen Treffer gefunden 12');
        // nur f�r den Test:   
        //  alert(VAIsource.parseError.reason);
        return;
      }
      else
      {
        var root = VAIsource.firstChild;
        treffer = root.getElementsByTagName('Count')(0).text
        VaiDiv.style.display='block';
      }  
  
      if (treffer == 0)      
      {      
        if (mehrere_kst_kz == 'True')
        {
          // Leistungsart ist ein POOL, Kennzeichen ist bereits gesetzt, aber hat noch keine KST
          r=window.showModalDialog("../Dialogs/VAIDialogKST4.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
            case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenKSTVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}    
            } 
          }
        }
        else
        {
          // Leistungsart kein POOL
          //alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
          r=window.showModalDialog("../Dialogs/VAIDialogKST.htm","","dialogHeight:150px;dialogWidth:250px;"+
                                 "center:yes;help:No;resizable:Yes;status:No;scroll:no");
          if(typeof(r)!='undefined')
          {
            switch(r)
            {
            case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}                      
            case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}     
            } 
          }
        } 
      }
      else
      {
        // Leistungsart ist ein POOL und hat mindestens eine KST
        // alert (firma + "," + kostenart + "," + typ + "," + gueltigab + "," + gueltigbis + "," + bezeichnung + "," + betrag + '');
        r=window.showModalDialog("../Dialogs/VAIDialogKST2.htm","","dialogHeight:250px;dialogWidth:250px;"+
                               "center:yes;help:No;resizable:Yes;status:No;scroll:no");
        if(typeof(r)!='undefined')
        {
          switch(r)
          {
          case 'Detail': {r=window.showModalDialog("../DialogVAI/DialogVAImehrereGNSKST.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag+"&SENDKST="+sendkst+"&KOSTENART="+kostenartSAP,"",""+
                            "dialogHeight:320px;dialogWidth:640px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Loeschen': {r=window.showModalDialog("../DialogVAI/DeleteVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+"&GNS="+gns+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:320px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:no");break;}
          case 'Erfassen': {r=window.showModalDialog("../DialogVAI/AnzeigenUndErfassenKSTVAI.asp?KOARTID="+koartid+"&FIRMA="+firma+"&KOART="+kostenart+"&Typ="+typ+
                            "&GueltigAb="+gueltigab+"&GueltigBis="+gueltigbis+"&Bezeichnung="+bezeichnung+"&KOARTANZ="+koartanz+"&Betrag="+betrag,"",""+
                            "dialogHeight:720px;dialogWidth:740px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}      
          case 'Anzeigen': {r=window.showModalDialog("../DialogVAI/AnzeigenKSTVAI.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'LoeschenKST': {r=window.showModalDialog("../DialogVAI/LoeschenVAIvonKST.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          case 'AendernKST': {r=window.showModalDialog("../DialogVAI/AendernVAIvonKST.asp?KOARTID="+koartid+"&KOART="+kostenart+"&Typ="+typ+"&KST="+kst+"&Betrag="+betrag,"",""+
                            "dialogHeight:560px;dialogWidth:550px;center:yes;help:No;resizable:Yes;status:No;scroll:yes");break;}
          } 
        } 
      } //if(treffer == 0)    
    } //if (typ == 'EK')
          
  } //if(window.event.srcElement.tagName=='TD')
} //function a13(firma, kostenart, typ, gueltigab, gueltigbis, bezeichnung, betrag, koartanz,kst)


function AuswahlFreigabe()
{
   //Abrechnungslauf f�r Vormonat, keine Selektion
   //produktiv:  case 'FreigabeAktuellesMonat': {window.open('../ASP/LoadVAIAbrechnungsdatenKB21.asp');break;}
   //test:       case 'FreigabeAktuellesMonat': {window.open('../ASP/LoadVAIAbrechnungsdatenKB21_test.asp');break;}
   var r;
   r=window.showModalDialog("../Dialogs/VAIFreigabeDialog.htm","","dialogHeight:150px;dialogWidth:250px;"+
   "center:yes;help:No;resizable:Yes;status:No;scroll:no");
   if(typeof(r)!='undefined')
   {
      switch(r)
      {
        case 'FreigabeAktuellesMonat': {window.open('../ASP/LoadVAIAbrechnungsdatenKB21.asp');break;}
      } 
   } 
} 

function AuswahlFreigabeMitSelektion()
{
   //Abrechnungslauf f�r einen bestimmten Monat: Hier ist es m�glich, in der Maske einen (mehrere) Monat(e) und ggf auch eine KST zu selektieren 
   var r;
   r=window.showModalDialog("../Dialogs/VAIFreigabeDialogSelektion.htm","","dialogHeight:150px;dialogWidth:250px;"+
   "center:yes;help:No;resizable:Yes;status:No;scroll:no");
   if(typeof(r)!='undefined')
   {
      switch(r)
      {
        case 'FreigabeWahlmonat': {window.open('../ASP/LoadVAIAbrechnungsdatenKB21Selektion.asp'+
                                '?KST='+form16.KST.value+
                                '&VONMONAT=' +form14.VONMONAT.value+
                                '&BISMONAT=' +form14.BISMONAT.value+
                                '&VONJAHR='  +form14.VONJAHR.value+
                                '&BISJAHR='  +form14.BISJAHR.value);break;}
      } 
   } 
} 

function AuswahlFreigabeMonatslauf()
{
   //Abrechnungslauf f�r Vormonat, keine Selektion
   //produktiv:  case 'FreigabeAktuellesMonat': {window.open('../ASP/LoadVAIAbrechnungsdatenKB21.asp');break;}
   //test:       case 'FreigabeAktuellesMonat': {window.open('../ASP/LoadVAIAbrechnungsdatenKB21_test.asp');break;}
   var r;
   r=window.showModalDialog("../Dialogs/VAIFreigabeDialogMonatslauf.htm","","dialogHeight:150px;dialogWidth:250px;"+
   "center:yes;help:No;resizable:Yes;status:No;scroll:no");
   if(typeof(r)!='undefined')
   {
      switch(r)
      {
        case 'FreigabeMonatslauf': {window.open('../ASP/LoadVAIMonatslauf.asp');break;}
      } 
   } 
} 

function a23(koartid, firma, kostenart, verr_kz, typ,bezeichnung,kst,gns)
{
   var r;
     // alert (firma + "," + kostenart + "," + verr_kz + '');
   r=window.showModalDialog("../Dialogs/VAIDialog3.htm","","dialogHeight:150px;dialogWidth:250px;"+
   "center:yes;help:No;resizable:Yes;status:No;scroll:no");
   if(typeof(r)!='undefined')
   {
      switch(r)
      {
        case 'Reaktivieren': {window.open('../ASP/ReaktivierenVAI.asp'+'?KOARTID='+koartid+'&TYP='+typ);break;}
//          case 'Reaktivieren': {break;}
      } 
   }   
} //function a23(firma, kostenart, verr_kz, typ)