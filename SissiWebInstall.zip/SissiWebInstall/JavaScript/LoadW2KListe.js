function LoadW2KListe(n)
{ 
  var f=top.form
  if(false){}
  else
  {
    W2KDiv.style.display='block'
    WDiv.style.display='block'
    WDiv.runtimeStyle.cursor='wait'
    WDiv.innerHTML=''  
  
    Gsource = new ActiveXObject("Microsoft.XMLDOM")     
    if(n=='W2KMassenSuche')   
    { 
      Gsource.load('../ASP/LoadW2KMassenSuche.asp'+
                     '?STO='            +escape(form6.STO.value)+ 
                     '&Raum='           +escape(form6.Raum.value)+
                     '&KSTVerr='        +escape(form6.KSTVerr.value)+
                     '&Betriebsbereich='+escape(form6.Betriebsbereich.value)+
                     '&Name='           +escape(form6.Name.value)+
                     '&VName='          +escape(form6.Vorname.value)+
                     '&Abteilung='      +escape(form6.Abteilung.value)+                
                     '&KSTBenutzer='    +escape(form6.KSTBenutzer.value)+
                     '&KSTBesitz='      +escape(form6.KSTBesitz.value)+
                     '&Zustand='        +escape(form6.Zustand.value)+
                     '&ORDER='          +escape(form6.order.value));                     
    }
    else
    { 
      if(form5.IPNummer.value!='') was='IPNR'
      else if(form5.Inventar.value!='') was='INVNR'
      else if(form5.Equipment.value!='') was='EQU'
      else if(form5.HostAlias.value!='') was='HOSTALIAS'
      else if(form5.GNS.value!='') was='GNS'       
      Gsource.load('../ASP/LoadW2KEinzelsuche.asp'+
                   '?was='+was+
                   '&IPNR='+form5.IPNummer.value+
                   '&EQU='+form5.Equipment.value+
                   '&INVNR='+form5.Inventar.value+
                   '&HOSTALIAS='+form5.HostAlias.value+             
                   '&GNS='+form5.GNS.value+             
                   '&MACADR=')
    }
    //alert ('Einzel=' + Gsource.xml + '');
    WDivUnten.innerHTML=''
    W2KcheckReadyState('I',n) 
  }
}

function W2KcheckReadyState(n,was)  
{
  var nr=n  
 if(Gsource.readyState ==4)
  { 
    if (Gsource.parseError != 0)
    {
      
      W2KDiv.style.display='block'
      WDiv.style.display='block' 
      WDiv.innerHTML=Gsource.parseError.reason
      //WDiv.innerHTML='Server �berlastet oder Treffermenge zu gross'

      clockTimeoutID=setTimeout("top.dummy()",1000,"JavaScript")
      
      Aendern.innerHTML=''
      Sichern.innerHTML=''
      Software.innerHTML=''
      Fortschritt.innerText=''     
    }
    else 
    { 
      WDiv.style.display='block'      
      W2KDiv.style.display='block'
      Fortschritt.innerText='Ausgabe wird vorbereitet - '+
                               (Gsource.firstChild.childNodes.length-1)+' S�tze' 
      
      top.W2KGesichert=true
      // 041128 Aut.M Software.innerHTML= '<button style="width: 200; height:20;font-size: 8pt;" '+
      //                   'onClick="W2KAendern()">Bearbeiten Lizenz</button>'
      
      if(was=='W2KMassenSuche')
      {    
        window.setTimeout("WLM('1')",1)
      }                     
      else                   
      {
        window.setTimeout("WLM('2')",1)
      }
    }
  }
  else 
  {
    if(nr.length<200) nr+="I"
    else nr="I"
    Fortschritt.innerText=nr
    window.setTimeout("W2KcheckReadyState('"+nr+"','"+was+"')",50)    
  }  
}

function W2KAendern()
{
  top.W2KGesichert=false
  var Clienttyp=Lizenz=''
  var change=false
  var Dia="dialogHeight:150px;dialogWidth:300px;"+
          "dialogLeft:690;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
  r=window.showModalDialog("../Dialogs/W2KAendern.htm","",Dia)
  if(typeof(r)!='undefined')  
  {
  
  // alert('W2KAendern0-> '+r+' '+r.substring(0,1)+' '+r.substring(1,2))
   
   
    switch(r.substring(0,1))
    {
      case '1':Lizenz='MSDN';break;
      case '2':Lizenz='MSDN-Folgelizenz';break;
      case '3':Lizenz='keine - Testfeldrechner';break;
      case '4':Lizenz='keine-Fremdlizenz';break;
      case '5':Lizenz='keine-Serverlizenz';break;      
      case '6':Lizenz='keine';
    } 
    
    
    
	   for (i=1; i<W2KListeMassenSuche.elements.length; i++)   
		{
		  if (W2KListeMassenSuche.elements(i).checked==true)
			if((InvL.childNodes(1).children(i).children(3).innerHTML=='')||(r.substring(1,2)=='2'))
			 {
			  InvL.childNodes(1).children(i).children(3).innerHTML=Lizenz
			   change=true   
			 }
			
		}
	   if(change)
		{
		 W2KSichern()
		}
     
  } 
}

function W2KSichern(parLizenz)
{ 
  var mindestensEiner = false

  var root=Gsource.firstChild;

  var W2KAendernSource = new ActiveXObject("Microsoft.XMLDOM")
  W2KAendernSource.async = false;
      
  for (i=1; i<W2KListeMassenSuche.elements.length; i++)   
  {
    
    c=root.childNodes(i-1)  
    if(W2KListeMassenSuche.elements(i).checked==true)
    {
      // alert('LoadW2Kliste'+InvL.childNodes(1).children(i).children(3).innerHTML)
      W2KAendernSource.load('../ASP/W2KAendern1.asp'+
                            '?PARKID='   +c.getElementsByTagName("PARKID")(0).text+
                            '&Lizenz='   +InvL.childNodes(1).children(i).children(3).innerHTML+
                            '&PersKey='  +PersKey) 
      if(W2KAendernSource.parseError != 0)
      {
          alert(W2KAendernSource.parseError.reason)
      }
      else
      {
        mindestensEiner=true
        // Alle identische PARKID nachkorrigieren
        for (j=1; j<W2KListeMassenSuche.elements.length; j++)   
        {
         if ((i!=j) && (root.childNodes(i-1).getElementsByTagName("PARKID")(0).text == root.childNodes(j-1).getElementsByTagName("PARKID")(0).text))
			InvL.childNodes(1).children(j).children(3).innerHTML=InvL.childNodes(1).children(i).children(3).innerHTML
        }
      }                    
    }    
  }
  top.W2KGesichert=true 
  if(mindestensEiner) alert('Daten eingetragen')
  else alert('keine Ger�te ausgew�hlt')
  
  W2KAendernSource=null  
}

function Softw()
{ 
  
  var Dia="dialogHeight:310px;dialogWidth:260px;"+
          "dialogLeft:690;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
  var r=window.showModalDialog("../Dialogs/W2KSoftware.htm","",Dia)
  if(typeof(r)!='undefined')
  {
    window.setTimeout("Softw2('"+r+"')",1)
  }
}  

function Softw2(r)
{
    var mindestensEiner = false
    
    var root=Gsource.firstChild;

    var W2KAendernSource = new ActiveXObject("Microsoft.XMLDOM")
    W2KAendernSource.async = false;
  
    for (i=1; i<W2KListeMassenSuche.elements.length; i++)   
    {
    
      c=root.childNodes(i-1)  
      if(W2KListeMassenSuche.elements(i).checked==true)
      {      
        W2KAendernSource.load('../ASP/W2KSoftware.asp'+
                              '?PARKID='  +c.getElementsByTagName("PARKID")(0).text+
                              '&Software='+r+
                              '&PersKey='  +PersKey)
        if(W2KAendernSource.parseError != 0)
        {
          //alert('Fehler')
          alert(W2KAendernSource.parseError.reason)
        }
        else
        {
          mindestensEiner=true
        }                    
      }    
    }
    top.W2KGesichert=true  
    if(mindestensEiner) alert('Daten eingetragen')
    else alert('keine Ger�te ausgew�hlt')
    
    W2KAendernSource=null   

}

