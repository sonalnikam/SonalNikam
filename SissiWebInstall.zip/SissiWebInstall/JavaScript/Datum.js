function Cal() 
{   var x
    x=window.showModalDialog("../Kalender/cal.htm",
                             "",
                             "dialogHeight:270px;dialogWidth:270px;"+
                             "dialogLeft:50;dialogTop:50;help:No;resizable:No;status:No;scroll:no");
   if (typeof(x)=='undefined') r=''
   else r=x                    
   return r                          
}

function CheckDate(sDatum)
{
  var bFlag=true;
  var bHelp=false;
  var aDatum=null;

  var aDatum=sDatum.split(".");
  // Flagvariable fuer die Fehlerpruefung
  var bFlag=true;
  // Datum pruefen
  if(aDatum.length!=3 || aDatum[0].length!=2 || aDatum[1].length!=2 || aDatum[2].length!=4)
    bFlag=false;
  if(bFlag && (new Number(aDatum[0])==NaN) || (new Number(aDatum[1])==NaN) || (new Number(aDatum[0])==NaN))
    bFlag=false;

  if(bFlag)
  {
    var nTag=new Number(aDatum[0]);
    var nMonat=new Number(aDatum[1]);
    var nJahr=new Number(aDatum[2]);
    // normale Monate bis 31 Tage
    if(nMonat==1||nMonat==3||nMonat==5||nMonat==7||nMonat==8||nMonat==10||nMonat==12)
      if(nTag>=1 && nTag<=31)
        bHelp=true;
    // Monate bis 30 Tage
    if(!bHelp && (nMonat==4||nMonat==6||nMonat==9||nMonat==11))
      if(nTag>=1 && nTag<=30)
        bHelp= true;
    // Februar wenn Schaltjahr
    if(!bHelp && (nMonat==2 && Schaltjahr(nJahr)))
      if(nTag>=1 && nTag<=29)
        bHelp= true;
    // Februar wenn kein Schaltjahr
    if(!bHelp && (nMonat==2 && !Schaltjahr(nJahr)))
      if(nTag>=1 && nTag<=28)
        bHelp= true;
  }
  if(bFlag && !bHelp)
    bFlag=false;
  return bFlag;
}

function Schaltjahr(nJahr)
{
  return (!((nJahr)%4)  &&  (((nJahr)%100) || !((nJahr)%400)));
}
