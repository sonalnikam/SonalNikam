function Diverses()
{

  window.open("../index.htm","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)

}

function DokuDiensteVerwaltung()
{
  chcolor()
  DD.runtimeStyle.color='red'
  window.open("http://sissi.siemens.at/Doku/AW_Doku_Verwaltung_von_IP-Diensten.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}

function DokuITParkVerwaltungSISSIbase()
{
  chcolor()
  DW.runtimeStyle.color='red'
  window.open("../Doku/verwaltung_des_it-parks.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}

function DokuITParkVerwaltungKurzanleitung()
{
  chcolor()
  DK.runtimeStyle.color='red'
  window.open("../Doku/sissi_kurzanleitung.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}

function DokuSISSIbaseAnwender()
{
  chcolor()
  DI1.runtimeStyle.color='red'
  window.open("../Doku/anwender-doku_IT-Park.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}

function DokuPCVerwertung()
{
  chcolor()
  DP.runtimeStyle.color='red'
  window.open("http://VIEE11AA/swsp03/Documents/Private/IuK-Management/SISSI/SISSI_Doku_Draft/Aus_Prozess_gpl.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}

function DokuWebaccessAnwender()
{
  chcolor()
  DI2.runtimeStyle.color='red'
  window.open("../Doku/AW_Doku_SISSI_WEB_ACCESS_IuK-Funktionen.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)

}

function DokuVV()
{
  chcolor()
  DV.runtimeStyle.color='red'
  window.open("../doku/AW_Doku_Verfahrensverwaltung.doc","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)

}
function DokuVAIKB21AbrechnungTag()
{
  chcolor()
  KB21T.runtimeStyle.color='red'
  window.open("../it-park_fehler/ss_sap_VAI_Abrechnung_tgl.txt","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}

function DokuVAIKB21AbrechnungMonat()
{
  chcolor()
  KB21M.runtimeStyle.color='red'
  window.open("../it-park_fehler/ss_sap_VAI_Abrechnung.txt","","width=850,height=600,top=50,left=150,menubar=yes,scrollbars=yes",false)
}