function Ini()
{
  NochNichtGewaehlt=true
  IPwie='expand'
  ILwie='collapse'
  WLwie='collapse'
  Dwie='collapse'
  Vwie='collapse'
  SELLeistungsartenKOA=false
  SELLeistungsartenABR=false
  SELLeistungsartenERF=false
  SELArbeitsplaetze=false
  SELRollen=false
  SELStandorte_1=false
  SELStandorte_2=false
  SELStandorte_3=false
  aktVLZeile=''
  aktSLZeile=''
  top.lastIPSuche=''

  IniAusw()

  aktWahl=AuswIPGeraet
  aktDiv=GeraeteDiv

  Unten.innerHTML='<table border="0" cellspacing="1" cellpadding="0" style="TABLE-LAYOUT: fixed;font-size:12;">\
  <col WIDTH="50"><col WIDTH="120"><col WIDTH="120"><col WIDTH="*"><tr>\
  <td><img src="../Images/htmlicon.gif" WIDTH="16" HEIGHT="16"></td>\
  <td style="COLOR: #008080">Application Server: NETS146A</td>\
  <td style="COLOR: #008080">Database Server: NETS146A\\ ITPARK</td>\
  <td style="COLOR: #008080"></td>\
  <td style="COLOR: red"><span id="Fortschritt"></span></td></tr></table>'

  DiensteDiv.style.left=625
  DiensteDiv.style.width=390

  SchnittstDiv.style.left=505 //325
  SchnittstDiv.style.width=515 //695

  document.onkeypress=HandleKey
}

function IniAusw()
{
  IniAuswIPGeraet()
  IniAuswIPPers()
  IniAuswIPFehler()
  IniAuswILGeraet()
  IniAuswILPers()
  IniAuswW2KMassenSuche()
  IniAuswW2KEinzelSuche()
  IniAuswSegmente()
  IniAuswUebersiedeln()
  IniAuswAusscheiden()
  IniAuswVerfahren()
  IniAuswWSGeraet()
  IniAuswWSPers()
  IniAuswVAIKOA()
  IniAuswVAIABR()
  IniAuswVAIKST()
  IniAuswVAIERF()
}
