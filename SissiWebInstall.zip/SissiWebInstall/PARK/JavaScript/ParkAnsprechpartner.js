function LoadAnsprechPartner(pid,PersKey)
{
  content5.innerHTML=''+
      '<span id="Angabe">'+jsVerfahren+': '+jsBEZ+' '+jsBEZERG+'</span>'+
      '<table border="0" cellspacing=0 cellpadding=0 style="Position:absolute; top=50; left=30; TABLE-LAYOUT: fixed;">'+
      '<col WIDTH=600>'+
      '<tr>'+
      '  <td height="320" valign="top"><div id="AnsprDiv"><div id="AspDiv"></div></div></td>'+
      '</tr><tr>'+      
      '<td onclick="EingabeAnsprechpartner('+pid+')" colspan=4>'+
      '<button style="height:18;font-size: 8pt">Anspechpartner hinzuf�gen</button></tr>'+      
      '</table>'

  s=''+
    '<table style="TABLE-LAYOUT: fixed" border="1" cellspacing=0 cellpadding=0>'+
    '<col WIDTH=20><col WIDTH=190><col WIDTH=190><col WIDTH=180>'+
    '<tr>'+
    '<th>&nbsp;</th><th>Name</th><th>Vorname</th><th>Rolle</th>'
          
  if(pid!='Neu')
  { 
    Asource = new ActiveXObject("Microsoft.XMLDOM")
    Asource.async = false;
    Asource.load('../Verfahren/ASP/LoadAnsprech.asp?PARKID='+pid); 

    if(Asource.parseError != 0)
    {
      alert(Asource.parseError.reason)
    }
    else
    {
      if(Asource.text=='keinen Eintrag gefunden')
      {

      }
      else
      {
        var root=Asource.firstChild; 
        for (var i=0; i< root.childNodes.length; i++)   
        {
          c=root.childNodes(i)
          s+='<tr onclick="ShowANSPRECH('+c.getElementsByTagName("ASPID")[0].text+')">'+
             '<td onclick="LoeschenAnsprechpartner('+pid+','+c.getElementsByTagName("ASPID")[0].text+','+c.getElementsByTagName("ROLLE")[0].text+')"><button style="height:18;font-size: 8pt">...</button>'+
             '</td><td>'+c.getElementsByTagName("FNAME")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("VNAME")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("BEMERK")[0].text+'&nbsp;</td>'+
             '</tr>'
        }         
      }
      Asource=null
    }  
  }
  AspDiv.innerHTML=s
}

function EingabeAnsprechpartner(pid)
{
  if(Edit(5))
  {
    var DiaStrNamen="dialogHeight:490px;dialogWidth:490px;"+
                    "dialogLeft:290;dialogTop:100;help:No;resizable:No;status:No;scroll:no" 
    r=window.showModalDialog("../Verfahren/DialogAnsprechpartner/DialogAnsprechpartner.htm",pid+"@A@"+PersKey,DiaStrNamen)
    LoadAnsprechPartner(pid,PersKey)
  }  
}

function LoeschenAnsprechpartner(pid,aspid,Rolle)
{
  if(Edit(5))
  {
    if(confirm('Wirklich l�schen?'))
    {   
   
      Nsource = new ActiveXObject("Microsoft.XMLDOM")
      Nsource.async = false; 
      Nsource.load('../Verfahren/ASP/LoeschenAnsprechpartner.asp?pid='  +pid+
                                                               '&ASPID='+aspid+
                                                               '&Rolle='+Rolle) 
      if (Nsource.parseError != 0)
      {
        alert(Nsource.parseError.reason)
      }
      else 
      {  
        var root=Nsource.lastChild;       
        //alert(root.getElementsByTagName("MSG")(0).text)
      }
      Nsource = null   
    }
    LoadAnsprechPartner(pid,PersKey)
  }    
}

function ShowANSPRECH(aspid)
{
      var DiaDetail="dialogHeight:280px;dialogWidth:345px;"+
          "dialogLeft:460;dialogTop:100;help:No;resizable:No;status:No;scroll:no"
      var x11='../Verfahren/DetailAnsprechpartner/DetailAnsprechpartner.asp?aspid='+aspid
	  window.showModalDialog(x11,'',DiaDetail)   	  	

}     