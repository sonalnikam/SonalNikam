function LoadDetails(pid,PersKey)
{
//	alert('--1--' +jsVerfahren)
  content3.innerHTML=''+
      '<span id="Angabe">'+jsVerfahren+': '+jsBEZ+' '+jsBEZERG+'</span>'+
      '<table border="0" cellspacing=0 cellpadding=0 style="Position:absolute; top=50; left=30; TABLE-LAYOUT: fixed;">'+
      '<col WIDTH=600>'+
      '<tr>'+
      '  <td height="340"><div id="LinkDiv"><div id="LDiv"></div></div></td>'+
      '</tr>'+
      '</table>'
      
  if(pid!='Neu')
  {
    var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
    xmlhttp.Open("POST","ASP/LoadDetails.asp?pid="+pid,false)
    xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;')
    xmlhttp.Send('<?xml version="1.0" ?>')
    LDiv.innerHTML=xmlhttp.responseText
  }
}

function park_histo()
{
  var DiaDetail="dialogHeight:315px;dialogWidth:920px;"+
                "dialogLeft:40;dialogTop:5;help:No;resizable:No;status:No;scroll:no" 
  r=window.showModalDialog("../Details/PARK_HISTO.asp?pid="+pid,"",DiaDetail)
}

function Dienste()
{
  var DiaDetail="dialogHeight:315px;dialogWidth:920px;"+
                "dialogLeft:40;dialogTop:5;help:No;resizable:No;status:No;scroll:no" 
  r=window.showModalDialog("../PARK/ASP/AlleDienste.asp?PARKID="+pid,"",DiaDetail)
}