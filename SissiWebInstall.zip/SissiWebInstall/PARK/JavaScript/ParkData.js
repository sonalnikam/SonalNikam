function LoadData(pid,PersKey,pSS_Art)
{
  if(pid!='Neu')
  { 
    Dsource = new ActiveXObject("Microsoft.XMLDOM")
    Dsource.async = false;
    Dsource.load('../Verfahren/ASP/LoadSSData.asp?PARKID='+pid); 

    if(Dsource.parseError != 0)
    {
      alert(Dsource.parseError.reason)
    }
    else
    {
      if(Dsource.text=='keinen Eintrag gefunden')
      {
        jsVerfahren='' 
        jsBEZERG=jsEQU=jsStatus1=jsInbetriebnahme=jsDATNEU=jsDATLA=jsAEND=jsPARKINFO=''
        jsVersion=jsLizenznr=jsAblaufdatum=jsNEU=''
        jsBEZ=pSS_Art
      }
      else
      {      
        jsVerfahren=Dsource.getElementsByTagName("VERFAHREN")[0].text
        SS_Art=Dsource.getElementsByTagName("ANLTEXT")[0].text
        jsBEZ=Dsource.getElementsByTagName("ANLTEXT")[0].text
        jsBEZERG=Dsource.getElementsByTagName("BEZ")[0].text
        jsEQU='00'+Dsource.getElementsByTagName("PARKID")[0].text
        jsStatus1=Dsource.getElementsByTagName("STATUS")[0].text
        jsInbetriebnahme=Dsource.getElementsByTagName("INBETRIEB")[0].text    
      
      
        jsDATNEU=Dsource.getElementsByTagName("DATNEU")[0].text
        jsDATLA=Dsource.getElementsByTagName("DATLA")[0].text
        jsAEND=Dsource.getElementsByTagName("AEND")[0].text
        jsPARKINFO=Dsource.getElementsByTagName("PARKINFO")[0].text
        jsVersion=Dsource.getElementsByTagName("PVERSION")[0].text
        jsLizenznr=Dsource.getElementsByTagName("MLFB")[0].text
        jsAblaufdatum=Dsource.getElementsByTagName("DABBAU")[0].text
        jsNEU=Dsource.getElementsByTagName("NEU")[0].text        
      }
    }
  }
  else
  {
    jsVerfahren='' 
    jsBEZERG=jsEQU=jsStatus1=jsInbetriebnahme=jsDATNEU=jsDATLA=jsAEND=jsPARKINFO=''
    jsVersion=jsLizenznr=jsAblaufdatum=jsNEU=''
    jsBEZ=pSS_Art 
  }
  ShowEingaben()
	if(Dsource.text=='keinen Eintrag gefunden')      
	{
		//alert('06');
	}else{
	var ArbeitsPl=(Dsource.getElementsByTagName("PARKID")[0].text==
                 Dsource.getElementsByTagName("HPARKID")[0].text)
	}

  Dsource=null
  return ArbeitsPl
}    

function ShowEingaben()    
{        
  content1.innerHTML=''+
  '<span id="Angabe">'+jsVerfahren+': '+jsBEZ+' Equipmentnummer '+jsEQU+'</span>'+
  '<table style="Position:absolute; top=50; TABLE-LAYOUT: fixed; left:30;" border="0" cellspacing=0 cellpadding=0>'+
  '<col WIDTH=147><col WIDTH=30><col WIDTH=470>'+
  '<tr>'+
  '<td rowspan="1" valign="top"><IMG border=1 height=89 src="../images/sissi-logo-winzig-gelb.gif" width=144></td>'+
  '<td>&nbsp;</td>'+
  
  '<td><table border="0" cellspacing=0 cellpadding=0 style="border: white 1px inset;TABLE-LAYOUT: fixed">'+
  '<col WIDTH=5><col WIDTH=90><col WIDTH=180><col WIDTH=170><tr>'+  
  '<td>&nbsp;</td><td>Bezeichnung</td>'+
  '<td colspan=2><input name="BEZERG" size=65 value="'+jsBEZERG+'" disabled=true></td>'+
  '</tr><tr>'+
  '<td>&nbsp;</td><td>Status</td>'+
'<td><input value="'+jsStatus1+'" disabled=true></td>'+  
 /* 
  '<td><SELECT class="Anz" name="Status1" disabled=true>'+
  '<OPTION value=0>Bestellt, nicht geliefert, geplant</OPTION>'+
  '<OPTION value=20>Aktiv, produktiv</OPTION>'+
  '<OPTION value=37>Demontiert, deaktiviert</OPTION>'+
  '<OPTION value=40>Zur Loeschung vorgesehen</OPTION>'+
  '</SELECT></td>'+  
*/  
  '</tr><tr>'+
  '<td>&nbsp;</td><td>Inbetriebnahme</td>'+
  '<td><input name="Inbetrieb" size=30 value="'+jsInbetriebnahme+'" disabled=true></td>'+
  '<td onclick="Inbetrieb.value=Cal()"><img src="../images/newappt.gif"></td>'+
  '</tr><tr>'+
  '<td>&nbsp;</td><td>Version</td>'+
  '<td><input name="Version" size=30 value="'+jsVersion+'" disabled=true></td>'+
  '</tr><tr>'+
  '<td>&nbsp;</td><td>Lizenznummer</td>'+
  '<td><input name="Lizenznr" size=30 value="'+jsLizenznr+'" disabled=true></td>'+
  '</tr><tr>'+
  '<td>&nbsp;</td><td>Abbaudatum</td>'+
  '<td><input name="Ablaufdatum" size=30 value="'+jsAblaufdatum+'" disabled=true></td>'+  
  '<td onclick="Ablaufdatum.value=Cal()"><img src="../images/newappt.gif"></td>'+
  '</tr></table></td>'+
  
  '<tr>'+     
  '<td colspan=3>&nbsp;</td>'+
  '</tr><tr>'+
  '<td></td><td></td><td>'+

  '<table border="0" style="border: white 1px inset;"><tr>'+  
  '<td>Datum Neuanlage</td>'+
  '<td colspan="2">'+jsDATNEU+'</td>'+
  '</tr><tr>'+
  '<td>Bearbeiter Neuanlage</td>'+
  '<td colspan="2">'+jsNEU+'</td>'+
  '</tr><tr>'+
  '<td>Datum letzte �nderung</td>'+
  '<td colspan="2">'+jsDATLA+'</td>'+
  '</tr><tr>'+
  '<td>letzter �nderungsbearbeiter</td>'+
  '<td colspan="2">'+jsAEND+'</td>'+
  '</tr></table></td>'+
  
  '<tr>'+
  '<td>Parkinfo</td>'+
  '</tr><tr>'+
  '<td colspan="4">'+
  '<textarea name="ParkInfo" cols="75" rows="6" style="background-color: #FFFFFF;)" disabled=true>'+
  jsPARKINFO+'</textarea>'+
  '</td>'+
  '</tr>'+
  '</table>'
/* 
  var k=0
  switch(jsStatus1)
  {  
    case 'Aktiv, produktiv'                   : k=1;break;
    case 'Demontiert, deaktiviert'            : k=2;break;
    case 'Zur Loeschung vorgesehen'           : k=3;
  }
  Status1.options[k].selected = true; 
*/      
} 

function SaveSSData()
{
  var Art=''
  var retval=''
  if(Inbetrieb.value!='')
  {   
    if(!CheckDate(Inbetrieb.value)) {alert('Inbetriebnahmedatum nicht g�ltig');return}
  }
  if(Ablaufdatum.value!='')
  {  
    if(!CheckDate(Ablaufdatum.value)) {alert('Abbaudatum nicht g�ltig');return}
  }
  switch(jsBEZ)
  {
    case 'Verfahren'            : {Art=6000172;break;}
    case 'Verfahrensmodul'      : {Art=6000174;break;}
    case 'Eingangsschnittstelle': {Art=6000176;break;}
    case 'Ausgangsschnittstelle': {Art=6000178;break;}
  }     
  DSsource = new ActiveXObject("Microsoft.XMLDOM")
  DSsource.async = false;
 
  DSsource.load('../Verfahren/ASP/SchreibeData.asp?PARKID=' +pid+
                                                 '&HPARKID='+hpid+
                                                 '&PersKey='+PersKey+
                                                 '&Art='+Art+
                                                 '&Status='+Status1.value+
                                                 '&BEZERG='+escape(BEZERG.value)+
                                                 '&EQU=00'+pid+
                                                 '&Inbetrieb='+Inbetrieb.value+
                                                 '&Version='+Version.value+
                                                 '&Lizenznr='+Lizenznr.value+
                                                 '&Ablaufdatum='+Ablaufdatum.value+
                                                 '&ParkInfo='+escape(ParkInfo.value))
  if(DSsource.parseError != 0)
  {
    alert('Fehler beim Speichern\n'+
    '?PARKID=' +pid+
    '&HPARKID='+hpid+
    '&PersKey='+PersKey+
    '&Art='+Art+
    '&Status='+Status1.value+
    '&BEZERG='+escape(BEZERG.value)+
    '&EQU=00'+pid+
    '&Inbetrieb='+Inbetrieb.value+
    '&Version='+Version.value+
    '&Lizenznr='+Lizenznr.value+
    '&Ablaufdatum='+Ablaufdatum.value+
    '&ParkInfo='+escape(ParkInfo.value))    
    //alert(DSsource.parseError.reason)
  }
  else
  {    
    var root=DSsource.firstChild;
    retval=root.firstChild.text  
  }
  DSsource=null
  return retval 
}