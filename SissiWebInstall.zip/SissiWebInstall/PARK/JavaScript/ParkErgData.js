function LoadErgData(pid,PersKey,SS_Art)
{
   var ponr
   content2.innerHTML=''+ 
      '<span id="Angabe">'+jsVerfahren+': '+jsBEZ+' '+jsBEZERG+'</span>'+
      //'<span style="position:absolute;top:50;left:30">'+
      //'<IMG border=1 height=89 src="../images/sissi-logo-winzig-gelb.gif" width=144>'+
      //'</span>'+
      '<table border="2" cellspacing=0 cellpadding=0 style="Position:absolute; top=50; left=30; TABLE-LAYOUT: fixed;">'+
      '<col WIDTH=640>'+
      '<tr>'+
      '  <td>'+
      '  <table border="0" cellspacing=0 cellpadding=0 style="TABLE-LAYOUT: fixed;font-family:Arial;">'+
      '  <col WIDTH=180><col WIDTH=230><col WIDTH=210>'+
      '  <tr><td>'+
      '  <tr>'+
      '  <td>&nbsp;&nbsp;Gruppe</td><td>&nbsp;&nbsp;Bezeichnung</td><td>Eingabefeld</td>'+
      '  </tr>'+
      '  </table>'+
      '  </td>'+
      '</tr>'+
      '<tr>'+
      '  <td height="300"><div id="NamenDiv">'+
      '    <div id="NDiv" onscroll="refreshNDiv()"></div></div></td>'+
      '</tr>'+
      '</table>'

  if(pid!='Neu')
  {
    was ='../Verfahren/ASP/LoadErgSSData.asp?PARKID='+pid
  }
  else
  {
    switch(SS_Art)
    {
      case 'Verfahrensmodul'      :{ponr=3052;break;}
      case 'Eingangsschnittstelle':
      case 'Ausgangsschnittstelle':{ponr=3053;break;}      
    }
    was ='../Verfahren/ASP/LeerErgSSData.asp?PONR='+ponr
  }  
  var i=0 
  var str='<form name="formErgData">'+
  '<table border="0" cellspacing=0 cellpadding=0 style="TABLE-LAYOUT:fixed;font-family:Arial;">'+
  '<col WIDTH=180><col WIDTH=230><col WIDTH=210>'
   
  Dsource = new ActiveXObject("Microsoft.XMLDOM")
  Dsource.async = false;
  
  Dsource.load(was); 

  if(Dsource.parseError != 0)
  {
    alert(Dsource.parseError.reason)
  }
  else
  { 
    var root=Dsource.firstChild;
    if(Dsource.text=='keinen Eintrag gefunden')
    {
alert(Dsource.text)   
    }
    else
    {
      var altZGNBEZ='XXX'  
      for (i=0; i< root.childNodes.length; i++)   
      {
        c=root.childNodes(i)        
        var Eingabe=''
        
        if(pid!='Neu')
        {        
          switch(c.getElementsByTagName("DTYP")(0).text)
          {
            case '-1': Eingabe=c.getElementsByTagName("INHTEXT")[0].text;break;
            case '0':  Eingabe=c.getElementsByTagName("INHDOUBLE")[0].text;break;
            case '2':  {
                         Eingabe=c.getElementsByTagName("INHTEXT")[0].text;                         
                         if(Eingabe=='Insert&amp;Update') Eingabe='Insert&Update'
                         break;
                       }  
            case '3':  Eingabe=c.getElementsByTagName("INHDATE")[0].text;break;         
          }
        }        
        str+='<tr><td class="Erg">&nbsp;&nbsp;&nbsp;'
        if(c.getElementsByTagName("ZGNBEZ")[0].text!=altZGNBEZ)
        {
          str+=''+c.getElementsByTagName("ZGNBEZ")[0].text+'&nbsp;'
          altZGNBEZ=c.getElementsByTagName("ZGNBEZ")[0].text
        }
        else
        {
          str+=''              
        }
        str+='</td><td class="Erg">&nbsp;&nbsp;&nbsp;'+c.getElementsByTagName("BEZ")[0].text+'&nbsp;</td>'+            
             '<td class="Erg">'+EingErgData(i,Eingabe)+'</td>'+
             '<input type="hidden" value="'+Eingabe+'">'+
             '<input type="hidden" value="'+c.getElementsByTagName("BEZNR")[0].text+'">'+
             '<input type="hidden" value="'+c.getElementsByTagName("DTYP")[0].text+'">'+
             '</tr>'              
      }
    }
    Dsource=null
    NDiv.innerHTML=str+'</table></form>'
    return i
  }  
}  

function EingErgData(z,Eingabe)
{
  var s1,c1
  var c=Dsource.firstChild.childNodes(z)
  var keineEingabe=true
  if(c.getElementsByTagName("DTYP")[0].text=='2')
  {  
    s1=''+
    '<SELECT class="Anz" style="width:180" name="ErgDat'+z+'" disabled=true>'
    
    var SELsource = new ActiveXObject("Microsoft.XMLDOM")
    SELsource.async = false;    
    SELsource.load('../Verfahren/ASP/LoadAuswahlwert.asp?BEZNR='+c.getElementsByTagName("BEZNR")[0].text) 
    if (SELsource.parseError != 0)
    {
      alert('Datenbankfehler')
    }
    else 
    {  
      var root=SELsource.firstChild;   
      for (var i=0; i<root.childNodes.length; i++)   
      {
        if(root.childNodes(i).text==Eingabe)
        {
          s1+='<OPTION SELECTED value="'+root.childNodes(i).text+'">'+root.childNodes(i).text+'</OPTION>'
          keineEingabe=false
        }
        else
        {
          s1+='<OPTION value="'+root.childNodes(i).text+'">'+root.childNodes(i).text+'</OPTION>'
        }  
      }
      if(keineEingabe)
      {
        s1+='<OPTION SELECTED value="">noch keine Auswahl</OPTION>'
      }
      s1+='</SELECT>'
    }
    SELsource=null   
  }
  else
  {
    if(c.getElementsByTagName("DTYP")[0].text=='3')
    {
      s1='<input class="Anz" onblur="chkField(this)" value="'+Eingabe+'" maxlength="30" size="30" name="ErgDat'+z+'" disabled=true>'
    }
    else
    {
      s1='<input class="Anz" value="'+Eingabe+'" maxlength="30" size="30" name="ErgDat'+z+'" disabled=true>'  
    }
  }      
  return s1 
}

function chkField(t)
{
  if(t.value!='')
  { 
    if(!CheckDate(t.value)) 
    {
      alert('Geben Sie bitte das Datum im Format tt.mm.jj ein');
      return
    }
  }  
}

function SaveErgData(parmParkID,parampid)
{ 
  var ponr
  switch(SS_Art)
  {
    case 'Verfahren'            :{ponr=3051;break;}
    case 'Verfahrensmodul'      :{ponr=3052;break;}
    case 'Eingangsschnittstelle':{ponr=3053;break;}
    case 'Ausgangsschnittstelle':{ponr=3053;break;}      
  }
  for(var i=0; i<formErgData.length-3; i+=4)
  {
    if((formErgData[i].value!=formErgData[i+1].value) || (parmParkID!=parampid))
    {
    
      DSsource = new ActiveXObject("Microsoft.XMLDOM")
      DSsource.async = false;  
      DSsource.load('../Verfahren/ASP/SchreibeErgData.asp?PARKID=' +parmParkID+                                                
                                                        '&PersKey='+PersKey+
                                                        '&DTYP='+formErgData[i+3].value+
                                                        '&Wert='+escape(formErgData[i].value)+
                                                        '&PONR='+ponr+
                                                        '&BEZNR='+formErgData[i+2].value)
      if(DSsource.parseError != 0)
      {
        alert('Fehler beim Speichern\n'+
        '?PARKID=' +parmParkID+                                                
        '&PersKey='+PersKey+
        '&DTYP='+formErgData[i+3].value+
        '&Wert='+escape(formErgData[i].value)+
        '&PONR='+ponr+
        '&BEZNR='+formErgData[i+2].value)        
        
        //alert(DSsource.parseError.reason)
      }
      else
      {
        //var root=DSsource.firstChild;
        //alert(root.firstChild.text)  
      }
      DSsource=null  
      //alert(formErgData[i].value+'--'+formErgData[i+1].value)  
    }
    
  }
}

function refreshNDiv()
{  
    NDiv.style.display='none'
    NDiv.style.display='block'
   
}

