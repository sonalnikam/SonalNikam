function LoadITPark(pid,PersKey)
{
  content5.innerHTML=''+
      '<span id="Angabe">'+jsVerfahren+': '+jsBEZ+' '+jsBEZERG+'</span>'+
      '<table border="0" cellspacing=0 cellpadding=0 style="Position:absolute; top=50; left=30; TABLE-LAYOUT: fixed;">'+
      '<col WIDTH=600>'+
      '<tr>'+
      '  <td height="320" valign="top"><div id="AnsprDiv"><div id="AspDiv"></div></div></td>'+
      '</tr>'+      
      '</table>'
         
  if(pid!='Neu')
  { 
    var xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
    xmlhttp.Open("POST","ASP/LoadITPark.asp?pid="+pid,false)
    xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;')
    xmlhttp.Send('<?xml version="1.0" ?>')
    AnsprDiv.innerHTML=xmlhttp.responseText
  }
}


