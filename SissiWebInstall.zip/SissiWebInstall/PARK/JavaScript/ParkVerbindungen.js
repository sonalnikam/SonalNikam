function LoadParkVerbindungen(pid,PersKey)
{
  content4.innerHTML=''+
  '<span id="Angabe">'+jsVerfahren+': '+jsBEZ+' '+jsBEZERG+'</span>'+
  '<div id="EigeneVerbDiv"><div id="EVDiv"></div></div>'+
  '<div style="position:absolute;top:110;left:30"><button onclick="EingabeVerbindung(pid,PersKey)">�ndern</button></div>'+
  '<div id="VerbDiv"><div id="VDiv"></div></div>' 
  s=''+
    '<table style="TABLE-LAYOUT: fixed" border="0" cellspacing=0 cellpadding=0>'+
    '<col WIDTH=190><col WIDTH=140><col WIDTH=250><col WIDTH=190><col WIDTH=400>'+
    '<tr>'+
    '<td id="VFTH">Verbindungen von Verfahren</td><td id="VFTH">Art</td><td id="VFTH">Schnittstelle</td><td id="VFTH">Status</td><td id="VFTH">Verbindungsinfo</td>'
          
  if(pid!='Neu')
  {
    Vsource = new ActiveXObject("Microsoft.XMLDOM")
    Vsource.async = false;
    Vsource.load('../Verfahren/ASP/LoadVerbindungen.asp?RPARKID='+pid); 

    if(Vsource.parseError != 0)
    {
      alert(Vsource.parseError.reason)
    }
    else
    {
      if(Vsource.text=='keinen Eintrag gefunden')
      {

      }
      else
      {
        var root=Vsource.firstChild; 
        for (var i=0; i< root.childNodes.length; i++)   
        {
          c=root.childNodes(i)
          s+='<tr onclick="Wechseln('+
                           c.getElementsByTagName("PARKID")[0].text+','+
                           c.getElementsByTagName("MPARKID")[0].text+','+PersKey+')">'+
             '</td><td>'+c.getElementsByTagName("BEZ_VERFAHREN")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("ANLTEXT")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("BEZ")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("STATXT")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("VERBINDUNGS_INFO")[0].text+'&nbsp;</td>'+             
             '</tr>'
        }         
      }
      Vsource=null
    }  
  }
  VDiv.innerHTML=s+'</table>'
  if(pid!='Neu') LoadEigeneVerbindung(pid,PersKey)
}      
      
function LoadEigeneVerbindung(pid,PersKey)
{
    var s='<table style="TABLE-LAYOUT: fixed" border="0" cellspacing=0 cellpadding=0>'+
    '<col WIDTH=190><col WIDTH=140><col WIDTH=250><col WIDTH=190><col WIDTH=400>'+
    '<tr style="BACKGROUND: red;">'+
    '<td id="VFTH">Verbindung zu Verfahren</td><td id="VFTH">Art</td><td>Schnittstelle</td><td id="VFTH">Status</td><td id="VFTH">Verbindungsinfo</td>'

    Vsource = new ActiveXObject("Microsoft.XMLDOM")
    Vsource.async = false;
    Vsource.load('../Verfahren/ASP/LoadEigeneVerbindung.asp?PARKID='+pid); 

    if(Vsource.parseError != 0)
    {
      alert(Vsource.parseError.reason)
    }
    else
    {
      if(Vsource.text=='keinen Eintrag gefunden')
      {

      }
      else
      {
        var root=Vsource.firstChild; 
        for (var i=0; i< root.childNodes.length; i++)   
        {
          c=root.childNodes(i)
          s+='<tr onclick="Wechseln('+
                           c.getElementsByTagName("PARKID")[0].text+','+
                           c.getElementsByTagName("MPARKID")[0].text+','+PersKey+')">'+
             '</td><td>'+c.getElementsByTagName("BEZ_VERFAHREN")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("ANLTEXT")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("BEZ")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("STATXT")[0].text+'&nbsp;</td>'+
             '<td>'+c.getElementsByTagName("VERBINDUNGS_INFO")[0].text+'&nbsp;</td>'+
             '</tr>'
        }         
      }
      Vsource=null
    }
    EVDiv.innerHTML+=s+'</table>'
}      
     
function Wechseln(ParkID,MParkID,PersKey)
{  
  window.returnValue=ParkID+"@A@"+MParkID+"@B@"+"Detail"+"@C@"+PersKey                       
  window.close()                                         
}                                           

function EingabeVerbindung(pid)
{
  if(Edit(4))
  {
    var DiaStrNamen="dialogHeight:630px;dialogWidth:490px;"+
                    "dialogLeft:290;dialogTop:90;help:No;resizable:No;status:No;scroll:no" 
    r=window.showModalDialog("../Verfahren/DialogVerbindung/DialogVerbindung.htm",pid+"@A@"+PersKey,DiaStrNamen)
    LoadParkVerbindungen(pid,PersKey)
  }  
}                                            
