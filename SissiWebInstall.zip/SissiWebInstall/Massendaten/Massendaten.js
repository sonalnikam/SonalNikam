function Massendaten()
{ 
  if(typeof(Msource)=='undefined')
  {
    alert('nichts ausgew�hlt')
    return
  }
  var OK=true
  var keinesAusgewaehlt=true
  var root=Msource.firstChild;
  var i=0
  while(i<MListe.elements.length-1 && OK)
  {
    if(MListe.elements(i+1).checked)
    {
      keinesAusgewaehlt=false
    }
    i++  
  }
  if(keinesAusgewaehlt) alert('nichts ausgew�hlt')
  else
  {
    if(OK)
    {
      var str1='<K><PARKIDs>'
      var erstePARKID=0
      for (i=0; i<MListe.elements.length-1; i++)   
      {
        if(MListe.elements(i+1).checked)
        {
          c=root.childNodes(i)
          var pid = c.getElementsByTagName("PARKID")(0).text      
          str1+='<PARKID>'+pid+'</PARKID>'
          if(erstePARKID==0) erstePARKID=c.getElementsByTagName("PARKID")(0).text
        }  
      }
      str1+='</PARKIDs></K>@@@'+PersKey+'@A@'+erstePARKID       
      var DiaDetail="dialogHeight:500px;dialogWidth:840px;"+
                    "dialogLeft:170;dialogTop:150;help:No;resizable:No;status:No;scroll:no" 
      r=window.showModalDialog("../Massendaten/Massendaten.htm",str1,DiaDetail)        
    }
    else alert('Angaben unvollst�ndig')
  }
} 
